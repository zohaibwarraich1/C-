#include <iostream>
#include <ctime>
using namespace std;
int main()
{
    clock_t startTime = clock(); // Start measuring runtime

    //* Code here between start time and end time.

    clock_t endTime = clock(); // End measuring runtime
    double duration = double(endTime - startTime) / CLOCKS_PER_SEC;
    cout << "Runtime: " << duration << " seconds" << endl;
    return 0;
}