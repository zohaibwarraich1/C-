#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool isCyclicUtil(int v, vector<int> adj[], map<int, bool> visited, int parent)
{
    visited[v] = true;
    for (int i : adj[v])
    {
        if (!visited[i])
        {
            if (isCyclicUtil(i, adj, visited, v))
                return true;
        }
        else if (i != parent)
            return true;
    }
    return false;
}
bool isCycle(int V, vector<int> adj[])
{
    map<int, bool> visited;
    for (int u = 0; u < V; u++)
    {
        if (!visited[u])
        {
            if (isCyclicUtil(u, adj, visited, -1))
                return true;
        }
    }
    return false;
}
int main()
{
    vector<int> adj[] = {{1}, {0, 2, 4}, {1, 3}, {2, 4}, {1, 3}};
    if (isCycle(5, adj))
    {
        cout << "True";
    }
    else
        cout << "False";
    return 0;
}