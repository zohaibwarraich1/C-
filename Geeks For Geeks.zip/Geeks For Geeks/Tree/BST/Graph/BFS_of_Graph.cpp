#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> bfsOfGraph(int V, vector<int> adj[])
{
    map<int, bool> visit;
    vector<int> res;
    queue<int> q;
    q.push(0);
    while (!q.empty())
    {
        int curr = q.front();
        q.pop();
        visit[curr] = true;
        res.push_back(curr);
        for (int i = 0; i < adj[curr].size(); i++)
        {
            if (visit[adj[curr][i]] == false)
            {
                q.push(adj[curr][i]);
                visit[adj[curr][i]] = true;
            }
        }
    }
    return res;
}
int main()
{
    int V = 5;
    vector<int> adj[] = {{1, 2, 3}, {}, {4}, {}, {}};
    vector<int> res = bfsOfGraph(V, adj);
    for (auto ele : res)
    {
        cout << ele << " ";
    }
    return 0;
}