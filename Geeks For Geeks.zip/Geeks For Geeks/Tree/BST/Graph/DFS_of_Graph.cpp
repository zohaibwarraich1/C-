#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void DFS(vector<int> adj[], map<int, bool> &visit, vector<int> &res, int curr)
{
    visit[curr] = true;
    res.push_back(curr);
    for (int i = 0; i < adj[curr].size(); i++)
    {
        if (visit[adj[curr][i]] == false)
        {
            DFS(adj, visit, res, adj[curr][i]);
        }
    }
}
vector<int> dfsOfGraph(int V, vector<int> adj[])
{
    map<int, bool> visit;
    vector<int> res;
    for (int i = 0; i < V; i++)
    {
        if (visit[i] == false)
        {
            DFS(adj, visit, res, i);
        }
    }
    return res;
}
int main()
{
    int V = 5;
    vector<int> adj[] = {{2, 3, 1}, {0}, {0, 4}, {0}, {2}};
    vector<int> result = dfsOfGraph(V, adj);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}