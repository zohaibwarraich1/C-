#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void isCyclicUtil(vector<int> adj[], int u,
                  map<int, bool> &visited, map<int, bool> &recStack, bool &found)
{
    visited[u] = true;
    recStack[u] = true;
    for (int x : adj[u])
    {
        if (!visited[x])
        {
            isCyclicUtil(adj, x, visited, recStack, found);
            if (found)
            {
                found = true;
                return;
            }
        }
        else if (recStack[x])
        {
            found = true;
            return;
        }
    }
    recStack[u] = false;
    return;
}
bool isCyclic(int V, vector<int> adj[])
{
    map<int, bool> visited;
    map<int, bool> recStack;
    bool found = false;
    for (int i = 0; i < V; i++)
    {
        if (!visited[i])
        {
            isCyclicUtil(adj, i, visited, recStack, found);
            if (found == true)
            {
                return true;
            }
        }
    }
    return false;
}
int main()
{
    vector<int> adj[] = {{1}, {2}, {3}, {3}};
    if (isCyclic(4, adj))
    {
        cout << "True";
    }
    else
        cout << "False";
    return 0;
}