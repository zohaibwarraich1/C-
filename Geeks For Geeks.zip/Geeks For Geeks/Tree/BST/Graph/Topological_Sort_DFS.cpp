#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void DFS(vector<int> adj[], map<int, bool> &visit, vector<int> &res, int curr)
{
    visit[curr] = true;
    for (int i = 0; i < adj[curr].size(); i++)
    {
        if (visit[adj[curr][i]] == false)
        {
            DFS(adj, visit, res, adj[curr][i]);
        }
    }
    res.push_back(curr);
}
vector<int> topoSort(int V, vector<int> adj[])
{
    map<int, bool> visit;
    vector<int> res;
    for (int i = 0; i < V; i++)
    {
        if (visit[i] == false)
        {
            DFS(adj, visit, res, i);
        }
    }
    reverse(res.begin(), res.end());
    return res;
}
int main()
{
    int V = 6;
    vector<int> adj[] = {{}, {3}, {3}, {}, {0, 1}, {0, 2}};
    vector<int> res = topoSort(V, adj);
    for (auto ele : res)
    {
        cout << ele << " ";
    }
    return 0;
}