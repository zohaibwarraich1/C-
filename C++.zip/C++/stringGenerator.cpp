#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
string LeetCode(string s)
{
    string result;
    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == '-')
        {
            s[i] = ' ';
        }
        if (s[i] == '.')
        {
            s.erase(s.begin() + i);
        }
        if (s[i] == ' ')
        {
            s[i] = '_';
        }
    }
    return s;
}
int main()
{
    string s;
    getline(cin, s);
    cout << LeetCode(s) << endl;
    return 0;
}