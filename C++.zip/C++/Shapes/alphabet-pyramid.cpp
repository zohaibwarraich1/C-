#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
    //! Program for inverse alphabets pyramid //

    int rows;
    cout << "Enter rows: ";
    cin >> rows;
    for (int i = 1; i <= rows; i++)
    {
        for (int k = 1; k <= rows - i; k++)
        {
            cout << " ";
        }
        for (int alphabets = (i - 1) * 2; alphabets >= 0; alphabets--)
        {
            cout << static_cast<char>(alphabets + 65);
        }
        cout << endl;
    }
    return 0;
}