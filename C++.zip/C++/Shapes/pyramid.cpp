#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
    int rows;
    cout << "Enter rows: ";
    cin >> rows;
    for (int i = 0; i < rows; i++)
    {
        for (int k = 1; k <= rows - i; k++)
        {
            cout << " ";
        }
        for (int star = i * 2; star >= 0; star--)
        {
            cout << "*";
        }
        cout << endl;
    }
    return 0;
}