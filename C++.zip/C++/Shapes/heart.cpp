#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
    //! Program of heart //

    int rows;
    cout << "Enter odd number of rows: ";
    cin >> rows;
    cout << endl;
    for (int i = 1; i <= rows; i++)
    {
        if (i % 2 == 0)
        {
            for (int j = 1; j <= i; j++)
            {
                cout << "*";
            }
            for (int k = 2; k <= (rows - i) * 2; k++)
            {
                cout << " ";
            }
            for (int l = rows; l >= 1; l--)
            {
                if (l <= i)
                {
                    cout << "*";
                }
            }
            cout << endl;
        }
    }
    int half = 1;
    for (int i = rows * 2; i >= 1; i--)
    {
        if (i % 2 == 1 || i == 1)
        {
            for (int j = 1; j <= i; j++)
            {
                if (j == 1)
                {
                    for (int m = 1; m < half; m++)
                    {
                        cout << " ";
                    }
                }
                cout << "*";
            }
            cout << endl;
            half++;
        }
    }
    return 0;
}