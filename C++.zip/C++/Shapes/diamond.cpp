#include <iostream>
using namespace std;
int main()
{
	//! Program for diamond //

	int num;
	cout << "Enter an odd number for diamond: ";
	cin >> num;
	char p = '*';
	int half = num / 2;
	for (int i = 1; i <= num; i++)
	{
		if (i % 2 == 0)
			continue;
		for (int j = 1; j <= i; j++)
		{
			if (j == 1)
				for (int m = 1; m <= half; m++)
				{
					cout << " ";
				}
			cout << p;
			if (i == j)
			{
				cout << endl;
				half = half - 1;
			}
		}
	}
	int half_2 = 1;
	for (int i = num; i >= 1; i--)
	{
		if (i % 2 == 0)
			continue;
		if (i == num)
		{
			continue;
		}
		for (int j = 1; j <= i; j++)
		{
			if (j == 1)
				for (int m = 1; m <= half_2; m++)
				{
					cout << " ";
				}
			cout << p;
			if (i == j)
			{
				cout << endl;
				half_2 = half_2 + 1;
			}
		}
	}
	return 0;
}