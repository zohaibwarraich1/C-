#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
    //! Program for square pattern based on user's given height and width //

    int height, width;
    cout << "Enter height: ";
    cin >> height;
    cout << "Enter width: ";
    cin >> width;
    for (int i = 1; i <= height; i++)
    {
        if (i == 1 || i == height)
        {
            for (int j = 1; j <= width; j++)
            {
                cout << "* ";
            }
        }
        else
        {
            for (int k = 1; k == 1; k++)
            {
                cout << "*";
            }
            for (int l = 1; l <= width - 2; l++)
            {
                cout << "  ";
            }
            for (int m = 1; m == 1; m++)
            {
                cout << " *";
            }
        }
        cout << endl;
    }
    return 0;
}