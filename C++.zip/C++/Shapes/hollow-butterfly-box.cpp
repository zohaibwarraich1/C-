#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
    //! Program for hollow butterfly box //

    int rows;
    cout << "Enter number of rows: ";
    cin >> rows;
    int temp_rows = rows / 2;
    for (int i = temp_rows; i >= 1; i--)
    {
        for (int j = 1; j <= i; j++)
        {
            cout << j;
        }
        for (int k = 1; k <= (temp_rows - i) * 2; k++)
        {
            cout << " ";
        }
        for (int l = temp_rows; l >= 1; l--)
        {
            if (l <= i)
            {
                cout << l;
            }
        }
        cout << endl;
    }
    for (int i = 1; i <= temp_rows; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            cout << j;
        }
        for (int k = 1; k <= (temp_rows - i) * 2; k++)
        {
            cout << " ";
        }
        for (int l = temp_rows; l >= 1; l--)
        {
            if (l <= i)
            {
                cout << l;
            }
        }
        cout << endl;
    }
    return 0;
}