#include <iostream>
using namespace std;
int main()
{
    //! Program for printing reverse pattern of star //

    int r, c, s;
    for (r = 5; r >= 1; r--)
    {
        for (s = 1; s <= 5 - r; s++)
        {
            cout << " ";
        }
        for (c = 1; c <= r; c++)
        {
            cout << "*";
        }
        cout << endl;
    }
    return 0;
}