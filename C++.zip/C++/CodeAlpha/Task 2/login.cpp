#include <iostream>
#include "registration.cpp"
using namespace std;
class Login : public Form
{
public:
    Login() {}
    Login(string name, string username, string email, string password) : Form(name, username, email, password) {}
    void getDetails() override
    {
        cout << "Enter Your Username: ";
        getline(cin, username);
        ifstream checkUsername;
        checkUsername.open(username);
        char quit = 'n';
        while (!checkUsername.is_open() && quit != 'y')
        {
            cout << "This Username is not available!" << endl;
            cout << "Do you want to quit? y/n";
            cin >> quit;
            if (quit != 'y')
            {
                cout << "Enter a valid Username: ";
                getline(cin, username);
                checkUsername.open(username);
            }
        }
        Login result = File::ReadDetails(username);
        cout << "Logged In!" << endl;
        result.PrintDetails();
    }
    void PrintDetails()
    {
        Form::PrintDetails();
    }
};