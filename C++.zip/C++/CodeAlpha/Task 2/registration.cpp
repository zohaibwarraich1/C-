#include <iostream>
#include <fstream>
#include "form.cpp"
using namespace std;
class Registration : public Form
{
public:
    Registration() {}
    Registration(string name, string username, string email, string password) : Form(name, username, email, password) {}
    void getDetails() override
    {
        cout << "Enter Your First and Last Name: ";
        getline(cin, name);
        cout << "Enter Your Username: ";
        getline(cin, username);
        ifstream checkUsername;
        checkUsername.open(username);
        while (checkUsername.is_open())
        {
            cout << "This Username is already present!" << endl;
            cout << "Enter a new Username";
            getline(cin, username);
            checkUsername.open(username);
        }
        cout << "Enter your email: ";
        getline(cin, email);
        cout << "Enter your password: ";
        getline(cin, password);
        Registration r = Registration(name, username, email, password);
        File::CreateFile(r);
    }
    void PrintDetails()
    {
        Form::PrintDetails();
    }
};