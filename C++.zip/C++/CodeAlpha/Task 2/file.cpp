#include <iostream>
#include <fstream>
#include "login.cpp"
using namespace std;
class File
{
    static ofstream write;
    static ifstream read;

public:
    static void CreateFile(Registration r)
    {
        write.open(r.username);
        write << r.name << endl;
        write << r.username << endl;
        write << r.email << endl;
        write << r.password << endl;
    }
    static Login ReadDetails(string username)
    {
        read.open(username);
        Login result = Login();
        string temp;
        getline(read, temp);
        result.name = temp;
        getline(read, temp);
        result.username = temp;
        getline(read, temp);
        result.email = temp;
        getline(read, temp);
        result.password = temp;
        return result;
    }
};
ofstream File::write;
ifstream File::read;