#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    int input;
    cout << "Press folowing commmands:" << endl
         << "1 for Register: " << endl
         << "2 for login" << endl;
    cin >> input;
    switch (input)
    {
        cin.ignore();
    case 1:
    {
        Registration r = Registration();
        r.getDetails();
    }
    case 2:
    {
        Login l = Login();
        l.getDetails();
    }
    }
    return 0;
}