#include <iostream>
#include "file.cpp"
using namespace std;
class Form
{
public:
    string name;
    string username;
    string email;
    string password;
    Form() {}
    Form(string name, string username, string email, string password)
    {
        this->name = name;
        this->username = username;
        this->email = email;
        this->password = password;
    }
    virtual void getDetails() = 0;
    void PrintDetails()
    {
        cout << "Your Username: " << username << endl;
        cout << "Your Email: " << email << endl;
        cout << "Your Password: " << password << endl;
    }
};
