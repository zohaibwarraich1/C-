#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//! Write a C++ program that takes a vector of strings and returns only those strings that contain a number(s). Return an empty vector if none.

//! Prototype
vector<string> numberString(vector<string> a);

int main()
{
    vector<string> a = {"red", "green23", "1black", "white"};
    vector<string> result = numberString(a);
    if (result.empty())
    {
        cout << "There are no words that contain digits";
    }
    else
    {
        cout << "There are ";
        for (int i = 0; i < result.size(); i++)
            cout << result[i] << " ";
        cout << " words that contain digits";
    }
    return 0;
}
vector<string> numberString(vector<string> a)
{
    vector<string> temp;
    bool reverse = true;
    for (int i = 0; i < a.size(); i++)
    {
        for (int j = 0; j < a[i].size(); j++)
        {
            for (char k = '0'; k < '9'; k++)
            {
                if (a[i][j] == k && reverse == true)
                {
                    temp.push_back(a[i]);
                    reverse = false;
                }
            }
        }
        reverse = true;
    }
    return temp;
}