#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//! Write a C++ program to verify that all of the letters in the second string appear in the first string as well. Return true otherwise false.

//! Prototype
bool secString(vector<string> a);

int main()
{
    vector<string> a = {"python", "py"};
    bool result = secString(a);
    if (result)
    {
        cout << "The string " << a[0] << " contains " << a[1];
    }
    else
    {
        cout << "The string " << a[0] << " doesn't contains " << a[1];
    }
    return 0;
}
bool secString(vector<string> a)
{
    for (int i = 0; i < a[1].size(); i++)
    {
        if (a[0][i] != a[1][i])
        {
            return false;
        }
    }
    return true;
}