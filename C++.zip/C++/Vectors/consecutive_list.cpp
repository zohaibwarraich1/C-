#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//! Write a C++ program to check whether numbers in a vector can be rearranged so that each number appears exactly once in a consecutive list of numbers. Return true otherwise false

//! Prototype
bool consecutiveList(vector<int> a);

int main()
{
    vector<int> number = {1, 5, 3, 7, 2};
    cout << "Original array: ";
    for (int i = 0; i < number.size(); i++)
    {
        cout << number[i] << " ";
    }
    cout << endl;
    bool Result = consecutiveList(number);
    if (Result)
    {
        cout << "Numbers can be rearranged to form a consecutive list.";
    }
    else
    {
        cout << "numbers cannot be rearranged to form a consecutive list.";
    }
    return 0;
}
bool consecutiveList(vector<int> a)
{
    sort(a.begin(), a.end());
    for (int i = 0; i < a.size(); i++)
    {
        if (a[i] == a[i + 1])
        {
            cout << a[i] << " number is repeatitve. So, ";
            return false;
        }
    }
    for (int i = 0; i < a.size() - 1; i++)
    {
        if (a[i] + 1 != a[i + 1])
        {
            cout << a[i] + 1 << " is not present. So, ";
            return false;
        }
    }
    return true;
}