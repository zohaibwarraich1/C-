#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//! Write a C++ program to capitalize the first character of each element of a given string vector. Return the vector.

//! Prototype
void firstCapitalLetter(vector<string> &a);

int main()
{
    vector<string> a = {"grapes", "apple", "mango", "orange"};
    cout << "Before capitalising first letter of each word: ";
    for (int i = 0; i < a.size(); i++)
    {
        cout << a[i] << " ";
    }
    firstCapitalLetter(a);
    cout << "\nAfter capitalising first letter of each word: ";
    for (int i = 0; i < a.size(); i++)
    {
        cout << a[i] << " ";
    }
    return 0;
}
void firstCapitalLetter(vector<string> &a)
{
    for (int i = 0; i < a.size(); i++)
    {
        a[i][0] = toupper(a[i][0]);
    }
}