#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//! Write a C++ program that returns the elements in a vector that are strictly smaller than their adjacent left and right neighbours.

//! Prototype
vector<int> smallerElements(vector<int> a);

int main()
{
    vector<int> numbers = {1, 2, 5, 0, 3, 2, 7};
    vector<int> result = smallerElements(numbers);
    if (result.empty())
    {
        cout << "There is no element smaller than their adjacent neighbours.";
    }
    else
    {
        cout << "The smaller elements: ";
        for (int i = 0; i < result.size(); i++)
        {
            cout << result[i] << " ";
        }
    }
    return 0;
}
vector<int> smallerElements(vector<int> a)
{
    vector<int> temp;
    for (int i = 0; i < a.size(); i++)
    {
        if (a[i] < a[i - 1] && a[i] < a[i + 1])
        {
            temp.push_back(a[i]);
        }
    }
    return temp;
}