#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int maxPairs(vector<int> skillLevel, int minDiff)
{
    sort(skillLevel.begin(), skillLevel.end());
    int n = skillLevel.size();
    int ans = 0;
    int i = 0;
    int j = 1;
    for (int k = 0; k < n / 2; ++k) //* If we dont divide n/2 it will again count an element that is already in pair with another element.
    {
        while (j < n && skillLevel[j] - skillLevel[i] < minDiff)
        {
            ++j;
        }
        if (j < n)
        {
            ++ans;
            ++i;
            ++j;
        }
    }

    return ans;
}
int main()
{
    vector<int> skillLevel = {1, 3, 5, 7, 9};
    cout << maxPairs(skillLevel, 4);
    return 0;
}