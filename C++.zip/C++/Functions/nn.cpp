#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    // creating file to input numbers
    ofstream write;
    write.open("input.txt");
    write << "78" << endl;
    write << "86" << endl;
    write << "44" << endl;
    write << "80" << endl;
    write.close();
    // closing file

    // opening file to get number
    // string temp;
    // int counter = -1;
    // ifstream read;
    // read.open("input.txt");
    // while (!read.eof())
    // {
    //     getline(read, temp);
    //     counter++;
    // }
    // read.close();
    // closing file

    int *array=new int[4];
    int i = 0;
    string *store_numbers= new string[4];

    // opening file to get number
    ifstream read2;
    read2.open("input.txt");
    while (!read2.eof())
    {
        getline(read2, store_numbers[i]);
        // array[i] = stoi(store_numbers[i]);
        i++;
    }
    read2.close();
    // closing file

    for (int i = 0; i < 4; i++)
    {
        array[i] = stoi(store_numbers[i]);
    }
    for (int i = 0; i < 4; i++)
    {
        for (int j = i + 1; j < 4; i++)
        {
            if (array[i] < array[j])
            {
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
        cout << array[i] << " ";
    }
    return 0;
}