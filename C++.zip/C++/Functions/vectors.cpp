#include <iostream>
#include <vector>
using namespace std;
int main()
{
    vector<int> n;

    char ans;
    do
    {
        int nn;
        cout << "enter element: ";
        cin >> nn;
        n.push_back(nn);
        cout << "Do you want to enter more number?: ";
        cin >> ans;
    } while (ans == 'y');
    // n[0] = 1080;
    // n.clear();
    for (int i = 0; i <= n.size(); i++)
    {
        // cout << n[0] << endl;
        cout << n[i] << " ";
    }
    cout << n.size();
}