#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <cctype>
using namespace std;

//! Prototype
string upper_case_letter(string a);

int main()
{
    string a = "ali ahmad hello";
    cout << upper_case_letter(a);
    return 0;
}
string upper_case_letter(string a)
{
    for (int i = 0; i < a.length(); i++)
    {
        if (i == 0 && a[i] != ' ')
        {
            int b = static_cast<int>(a[i]);
            int c = b - 32;
            a[i] = static_cast<char>(c);
        }
        if (a[i - 1] == ' ' && a[i] >= 97 && a[i] <= 122)
        {
            int b = static_cast<int>(a[i]);
            int c = b - 32;
            a[i] = static_cast<char>(c);
        }
    }
    return a;
}