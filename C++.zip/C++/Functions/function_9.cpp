#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <cctype>
using namespace std;

//! Prototype //
int sum(int a, int b);

int main()
{
    int a,b;
    cin>>a>>b;
    cout<<sum(a,b);
    return 0;
}
int sum(int a, int b)
{
    if(a>b)
    {
        cout<<a<<" is greater than ";
        return b;
    }
    else 
    {
        cout<<b<<" is greater than ";
        return a;
    }
}