#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
using namespace std;

//?Prototype
void print(int num1, int num2);
int greatest(int num1, int num2);

//! Program for checking greatest number between 2 numbers using function //

int main()
{
    int a = 5;
    int b = 6;
    cout << greatest(a, b) << "\b";
    return 0;
}
int greatest(int num1, int num2)
{
    if (num1 > num2)
    {
        print(num1, num2);
        return 0;
    }
    else
    {
        print(num2, num1);
        return 0;
    }
}
void print(int num1, int num2)
{
    cout << num1 << " is greater than " << num2;
    return;
}