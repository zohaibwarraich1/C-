#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
using namespace std;

//! functions Prototype //
void greatest_num(int a, int b);
void smallest_num(int x, int y);
//! functions Prototype //

//! Program by using Function to find sum of two numbers //

int main()
{
    int a, b;
    cin >> a >> b;
    greatest_num(a, b);
    int x, y;
    cin >> x >> y;
    smallest_num(x, y);
    return 0;
}
//* function to find greatest number
void greatest_num(int a, int b)
{
    if (a > b)
    {
        cout << a << " is greater than " << b << endl;
    }
    else
    {
        cout << b << " is greater than " << a << endl;
    }
}
//* function to find smallest number
void smallest_num(int x, int y)
{
    if (x < y)
    {
        cout << x << " is less than " << y << endl;
    }
    else
    {
        cout << y << " is less than " << x << endl;
    }
}