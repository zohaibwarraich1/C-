#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
using namespace std;

//! Prototype //
int factorial_1(int a);
void factorial_2(int num);

int main()
{
    int num = 6;
    cout << num << "!"
         << " = " << factorial_1(num);
    return 0;
}
//* For sum of factorial //
int factorial_1(int num)
{
    int multiply = 1;
    for (int i = num; i > 0; i--)
    {
        factorial_2(i);
        multiply *= i;
    }
    return multiply;
}
//* For printing numbes starting from factorial upto 1 //
void factorial_2(int num)
{
    if (num > 1)
    {
        cout << num << " * ";
    }
    else
    {
        cout << num << " = ";
    }
    return;
}