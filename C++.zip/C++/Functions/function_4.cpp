#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
using namespace std;

//! Prototype
void fibonacci(int a);

int main()
{
    int n = 10;
    fibonacci(n);
    return 0;
}
//* For printing fibonacci numbers //
void fibonacci(int a)
{
    int first = 0;
    int sec = 1;
    int fibonacci = 1;
    for (int i = 0; i < a; i++)
    {
        fibonacci = first + sec;
        first = sec;
        sec = fibonacci;
        cout << fibonacci << " ";
    }
    return;
}