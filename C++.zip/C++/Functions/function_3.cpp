#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
using namespace std;

//! Prototype //
bool isFibonacci(int a);

int main()
{
    int first = 9;
    int sec = 30;
    for (int i = first; i <= sec; i++)
    {
        if (isFibonacci(i))
        {
            cout << i << " ";
        }
    }
    return 0;
}
//* For checking the number is prime or not //
bool isFibonacci(int a)
{
    if (a == 2 || a == 3 || a == 5 || a == 7)
    {
        return true;
    }
    else if (a % 2 == 0 || a % 3 == 0 || a % 5 == 0 || a % 7 == 0)
    {
        return false;
    }
    if (a % 2 == 1)
    {
        return true;
    }
}
