#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
using namespace std;

//! Prototype //
void spaces(int rows, int a);
void pascal_formula(int i);

int main()
{
    int num = 5;
    for (int i = 0; i < num; i++)
    {
        spaces(num, i);
        pascal_formula(i);
    }
    return 0;
}
//* For printing spaces //
void spaces(int rows, int iteration)
{
    for (int i = 0; i < (rows - iteration) - 1; i++)
    {
        cout << " ";
    }
    return;
}
//* For printing pascal numbers //
void pascal_formula(int iteration)
{
    int pascal = 1;
    for (int j = 0; j <= iteration; j++)
    {
        cout << pascal << " ";
        pascal = pascal * (iteration - j) / (j + 1);
    }
    cout << endl;
    return;
}