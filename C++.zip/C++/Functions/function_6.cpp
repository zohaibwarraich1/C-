#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
using namespace std;

//! Prototype //
int factorial_1(int a);
void factorial_2(int num);
long double nCr(int n, int r);

int main()
{
    int n = 6;
    int r = 5;
    cout << nCr(n, r) << endl;
    return 0;
}
//* For sum of factorial //
int factorial_1(int num)
{
    int multiply = 1;
    for (int i = num; i > 0; i--)
    {
        multiply *= i;
    }
    return multiply;
}
//* For printing numbers starting from factorial upto 1 //
void factorial_2(int num)
{
    cout << "nCr = n!/(n-r)!*r!" << endl;
    cout << "nCr = ";
    return;
}
//* For printing nCr //
long double nCr(int n, int r)
{
    int formula_division = (factorial_1(n) - factorial_1(r)) * factorial_1(n);
    factorial_2(n);
    long double formula = static_cast<long double>(factorial_1(n)) / static_cast<long double>(formula_division);
    return formula;
}