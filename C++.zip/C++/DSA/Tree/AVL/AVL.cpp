#include <iostream>
#include "TreeNode.cpp"
using namespace std;
class AVL
{
    TreeNode *root = nullptr;

public:
    ;
    AVL() : root(nullptr) {}
    AVL(TreeNode *root) : root(root) {}
    ~AVL()
    {
        delete root;
    }
    TreeNode *insert(TreeNode *r, TreeNode *new_node)
    {
        if (r == nullptr)
        {
            r = new_node;
            return r;
        }
        else if (r->val > new_node->val)
        {
            r->left = insert(r->left, new_node);
        }
        else if (r->val < new_node->val)
        {
            r->right = insert(r->right, new_node);
        }
        int bf = getBalanceFactor(r);
        if (bf > 1 && new_node->val < r->left->val)
        {
            return rightRotate(r);
        }
        else if (bf < -1 && new_node->val > r->right->val)
        {
            return leftRotate(r);
        }
        else if (bf > 1 && new_node->val > r->left->val)
        {
            r->left = leftRotate(r->left);
            return rightRotate(r);
        }
        else if (bf < -1 && new_node->val < r->right->val)
        {
            r->right = leftRotate(r->right);
            return rightRotate(r);
        }
        return r;
    }
    bool isEmpty()
    {
        if (root == nullptr)
            return true;
        else
            return false;
    }
    void PreOrder(TreeNode *r)
    {
        //* PreOrder -> NLR
        if (r == nullptr)
        {
            return;
        }
        cout << r->val << " ";
        PreOrder(r->left);
        PreOrder(r->right);
    }
    void InOrder(TreeNode *r)
    {
        //* InOrder -> LNR
        if (r == nullptr)
        {
            return;
        }
        InOrder(r->left);
        cout << r->val << " ";
        InOrder(r->right);
    }
    void PostOrder(TreeNode *r)
    {
        //* PostOrder -> LRN
        if (r == nullptr)
        {
            return;
        }
        PostOrder(r->left);
        PostOrder(r->right);
        cout << r->val << " ";
    }
    int height(TreeNode *r)
    {
        if (r == nullptr)
        {
            return -1;
        }
        else
        {
            int left = height(r->left);
            int right = height(r->right);
            if (left > right)
            {
                return (left + 1);
            }
            else
            {
                return (right + 1);
            }
        }
    }
    int count(TreeNode *r)
    {
        int x = 0, y = 0;
        if (r != nullptr)
        {
            x = count(r->left);
            y = count(r->right);
            return x + y + 1;
        }
        return 0;
    }
    void BFS(TreeNode *r)
    {
        int h = height(r);
        for (int i = 0; i <= h; i++)
        {
            PrintBFS(r, i);
        }
    }
    TreeNode *Delete(TreeNode *root, int val)
    {
        if (root == nullptr) //* Base condition
        {
            return nullptr;
        }
        else if (root->val < val) //* If val is smaller than node val, go to left
        {
            root->right = Delete(root->right, val);
        }
        else if (root->val > val) //* If val is larger than node val, go to right
        {
            root->left = Delete(root->left, val);
        }
        else //* If val matches
        {
            TreeNode *temp;
            if (root->left == nullptr) //* Node with only right child OR No child
            {
                temp = root->right;
                return temp;
            }
            else if (root->right == nullptr) //* Node with only left child
            {
                temp = root->left;
                return temp;
            }
            else //* Node with two childs
            {
                temp = minValNode(root->right);
                root->val = temp->val;
                root->right = Delete(root->right, temp->val); //* Delete that right subtree's copied node by recursion again.
            }
        }
        int bf = getBalanceFactor(root);
        if (bf == 2 && getBalanceFactor(root->left) >= 0)
        {
            return rightRotate(root);
        }
        else if (bf == 2 && getBalanceFactor(root->left) < 0)
        {
            root->left = leftRotate(root->left);
            return rightRotate(root);
        }
        else if (bf == -2 && getBalanceFactor(root->right) <= 0)
        {
            return leftRotate(root);
        }
        else if (bf == -2 && getBalanceFactor(root->right) > 0)
        {
            root->right = rightRotate(root->right);
            return leftRotate(root);
        }
        return root;
    }

private:
    void PrintBFS(TreeNode *r, int level)
    {
        if (r == nullptr)
        {
            return;
        }
        else if (level == 0)
        {
            cout << r->val << " ";
        }
        else
        {
            PrintBFS(r->left, level - 1);
            PrintBFS(r->right, level - 1);
        }
    }
    int getBalanceFactor(TreeNode *r)
    {
        if (r == nullptr)
        {
            return -1;
        }
        return (height(r->left) - height(r->right));
    }
    TreeNode *leftRotate(TreeNode *r)
    {
        TreeNode *x = r->right;
        TreeNode *y = x->left;
        //*Perfom Rotation
        x->left = r;
        r->right = y;
        return x;
    }
    TreeNode *rightRotate(TreeNode *r)
    {
        TreeNode *x = r->left;
        TreeNode *y = x->right;
        //*Perfom Rotation
        x->right = r;
        r->left = y;
        return x;
    }
    TreeNode *minValNode(TreeNode *r)
    {
        TreeNode *temp = r;
        while (temp->left != nullptr)
        {
            temp = temp->left;
        }
        return temp;
    }
};