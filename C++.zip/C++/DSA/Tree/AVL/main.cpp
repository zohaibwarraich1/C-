#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
#include "AVL.cpp"
using namespace std;
int main()
{
    TreeNode *root = new TreeNode(3);
    root->left = new TreeNode(2);
    root->right = new TreeNode(5);
    AVL a1 = AVL(root);
    root = a1.insert(root, new TreeNode(6));
    a1.PreOrder(root);
    root = a1.insert(root, new TreeNode(10));
    cout << endl;
    a1.PreOrder(root);
    a1.Delete(root, 6);
    cout << endl;
    a1.PreOrder(root);
    return 0;
}