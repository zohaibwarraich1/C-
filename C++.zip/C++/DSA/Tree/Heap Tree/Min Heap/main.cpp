#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
#include "minheap.cpp"
using namespace std;
int main()
{
    MinHeap mh = MinHeap(15);
    mh.insertKey(8);
    mh.insertKey(9);
    mh.insertKey(11);
    mh.printArray();
    mh.extractMin();
    mh.printArray();
    return 0;
}