#include <iostream>
#include "TreeNode.cpp"
using namespace std;
class BST
{
public:
    TreeNode *root = nullptr;
    BST() : root(nullptr) {}
    BST(TreeNode *root) : root(root) {}
    ~BST()
    {
        delete root;
        // cout << "Memory has been freed" << endl;
    }
    bool isEmpty()
    {
        if (root == nullptr)
            return true;
        else
            return false;
    }
    void insert(TreeNode *new_node)
    {
        if (root == nullptr)
        {
            root = new_node;
        }
        else
        {
            TreeNode *temp = root;
            while (temp != nullptr)
            {
                if (new_node->val <= temp->val)
                {
                    if (temp->left == nullptr)
                    {
                        temp->left = new_node;
                        break;
                    }
                    else
                    {
                        temp = temp->left;
                    }
                }
                else
                {
                    if (temp->right == nullptr)
                    {
                        temp->right = new_node;
                        break;
                    }
                    else
                    {
                        temp = temp->right;
                    }
                }
            }
        }
    }
    void PreOrder(TreeNode *r)
    {
        //* PreOrder -> NLR
        if (r == nullptr)
        {
            return;
        }
        cout << r->val << " ";
        PreOrder(r->left);
        PreOrder(r->right);
    }
    void InOrder(TreeNode *r)
    {
        //* InOrder -> LNR
        if (r == nullptr)
        {
            return;
        }
        InOrder(r->left);
        cout << r->val << " ";
        InOrder(r->right);
    }
    void PostOrder(TreeNode *r)
    {
        //* PostOrder -> LRN
        if (r == nullptr)
        {
            return;
        }
        PostOrder(r->left);
        PostOrder(r->right);
        cout << r->val << " ";
    }
    TreeNode *Iterative_Search(int val)
    {
        if (root == nullptr)
        {
            return nullptr;
        }
        TreeNode *temp = root;
        while (temp != nullptr)
        {
            if (val == temp->val)
            {
                return temp;
            }
            else if (temp->val > val)
            {
                temp = temp->left;
            }
            else
            {
                temp = temp->right;
            }
        }
        return nullptr;
    }
    TreeNode *Recursive_Search(TreeNode *r, int val)
    {
        if (r == nullptr)
        {
            return nullptr;
        }
        else if (r->val == val)
        {
            return r;
        }
        else if (r->val > val)
        {
            return Recursive_Search(r->left, val);
        }
        else
        {
            return Recursive_Search(r->right, val);
        }
    }
    int height(TreeNode *r)
    {
        if (r == nullptr)
        {
            return -1;
        }
        else
        {
            int left = height(r->left);
            int right = height(r->right);
            if (left > right)
            {
                return (left + 1);
            }
            else
            {
                return (right + 1);
            }
        }
    }
    int count(TreeNode *r)
    {
        int x = 0, y = 0;
        if (r != nullptr)
        {
            x = count(r->left);
            y = count(r->right);
            return x + y + 1;
        }
        return 0;
    }
    void BFS(TreeNode *r)
    {
        int h = height(r);
        for (int i = 0; i <= h; i++)
        {
            PrintBFS(r, i);
        }
    }
    TreeNode *DeleteNode(TreeNode *r, int val)
    {
        if (r == nullptr) //* Base condition
        {
            return r;
        }
        else if (r->val > val) //* If val is smaller than node val, go to left
        {
            r->left = DeleteNode(r->left, val);
        }
        else if (r->val < val) //* If val is larger than node val, go to right
        {
            r->right = DeleteNode(r->right, val);
        }
        else //* If val matches
        {
            TreeNode *temp = nullptr;
            if (r->left == nullptr) //* Node with only right child OR No Child
            {
                temp = r->right;
                // delete r;
                return temp;
            }
            else if (r->right == nullptr) //* Node with only left child
            {
                temp = r->left;
                // delete r;
                return temp;
            }
            else //* Node with two childs
            {
                temp = minNodeVal(r->right);
                r->val = temp->val;
                r->right = DeleteNode(r->right, temp->val); //* Delete that right subtree's copied node by recursion again.
            }
        }
        return r;
    }

private:
    void PrintBFS(TreeNode *r, int level)
    {
        if (r == nullptr)
        {
            return;
        }
        else if (level == 0)
        {
            cout << r->val << " ";
        }
        else
        {
            PrintBFS(r->left, level - 1);
            PrintBFS(r->right, level - 1);
        }
    }
    TreeNode *minNodeVal(TreeNode *r)
    {
        TreeNode *temp = r;
        while (temp->left != nullptr)
        {
            temp = temp->left;
        }
        return temp;
    }
};