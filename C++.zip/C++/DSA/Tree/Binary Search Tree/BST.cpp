#include <iostream>
#include "TreeNode.cpp"
using namespace std;
class BST
{
public:
    TreeNode *root = nullptr;
    BST() : root(nullptr) {}
    BST(TreeNode *root) : root(root) {}
    ~BST()
    {
        delete root;
        cout << "Memory has been freed" << endl;
    }
    bool isEmpty()
    {
        if (root == nullptr)
            return true;
        else
            return false;
    }
    void insert(TreeNode *new_node)
    {
        if (root == nullptr)
        {
            root = new_node;
        }
        else
        {
            TreeNode *temp = root;
            while (temp != nullptr)
            {
                if (new_node->val <= temp->val)
                {
                    if (temp->left == nullptr)
                    {
                        temp->left = new_node;
                        break;
                    }
                    else
                    {
                        temp = temp->left;
                    }
                }
                else
                {
                    if (temp->right == nullptr)
                    {
                        temp->right = new_node;
                        break;
                    }
                    else
                    {
                        temp = temp->right;
                    }
                }
            }
        }
    }
    void PreOrder(TreeNode *r)
    {
        //* PreOrder -> NLR
        if (r == nullptr)
        {
            return;
        }
        cout << r->val << " ";
        PreOrder(r->left);
        PreOrder(r->right);
    }
    void InOrder(TreeNode *r)
    {
        //* InOrder -> LNR
        if (r == nullptr)
        {
            return;
        }
        InOrder(r->left);
        cout << r->val;
        InOrder(r->right);
    }
    void PostOrder(TreeNode *r)
    {
        //* PostOrder -> LRN
        if (r == nullptr)
        {
            return;
        }
        InOrder(r->left);
        InOrder(r->right);
        cout << r->val;
    }
};