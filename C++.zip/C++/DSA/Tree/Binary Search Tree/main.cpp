#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
#include "BST.cpp"
using namespace std;
int main()
{
    TreeNode *t1 = new TreeNode(5);
    BST b1 = BST(t1);
    if (b1.isEmpty())
    {
        cout << "True" << endl;
    }
    else
        cout << "False" << endl;
    return 0;
}