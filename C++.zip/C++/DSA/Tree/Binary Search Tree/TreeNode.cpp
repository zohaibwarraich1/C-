#include <iostream>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *right;
    TreeNode *left;
    TreeNode() : val(0), right(nullptr), left(nullptr) {}
    TreeNode(int val) : val(val), right(nullptr), left(nullptr) {}
    TreeNode(int val, TreeNode *r, TreeNode *l) : val(val), right(r), left(l) {}
    ~TreeNode()
    {
        delete right;
        delete left;
    }
};