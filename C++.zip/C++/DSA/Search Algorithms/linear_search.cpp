#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
int main()
{
    int array[6] = {1, 4, 2, 5, 6, 8};
    int search = 10;
    int size = sizeof(array) / sizeof(array[0]);
    bool found = false;
    for (int i = 0; i < size; i++)
    {
        if (search == array[i])
        {
            cout << "Element found" << endl;
            found = true;
            break;
        }
    }
    if (!found)
    {
        cout << "Element not found" << endl;
    }
    return 0;
}