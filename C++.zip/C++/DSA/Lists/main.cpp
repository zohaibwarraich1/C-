#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include "SinglyLinkedList.cpp"
using namespace std;
int main()
{
    Node n9 = Node();
    Node n1 = Node(1);
    SinglyLinkedList s = SinglyLinkedList(&n1);
    s.display();
    Node n2 = Node(2);
    s.InsertAtLast(&n2);
    s.display();
    Node *n3 = new Node(3);
    s.InsertAtLast(n3);
    s.display();
    Node *n4 = new Node(4);
    s.InsertAtFirst(n4);
    s.display();
    Node *n5 = new Node(5);
    s.InsertNode(2, n5);
    s.display();
    s.deleteNode(2);
    s.display();
    s.deleteNode(10);
    return 0;
}