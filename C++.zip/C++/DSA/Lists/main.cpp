#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include "CircularLinkedList.cpp"
using namespace std;
int main()
{
    cout << "--------------  Singly Linked List  --------------" << endl;
    Node n1 = Node(1);
    SinglyLinkedList s = SinglyLinkedList(&n1);
    s.display();
    Node n2 = Node(2);
    s.InsertAtLast(&n2);
    s.display();
    Node n3 = Node(3);
    s.InsertAtLast(&n3);
    s.display();
    Node n4 = Node(4);
    s.InsertAtFirst(&n4);
    s.display();
    Node n5 = Node(5);
    s.InsertNode(2, &n5);
    s.display();
    s.deleteNode(2);
    s.display();
    s.deleteNode(10);
    cout << "--------------  End  --------------" << endl
         << endl;
    cout << "--------------  Doubly Linked List  --------------" << endl;
    Node n6 = Node(11);
    DoublyLinkedList d = DoublyLinkedList(&n6);
    d.display();
    Node n7 = Node(12);
    d.InsertAtLast(&n7);
    d.display();
    Node n8 = Node(13);
    d.InsertAtLast(&n8);
    d.display();
    Node n9 = Node(14);
    d.InsertAtFirst(&n9);
    d.display();
    Node n10 = Node(15);
    d.InsertNode(7, &n10);
    d.display();
    d.updateNode(7, 22);
    d.display();
    d.deleteNode(7);
    d.display();
    cout << "--------------  End  --------------" << endl
         << endl;
    return 0;
}