#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
class Stack_Linked_list
{
    ListNode *topNode = nullptr;
    int Count = 0;

public:
    bool isEmpty()
    {
        if (topNode == nullptr)
            return true;
        else
            return false;
    }
    void push(ListNode *n)
    {
        if (topNode == nullptr)
        {
            topNode = n;
        }
        else
        {
            n->next = topNode;
            topNode = n;
        }
        Count++;
    }
    int count()
    {
        return Count;
    }
    void pop()
    {
        if (isEmpty())
        {
            cout << "Stack Underflow";
            return;
        }
        else
        {
            ListNode *temp = topNode;
            topNode = topNode->next;
            delete temp; // Free the memory of the popped node
            Count--;
        }
    }
    int top()
    {
        if (isEmpty())
        {
            cout << "Stack Underflow";
            return 0;
        }
        else
        {
            return topNode->val;
        }
    }
};
