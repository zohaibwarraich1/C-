#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include "stack_using_arrays.cpp"
#include "stack_using_linked_list.cpp"
using namespace std;
int main()
{
    Stack s1;
    s1.push(3);
    s1.push(4);
    s1.push(5);
    s1.change(2, 10);
    s1.display();
    cout << endl;
    s1.pop();
    s1.display();
    cout << endl;
    cout << s1.count();
    cout << "\n\n--------------------------------------------------------------------" << endl
         << endl;
    Stack_Linked_list n1;
    ListNode *node1 = new ListNode(1);
    ListNode *node2 = new ListNode(2);
    ListNode *node3 = new ListNode(3);
    n1.push(node1);
    n1.push(node2);
    n1.push(node3);
    cout << n1.count() << endl;
    cout << n1.top() << endl;
    n1.pop();
    cout << n1.top() << endl;
    cout << n1.count() << endl;
    return 0;
}