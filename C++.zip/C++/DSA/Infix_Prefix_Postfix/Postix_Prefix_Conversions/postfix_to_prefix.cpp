#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
string PostToPrefix(string postfix)
{
    stack<string> st;
    for (int i = 0; i < postfix.length(); i++)
    {
        if ((postfix[i] >= 'A' && postfix[i] <= 'Z') || (postfix[i] >= 'a' && postfix[i] <= 'z')) 
        {
            string op;
            op.push_back(postfix[i]);
            st.push(op);
        }
        else
        {
            string op1 = st.top();
            st.pop();
            string op2 = st.top();
            st.pop();
            st.push(postfix[i] + op2 + op1);
        }
    }
    return st.top();
}
int main()
{
    string postfix = "ab+c-def^^*g/";
    cout << PostToPrefix(postfix);
    return 0;
}