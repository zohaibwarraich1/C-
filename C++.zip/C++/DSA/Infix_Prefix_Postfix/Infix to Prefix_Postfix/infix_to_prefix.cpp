#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int precedence(char op)
{
    if (op == '^')
        return 3;
    else if (op == '*' || op == '/')
        return 2;
    else if (op == '+' || op == '-')
        return 1;
    else
        return -1;
}
bool isOperator(char op)
{
    if (op == '+' || op == '-' || op == '*' || op == '/' || op == '^')
        return true;
    else
        return false;
}
string InfixtoPrefix(string infix)
{
    stack<char> stack;
    string prefix;
    reverse(infix.begin(), infix.end());
    for (int i = 0; i < infix.length(); i++)
    {
        if (infix[i] == '(')
            infix[i] = ')';
        else if (infix[i] == ')')
            infix[i] = '(';
    }
    for (int i = 0; i < infix.length(); i++)
    {
        if ((infix[i] >= 'A' && infix[i] <= 'Z') || (infix[i] >= 'a' && infix[i] <= 'z'))
        {
            prefix += infix[i];
        }
        else if (infix[i] == '(')
        {
            stack.push(infix[i]);
        }
        else if (infix[i] == ')')
        {
            while (!stack.empty() && stack.top() != '(')
            {
                prefix += stack.top();
                stack.pop();
            }
            if (stack.top() == '(')
            {
                stack.pop();
            }
        }
        else if (isOperator(infix[i]))
        {
            if (stack.empty())
            {
                stack.push(infix[i]);
            }
            else if (precedence(infix[i]) > precedence(stack.top()))
            {
                stack.push(infix[i]);
            }
            else if (precedence(infix[i]) == precedence(stack.top()) && infix[i] == '^')
            {
                while (!stack.empty() && precedence(infix[i]) == precedence(stack.top()) && infix[i] == '^')
                {
                    prefix += stack.top();
                    stack.pop();
                }
                stack.push(infix[i]);
            }
            else if (precedence(infix[i]) == precedence(stack.top()))
            {
                stack.push(infix[i]);
            }
            else
            {
                while (!stack.empty() && (precedence(infix[i]) < precedence(stack.top())))
                {
                    prefix += stack.top();
                    stack.pop();
                }
                stack.push(infix[i]);
            }
        }
    }
    while (!stack.empty())
    {
        prefix += stack.top();
        stack.pop();
    }
    reverse(prefix.begin(), prefix.end());
    return prefix;
}
int main()
{
    string infix = "((a+b-c)*d^e^f)/g";
    cout << InfixtoPrefix(infix);
    return 0;
}