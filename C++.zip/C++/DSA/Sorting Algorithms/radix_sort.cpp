#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
void CountSort(vector<int> &nums, int div, int size)
{
    int *count = new int[10];
    vector<int> result(size);
    for (int i = 0; i < size; i++)
    {
        count[(nums[i] / div) % 10]++;
    }
    for (int i = 1; i < 10; i++)
    {
        count[i] += count[i - 1];
    }
    for (int i = size - 1; i >= 0; i--)
    {
        result[count[(nums[i] / div) % 10] - 1] = nums[i];
        count[(nums[i] / div) % 10]--;
    }
    for (int i = 0; i < size; i++)
    {
        nums[i] = result[i];
    }
    delete[] count;
}
void RadixSort(vector<int> &nums)
{
    int size = nums.size();
    int max = nums[0];
    for (int i = 1; i < nums.size(); i++)
    {
        if (max < nums[i])
        {
            max = nums[i];
        }
    }
    for (int div = 1; max / div > 0; div *= 10)
    {
        CountSort(nums, div, size);
    }
}
int main()
{
    vector<int> nums = {7941, 8786, 2088, 3510, 1321};
    RadixSort(nums);
    for (int i = 0; i < nums.size(); i++)
    {
        cout << nums[i] << " ";
    }
    return 0;
}