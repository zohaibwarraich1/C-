#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int Partition(vector<int> &nums, int l, int r)
{
    int pivot = nums[r];
    int index = l;
    for (int i = l; i < r; i++)
    {
        if (nums[i] <= pivot)
        {
            swap(nums[i], nums[index]);
            index++;
        }
    }
    swap(nums[index], nums[r]);
    return index;
}
void QuickSort(vector<int> &nums, int l, int r)
{
    if (l < r)
    {
        int p = Partition(nums, l, r);
        QuickSort(nums, l, (p - 1));
        QuickSort(nums, (p + 1), r);
    }
}
int main()
{
    vector<int> nums = {5, 2, 7, 1, 0};
    QuickSort(nums, 0, nums.size() - 1);
    for (auto ele : nums)
    {
        cout << ele << " ";
    }
    return 0;
}