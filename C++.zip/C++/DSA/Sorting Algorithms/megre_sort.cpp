#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
void Merge(vector<int> &nums, int l, int mid, int r)
{
    int i = l;
    int j = mid + 1;
    vector<int> result;
    while (i <= mid && j <= r)
    {
        if (nums[i] >= nums[j])
        {
            result.push_back(nums[j++]);
        }
        else
        {
            result.push_back(nums[i++]);
        }
    }
    while (i <= mid)
    {
        result.push_back(nums[i++]);
    }
    while (j <= r)
    {
        result.push_back(nums[j++]);
    }
    for (int i = l; i <= r; i++)
    {
        nums[i] = result[i - l];
    }
}
void MergeSort(vector<int> &nums, int l, int r)
{
    int mid;
    if (l < r)
    {
        mid = l + (r - l) / 2;
        MergeSort(nums, l, mid);
        MergeSort(nums, mid + 1, r);
        Merge(nums, l, mid, r);
    }
}
int main()
{
    vector<int> nums = {5, 3, 6, 4, 1};
    MergeSort(nums, 0, nums.size() - 1);
    for (auto ele : nums)
    {
        cout << ele << " ";
    }
    return 0;
}