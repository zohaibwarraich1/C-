#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
void BubleSort(vector<int> &arr)
{
    for (int i = 0; i < arr.size(); i++)
    {
        bool isSwap = false;
        for (int j = 0; j < arr.size() - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                isSwap = true;
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
        if (isSwap == false) //! If further swapping in the recent iteration was not done, then it means that the array/list is sorted already, we dont need to further iterate it. So, we break the loop by using this boolean.
        {
            break;
        }
    }
}
int main()
{
    vector<int> arr = {64, 25, 27, 12, 11, 80};
    BubleSort(arr);
    for (int i = 0; i < arr.size(); i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
    return 0;
}