#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include "Circular_Queue.cpp"
#include "Single_Queue.cpp"
using namespace std;
/*
! Both single and circular queue follow:
* First in First out (FIFO) or Last in Last out (LILO) order.
? It means the value that was enqueued(entered) first, will dequeue(remove) first.
*/
int main()
{
    cout << "---------- Circular Queue ----------\n";
    CircularQueue q1 = CircularQueue();
    q1.enqueue(2);
    q1.enqueue(5);
    q1.enqueue(6);
    q1.enqueue(4);
    q1.enqueue(7);
    cout << "Count: " << q1.count() << endl;
    q1.display();
    cout << endl;
    q1.dequeue();
    q1.dequeue();
    cout << "Count: " << q1.count() << endl;
    q1.display();
    cout << endl;
    q1.enqueue(9);
    q1.display();
    cout << endl;
    cout << q1.isFull() << " " << q1.isEmpty();
    cout << "\n---------- Standard Queue ----------\n";
    SingleQueue sq = SingleQueue();
    sq.enqueue(2);
    sq.enqueue(5);
    sq.enqueue(6);
    sq.enqueue(4);
    cout << "Count: " << sq.count() << endl;
    sq.display();
    cout << endl;
    sq.dequeue();
    cout << "Count: " << sq.count() << endl;
    sq.display();
    cout << endl;
    cout << sq.isFull() << " " << sq.isEmpty();
    return 0;
}