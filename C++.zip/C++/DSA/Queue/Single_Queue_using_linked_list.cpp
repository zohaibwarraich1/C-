#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
class Queue_Linked_List
{
private:
    ListNode *front = nullptr;
    ListNode *rear = nullptr;
    int Count = 0;

public:
    bool isEmpty()
    {
        if (this->front == nullptr && this->rear == nullptr)
            return true;
        else
            return false;
    }
    void push_back(ListNode *n)
    {
        if (isEmpty())
        {
            this->rear = n;
            this->front = n;
        }
        else
        {
            this->rear->next = n;
            this->rear = this->rear->next;
        }
        Count++;
    }
    void pop_front()
    {
        if (isEmpty())
        {
            cout << "Stack Underflow";
            return;
        }
        else if (front == rear)
        {
            front = nullptr;
            rear = nullptr;
        }
        else
        {
            ListNode *temp = front;
            this->front = this->front->next;
            delete temp;
        }
        Count--;
    }
    int count()
    {
        return Count;
    }
    int front_value()
    {
        if (isEmpty())
        {
            return 0;
        }
        else
        {
            return this->front->val;
        }
    }
};
