#include <iostream>
using namespace std;
/*
! In this Single queue, the enqueue and dequeue is in the single line.
! Example: If we enqueue 5 numbers.
? The order will be: 2->3->6->8->5
! After that if dequeue one value i.e(2)
? The order will be: 0->3->6->8->5
! Now if we try to again enter the value it will show an error of "The queue is full". Because it is a single queue and once the queue is filled with the last 5th value it wont be able to store further values even if we dequeue one or more time.
*/
class SingleQueue
{
    int array[5];
    int rear;
    int front;
    int valueCount;

public:
    SingleQueue()
    {
        for (int i = 0; i < 5; i++)
        {
            array[i] = 0;
        }
        valueCount = 0;
        rear = -1;
        front = -1;
    }
    bool isEmpty()
    {
        if (rear == -1 && front == -1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    bool isFull()
    {
        if (rear == 4)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    void enqueue(int value)
    {
        if (isFull())
        {
            cout << "Queue is Full" << endl;
        }
        else
        {
            if (isEmpty())
            {
                rear = 0;
                front = 0;
            }
            else
            {
                rear++;
            }
            array[rear] = value;
            valueCount++;
        }
    }
    void dequeue()
    {
        if (isEmpty())
        {
            cout << "Queue is Empty";
        }
        else
        {
            if (front == 0 && rear == 0)
            {
                array[front] = 0;
                front = -1;
                rear = -1;
            }
            else
            {
                array[front] = 0;
                front++;
            }
            valueCount--;
        }
    }
    int count()
    {

        return valueCount;
    }
    void display()
    {
        for (int i = front; i <= rear; i++)
        {
            cout << array[i] << " ";
        }
    }
};