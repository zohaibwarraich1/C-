#include <iostream>
#include <ctime>
#include <cstdlib>
#include <stdlib.h>
#include <unistd.h>
using namespace std;

//! Prototypes //
void game_setup();
void instructions();
void game_starter(const int height, const int width, int snake_x, int snake_y, int fx, int fy, int score, int tailLength, int *pTailX, int *pTailY);
void gettingInput(int &snake_x, int &snake_y, bool &gameOver, int &temp_snake_x, int &temp_snake_y);
void changing_position(int snake_x, int snake_y, int &fx, int &fy, const int height, const int width, int &score, bool &gameOver, int &tailLength, int *pTailX, int *pTailY, int temp_snake_x, int temp_snake_y);
//! Prototypes //

int main()
{
    srand(time(0)); //*Comment 1: to genreate random numbers.
    game_setup(); //* Comment 2: to setup the game and decalre variables to be used in game and to give instructions.
    return 0;
}
void game_setup()
{
    const int height = 20; //* Comment 1: for border height.
    const int width = 20; //* Comment 2: for border width.
    int snake_x = width / 2; //* Comment 3: for snake's position on x-axis.
    int snake_y = height / 2; //* Comment 4: for snake's position on y-axis.
    int fx = rand() % width; //* Comment 5: for fruit's position on x-axis.
    int fy = rand() % height; //* Comment 6: for fruit's position on y-axis.
    bool gameOver = false; //* Comment 7: to check whether the game is over.
    int score = 0; //* Comment 8: to calculate the score.
    int tailLength = 1; //* Comment 9: for snake's tail.
    int *pTailX = new int[100]; //* Comment 10: for snake's tail position on x-axis.
    int *pTailY = new int[100]; //* Comment 11: for snake's tail position on y-axis.
    int store_snake_x = 0; //* Comment 12: to store the snake's current position on x-axis during execution.
    int store_snake_y = 0; //* Comment 13: to store the snake's current position on y-axis during execution.
    instructions(); //* Comment 14: Give instructions to user.
    char input; //* Comment 15: to ask the user if he is ready to play.
    cout << "\nDo you want to start the game? (Y/N): ";
    cin >> input;
    if (input == 'y' || input == 'Y') //* Comment 16: if user is ready to play.
    {
        while (!gameOver) //* Comment 17: to check whether the game is over.
        {
            game_starter(height, width, snake_x, snake_y, fx, fy, score, tailLength, pTailX, pTailY); //* Comment 17.1: to call the function for starting game.
            gettingInput(snake_x, snake_y, gameOver, store_snake_x, store_snake_y); //* Comment 17.2: to call the function for getting indication/direction of snake.
            changing_position(snake_x, snake_y, fx, fy, height, width, score, gameOver, tailLength, pTailX, pTailY, store_snake_x, store_snake_y); //* Comment 17.3: to call the function for changing position of snake.
            usleep(100010); //* Comment 17.4: to call the function for controlling the snake movement.
        }
        cout << "ThankYou for Playing the Game"; //* Comment 17.5: to end the game.
    }
    else //* Comment 18: if user is not ready to play.
    {
        cout << "GOODBYE."; //* Comment 18.1: to end the game.
    }
    delete[] pTailX; //* Comment 19: to delete the dynamically memory allocation for snake's tail position on x-axis.
    delete[] pTailY; //* Comment 20: to delete the dynamically memory allocation for snake's tail position on y-axis.
}
void instructions()
{
    cout << endl;
    cout << "\t\t\t\t\t\t*INSTRUCTIONS TO PLAY THE GAME*" << endl; //* Comment 1: for heading.
    cout << "-> Press 'a' to move 'LEFT' side." << endl; //* Comment 2: for 'a' movement.
    cout << "-> Press 'd' to move 'RIGHT' side." << endl; //* Comment 3: for 'd' movement.
    cout << "-> Press 'w' to move 'UP' side." << endl; //* Comment 4: for 'w' movement.
    cout << "-> Press 's' to move 'DOWN' side." << endl; //* Comment 5: for 's' movement.
    cout << "-> NOTE: To Quit the game anytime. Press 'q'"; //* Comment 6: to quit the game.
}
void game_starter(const int height, const int width, int snake_x, int snake_y, int fx, int fy, int score, int tailLength, int *pTailX, int *pTailY)
{
    system("clear"); //* Comment 1: to clear the terminal for different iterations.
    for (int i = 0; i < width + 2; i++) //* Comment 2: for creating border width.
    {
        cout << "*";
    }
    cout << endl;
    for (int i = 0; i < height; i++) //* Comment 2: for creating header border.
    {
        for (int j = 0; j < width; j++)
        {
            if (j == 0) //* Comment 3: to create the border on left side.
            {
                cout << "*";
            }
            if (i == snake_y && j == snake_x) //* Comment 4: for creating snake's head.
            {
                cout << "zain";
            }
            else if (i == fy && j == fx) //* Comment 5: for creating fruit's position.
            {
                cout << "F";
            }
            else
            {
                bool printSpace = false; //* Comment 6: to check whether to print the empty space or snake's taillength.
                for (int k = 1; k < tailLength; k++) //* Comment 7: to print the snake's tail.
                {
                    if (pTailY[k] == i && pTailX[k] == j) //* Comment 8: for priting snake's tail along its head.
                    {
                        cout << "zain";
                        printSpace = true; //* Comment 9: if snake's tail is to be printed then bool will be true and tail will be printed instead of empty space in that location.
                    }
                }
                if (!printSpace) //* Comment 10: if snake's tail is not printed then empty space will be printed in that location.
                    cout << " ";
            }
            if (j == width - 1) //* Comment 11: for creating right side border.
            {
                cout << "*";
            }
        }
        cout << endl; //* Comment 12: Jump to next line.
    }
    for (int i = 0; i < width + 2; i++) //* Comment 13: for creating footer border.
    {
        cout << "*";
    }
    cout << endl;
    cout << "Score: " << score << endl; //* Comment 14: to display the score.
    cout << "Enter key: "; //* Comment 15: to ask the player to enter key for snake's movement.
}
void gettingInput(int &snake_x, int &snake_y, bool &gameOver, int &temp_snake_x, int &temp_snake_y)
{
    temp_snake_x = snake_x; //* Comment 1: as in game_setup func on 12th comment we decaled it to store the snake's position on x-axis. It will be used to create snake's tail.
    temp_snake_y = snake_y; //* Comment 2: as in game_setup func on 13th comment we decaled it to store the snake's position on y-axis. It will be used to create snake's tail.
    char input;
    cin >> input; //* Comment 3: to ask the user for indication/movement of snake.
    while (!(input == 'a' || input == 'd' || input == 's' || input == 'w' || input == 'q')) //* Comment 4: if user enter any other key than the given one this loop will ask the key again.
    {
        cout << "You entered wrong key: "; //* Comment 4.1: to display that user have entered wrong key.
        cin >> input;
    }
    switch (input) //* Comment 5: it will check the pressed key by user and then change the snake's position.
    {
    case 'a':
        snake_x--; //* Comment 5.1: to move the snake on left side.
        break;
    case 'd':
        snake_x++; //* Comment 5.2: to move the snake on right side.
        break;
    case 'w':
        snake_y--; //* Comment 5.3: to move the snake upward side.
        break;
    case 's':
        snake_y++; //* Comment 5.4: to move the snake downward side.
        break;
    case 'q':
        gameOver = true;  //* Comment 5.5: to finish the game. If user enter 'q'.
        break;
    }
}
void changing_position(int snake_x, int snake_y, int &fx, int &fy, const int height, const int width, int &score, bool &gameOver, int &tailLength, int *pTailX, int *pTailY, int temp_snake_x, int temp_snake_y)
{
    pTailX[0] = temp_snake_x; //* Comment 1: to store the snake's current position on x-axis for creating tail on x-axis.
    pTailY[0] =temp_snake_y; //* Comment 2: to store the snake's current position on y-axis for creating tail on y-axis.
    for (int i = tailLength; i > 0; i--) //* Comment 3: to store the snake's position in array's indexes for creating tail.
    {
        pTailX[i] = pTailX[i - 1]; //* Comment 3.1: to create tail on x-axis.
        pTailY[i] = pTailY[i - 1]; //* Comment 3.2: to create tail on y-axis.
    }
    if (snake_y < 0 || snake_y > height - 1) //* Comment 4: to check whether the snake's head touch the height border and if yes then it will true the gameover.
        gameOver = true;
    if (snake_x < 0 || snake_x > width - 1) //* Comment 5: to check whether the snake's head touch the width border and if yes then it will true the gameover.
        gameOver = true;
    if (snake_x == fx && snake_y == fy) //* Comment 6: to check if snake's head position equals to fruit's positions.
    {
        fx = rand() % width; //* Comment 6.1: to generate new fruit on x-axis using random func.
        fy = rand() % height; //* Comment 6.2: to generate new fruit on y-axis using random func.
        score += 10; //* Comment 6.3: to update the player's score when snake eat the fruit.
        tailLength++; //* Comment 6.4: to increase the length of snake's tail when it eats the fruit.
    }
}