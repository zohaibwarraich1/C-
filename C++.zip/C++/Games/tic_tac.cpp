#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <cctype>
using namespace std;

//! Prototype //
void welcome();
void internal(char board[][3], char player1, char player2);
void matrix_board(char board[][3]);
bool winner(char board[][3], char player_sign);
int main()
{
    welcome();
    cout << endl;
    char board[3][3] = {{' ', ' ', ' '}, {' ', ' ', ' '}, {' ', ' ', ' '}};
    char player_1 = 'X';
    char player_2 = 'O';
    internal(board, player_1, player_2);
}
//* To Welcome the Player
void welcome()
{
    cout << "\nWelcome to Tic Tac Toe!" << endl
         << endl;
    cout << " 1 | 2 | 3 " << endl;
    cout << "---|---|---" << endl;
    cout << " 4 | 5 | 6 " << endl;
    cout << "---|---|---" << endl;
    cout << " 7 | 8 | 9 " << endl;
    cout << "---|---|---" << endl;
}

//* To get the choice of Player
void internal(char board[][3], char player_1, char player_2)
{
    int i;
    for (i = 1; i <= 9; i++)
    {
        int move_player_1;
        int move_player_2;
        if (i == 1 || i % 2 == 1)
        {
            cout << "\nPlayer 1 (X) - Enter your move (1-9): ";
            cin >> move_player_1;
            cout << endl
                 << endl;
            if (move_player_1 != move_player_2 && move_player_1 >= 1 && move_player_1 <= 9)
            {
                if (move_player_1 >= 1 && move_player_1 <= 3)
                {
                    board[0][(move_player_1 - 1)] = player_1;
                    matrix_board(board);
                }
                else if (move_player_1 >= 4 && move_player_1 <= 6)
                {
                    board[1][(move_player_1 - 4)] = player_1;
                    matrix_board(board);
                }
                else if (move_player_1 >= 7 && move_player_1 <= 9)
                {
                    board[2][(move_player_1 - 7)] = player_1;
                    matrix_board(board);
                }
                if (winner(board, player_1))
                {
                    cout << "\nCongratulations! Player 1 have won!\n";
                    break;
                }
            }
            else
            {
                cout << "\nInvalid move!"
                     << "\nPlease try again: ";
                cout << endl;
                i--;
            }
        }
        else if (i == 2 || i % 2 == 0)
        {
            cout << "\nPlayer 2 (O) - Enter your move (1-9): ";
            cin >> move_player_2;
            cout << endl
                 << endl;
            if (move_player_2 != move_player_1 && move_player_2 >= 1 && move_player_2 <= 9)
            {
                if (move_player_2 >= 1 && move_player_2 <= 3)
                {
                    board[0][(move_player_2 - 1)] = player_2;
                    matrix_board(board);
                }
                else if (move_player_2 >= 4 && move_player_2 <= 6)
                {
                    board[1][(move_player_2 - 4)] = player_2;
                    matrix_board(board);
                }
                else if (move_player_2 >= 7 && move_player_2 <= 9)
                {
                    board[2][(move_player_2 - 7)] = player_2;
                    matrix_board(board);
                }
                cout << endl;
                if (winner(board, player_2))
                {
                    cout << "\nCongratulations! Player 2 have won!\n";
                    break;
                }
            }
            else
            {
                cout << "Invalid move!"
                     << "\nPlease try again: ";
                cout << endl;
                i--;
            }
        }
    }
    if (i == 10)
    {
        cout << "\nIt is a draw match\n";
    }
    return;
}

//* To print the tic tac toe Game board
void matrix_board(char board[][3])
{
    system("clear");
    cout << " " << board[0][0] << " | " << board[0][1] << " | " << board[0][2] << endl;
    cout << "---|---|---" << endl;
    cout << " " << board[1][0] << " | " << board[1][1] << " | " << board[1][2] << endl;
    cout << "---|---|---" << endl;
    cout << " " << board[2][0] << " | " << board[2][1] << " | " << board[2][2] << endl;
    cout << "---|---|---" << endl;
}

//* To check the winner
bool winner(char board[][3], char player_sign)
{
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if ((board[i][j] == player_sign && board[i][j + 1] == player_sign && board[i][j + 2] == player_sign))
            {
                return true;
            }
            else if ((board[i][j] == player_sign && board[i + 1][j] == player_sign && board[i + 2][j] == player_sign))
            {
                return true;
            }
            else if ((board[i][j] == player_sign && board[i + 1][j + 1] == player_sign && board[i + 2][j + 2] == player_sign))
            {
                return true;
            }
            else if ((board[i][j + 2] == player_sign && board[i + 1][j + 1] == player_sign && board[i + 2][j] == player_sign))
            {
                return true;
            }
        }
    }
    return false;
}