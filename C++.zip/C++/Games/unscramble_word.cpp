#include <iostream>
#include <ctime>
using namespace std;

//! Prototype //
string *word();

int main()
{
    srand(time(0));
    string *words = word();
    string word = words[rand() % 100];
    string scrambledWord = word;
    random_shuffle(scrambledWord.begin(), scrambledWord.end());
    cout << "Welcome to the Word Scramble Game!\n";
    cout << "Unscramble the word: " << scrambledWord << "\n\n";
    string guess;
    cout << "Your guess: ";
    getline(cin, guess);
    if (guess == word)
    {
        cout << "\nCongratulations! You unscrambled the word correctly. It was " << word << "!\n";
    }
    else
    {
        cout << "\nOops! That's incorrect. The word was " << word << ".\n";
    }
    delete[] words;
    return 0;
}
//* includes list of words //
string *word()
{
    string *words = new string[100];
    words[0] = "computer";
    words[1] = "sciences";
    words[2] = "underrated";
    words[3] = "companion";
    words[4] = "suspicious";
    words[5] = "combinations";
    words[6] = "suspicious";
    words[7] = "vocabulary";
    words[8] = "dictionary";
    words[9] = "preference";
    words[10] = "subsequent";
    words[11] = "feedback";
    words[12] = "workspaces";
    words[13] = "inconvenient";
    words[14] = "ordinary";
    words[15] = "determine";
    words[16] = "verisimilitude";
    words[17] = "consanguineous";
    words[18] = "self-isolating";
    words[19] = "equivocate";
    words[20] = "iconoclast";
    words[21] = "flooded";
    words[22] = "punishment";
    words[23] = "meaning";
    words[24] = "process";
    words[25] = "truculent";
    words[26] = "president";
    words[27] = "physically";
    words[28] = "terminology";
    words[29] = "frigate";
    words[30] = "callipygian";
    words[31] = "confabulate";
    words[32] = "bombilate";
    words[33] = "confusing";
    words[34] = "criteria";
    words[35] = "iconic";
    words[36] = "covalent";
    words[37] = "coherent";
    words[38] = "opaque";
    words[39] = "filtered";
    words[40] = "conscious";
    words[41] = "embraced";
    words[42] = "glorious";
    words[43] = "frightened";
    words[44] = "strangers";
    words[45] = "intriguing";
    words[46] = "insightful";
    words[47] = "noteworthy";
    words[48] = "compelling";
    words[49] = "resonate";
    words[50] = "authentic";
    words[51] = "genuine";
    words[52] = "impactful";
    words[53] = "thoughtful";
    words[54] = "enlightening";
    words[55] = "profound";
    words[56] = "stimulating";
    words[57] = "emotional";
    words[58] = "response";
    words[59] = "influenced";
    words[60] = "simplest";
    words[61] = "definition";
    words[62] = "emotion";
    words[63] = "action";
    words[64] = "copywriters";
    words[65] = "motivate";
    words[67] = "website";
    words[68] = "conversion";
    words[69] = "increase";
    words[70] = "following";
    words[71] = "decrease";
    words[72] = "empathy";
    words[73] = "convey";
    words[74] = "satisfied";
    words[75] = "customer";
    words[76] = "difference";
    words[77] = "between";
    words[78] = "adaptable";
    words[79] = "consistent";
    words[80] = "friendly";
    words[81] = "knowledgeable";
    words[82] = "trustworthy";
    words[83] = "committed";
    words[84] = "attentive";
    words[85] = "encouraging";
    words[86] = "heard";
    words[87] = "assured";
    words[88] = "recommend";
    words[89] = "company";
    words[90] = "content";
    words[91] = "read";
    words[92] = "spark";
    words[93] = "curiosity";
    words[94] = "readers ";
    words[95] = "deeper";
    words[96] = "promise";
    words[97] = "value";
    words[98] = "companion";
    words[99] = "benefits";
    return words;
}