#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <iomanip>
#include <cctype>
#include <string>
using namespace std;

//! Prototype
void welcome();
int cin_check(int guess);
void computer_check(int &computer);
void check(int a, int b);

int main()
{
    srand(time(0));
    cout << endl;
    welcome();
    int guess;
    int computer = rand() % 6;
    computer_check(computer);
    cout << "Enter your guess (1-6): ";
    int cin_temp = cin_check(guess);
    cout << "Rolling the dice..." << endl;
    check(cin_temp, computer);
    return 0;
}
void welcome()
{
    cout << "Welcome to the Dice Rolling Game!" << endl;
    cout << "Let's see if you can guess the outcome of the dice roll." << endl;
}

int cin_check(int guess)
{
    cin >> guess;
    if (!(guess >= 1 && guess <= 6))
    {
        while (!(guess >= 1 && guess <= 6))
        {
            cout << "You entered wrong number: ";
            cin >> guess;
        }
    }
    return guess;
}

void computer_check(int &computer)
{
    if (computer == 0)
    {
        while (computer == 0)
        {
            computer = rand() % 6;
        }
    }
}

void check(int a, int b)
{
    if (a == b)
    {
        cout << "Congratulations! You guessed the correct!" << endl;
    }
    else
    {
        cout << "Oops! The dice rolled a " << b << ". Better luck next time!" << endl;
    }
}