#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <cctype>
using namespace std;

//! Protoypes //
void welcome();
void game_starter(string game_starter);
void question_1(int *counter);
char question_1_answer(char a, int *counter);
void question_2(int *counter);
char question_2_answer(char a, int *counter);
void question_3(int *counter);
char question_3_answer(char a, int *counter);

int main()
{
    welcome();
    string game_starterr;
    cout << "Enter \"START\" to start the Game: ";
    getline(cin, game_starterr);
    cout << endl;
    game_starter(game_starterr);
    string a;
    cout << "\nWant to play again? (Yes/No): ";
    while (cin.get() != '\n');
    getline(cin, a);
    cout << endl;
    do
    {
        if (a == "Y" || a == "y" || a == "Yes" || a == "yes" || a == "YES")
        {
            game_starter(game_starterr);
            cout << "\nWant to play again? (Yes/No): ";
            while (cin.get() != '\n')
                ;
            getline(cin, a);
            cout << endl;
        }
    } while (a == "Y" || a == "y" || a == "Yes" || a == "yes" || a == "YES");
    cout
        << "Thank You!" << endl;
    return 0;
}
//*To Welcome the player //
void welcome()
{
    cout << "\nWelcome to the Quiz Game!" << endl
         << endl;
    cout << "Instructions:" << endl;
    cout << "- Answer each question by entering A, B, C, or D." << endl;
    cout << "- Let's start the Game!" << endl
         << endl;
}

//* To Start the Game //
void game_starter(string game_starter)
{
    if (game_starter == "start" || game_starter == "Start" || game_starter == "START")
    {
        int counter = 0;
        int *counterr = &counter;
        question_1(counterr);
        question_2(counterr);
        question_3(counterr);
        cout << "\nQuiz Completed!";
        cout << "\nYour score: ";
        if (counter == 1)
        {
            cout << counter << "/3" << endl;
            cout << "You need to increase you knowledge! Don't keep it put." << endl;
        }
        else if (counter == 2)
        {
            cout << counter << "/3" << endl;
            cout << "Great! You played well!" << endl;
        }
        else if (counter == 3)
        {
            cout << counter << "/3" << endl;
            cout << "Excellent! You got all the answers right!" << endl;
        }
        return;
    }
    return;
}

//* To ask the First Question //
void question_1(int *counter)
{
    cout << "Question 1:" << endl;
    cout << "What is the capital of France ?" << endl;
    cout << "A) Paris" << endl;
    cout << "B) Rome" << endl;
    cout << "C) Italy" << endl;
    cout << "D) Washington D.C" << endl
         << endl;
    cout << "Your answer (A/B/C/D): ";
    char answer;
    cin >> answer;
    char answer_temp = question_1_answer(answer, counter);
}
char question_1_answer(char a, int *counter)
{
    if (a == 'A' || a == 'a' || a == '1')
    {
        cout << endl
             << "Correct!" << endl
             << endl;
        *counter = *counter + 1;
    }
    else
    {
        cout << endl
             << "Wrong answer!" << endl;
        cout << "The right answer is A: Paris" << endl
             << endl;
    }
}

//* To ask the Second Question //
void question_2(int *counter)
{
    cout << "Question 2:" << endl;
    cout << "Which planet is known as the Red Planet?" << endl;
    cout << "A) Venus" << endl;
    cout << "B) Mars" << endl;
    cout << "C) Jupiter" << endl;
    cout << "D) Saturn" << endl
         << endl;
    cout << "Your answer (A/B/C/D): ";
    char answer;
    cin >> answer;
    char answer_temp = question_2_answer(answer, counter);
}
char question_2_answer(char a, int *counter)
{
    if (a == 'B' || a == 'b' || a == '2')
    {
        *counter = *counter + 1;
        cout << endl
             << "Correct!" << endl
             << endl;
    }
    else
    {
        cout << endl
             << "Wrong answer!" << endl;
        cout << "The right answer is B: Mars" << endl
             << endl;
    }
}

//* To ask the Third Question //
void question_3(int *counter)
{
    cout << "Question 3:" << endl;
    cout << "What is the largest mammal in the world?" << endl;
    cout << "A) African Elephant" << endl;
    cout << "B) Blue Whale" << endl;
    cout << "C) Giraffe" << endl;
    cout << "D) Hippopotamus" << endl
         << endl;
    cout << "Your answer (A/B/C/D): ";
    char answer;
    cin >> answer;
    char answer_temp = question_3_answer(answer, counter);
}
char question_3_answer(char a, int *counter)
{
    if (a == 'B' || a == 'b' || a == '2')
    {
        *counter = *counter + 1;
        cout << endl
             << "Correct!" << endl
             << endl;
    }
    else
    {
        cout << endl
             << "Wrong answer!" << endl;
        cout << "The right answer is B: Blue Whale" << endl
             << endl;
    }
}