#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <cctype>
using namespace std;

//! Prototype //
void welcome();
void computer_choice(int computer);
int convertt(string player_1);
void winner(int a, int b);

//! Enums //
enum player1
{
    rock,
    paper,
    scissor,
};
int main()
{
    srand(time(0));
    welcome();
    string player_1;
    cout << "Enter your choice (Rock, Paper, Scissors): ";
    getline(cin, player_1);
    int player_choice = convertt(player_1);
    int computer;
    computer = rand() % 3;
    computer_choice(computer);
    winner(player_choice, computer);
    return 0;
}

//* To welcome the Player
void welcome()
{
    cout << "Let's play Rock, Paper, Scissors!" << endl;
}

//* To convert the string into number
int convertt(string player_1)
{
    player1 choice;
    for (int i = 0; i < player_1.length(); i++)
    {
        player_1[i] = toupper(player_1[i]);
    }
    if (player_1 == "ROCK")
    {
        choice = rock;
    }
    else if (player_1 == "PAPER")
    {
        choice = paper;
    }
    else if (player_1 == "SCISSORS" || player_1 == "SCISSOR")
    {
        choice = scissor;
    }
    return choice;
}

//* To check the computer's chocie
void computer_choice(int computer)
{
    cout << "Computer chose: ";
    switch (computer)
    {
    case 0:
        cout << "Rock" << endl;
        break;
    case 1:
        cout << "Paper" << endl;
        break;
    case 2:
        cout << "Scissor" << endl;
        break;
    }
}

//* To check the winner
void winner(int a, int b)
{
    if (a == 0 && b == 2 || a == 1 && b == 0 || a == 2 && b == 1)
    {
        cout << "Congratualtions! You win!" << endl;
    }
    else if (a == b)
    {
        cout << "It's draw match!" << endl;
    }
    else
    {
        cout << "You lose! Try again." << endl;
    }
}