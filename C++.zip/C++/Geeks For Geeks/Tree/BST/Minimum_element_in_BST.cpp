#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class Node
{
public:
    int data;
    Node *left;
    Node *right;
    Node() : data(0), left(nullptr), right(nullptr) {}
    Node(int x) : data(x), left(nullptr), right(nullptr) {}
    Node(int x, Node *left, Node *right) : data(x), left(left), right(right) {}
    ~Node()
    {
        delete left;
        delete right;
    }
};
int BinarySearchTree(Node *r, int val)
{
    if (r == nullptr)
    {
        return val;
    }
    else if (r->data <= val)
    {
        val = r->data;
        return BinarySearchTree(r->left, val);
    }
    else
    {
        return BinarySearchTree(r->right, val);
    }
}
int minValue(Node *root)
{
    int min = BinarySearchTree(root, root->data);
    return min;
}
int main()
{
    Node *root = new Node(5);
    Node *l1 = new Node(4);
    Node *l2 = new Node(3);
    Node *l3 = new Node(1);
    Node *r1 = new Node(6);
    Node *r2 = new Node(7);
    root->left = l1;
    root->right = r1;
    l1->left = l2;
    r1->right = r2;
    l2->left = l3;
    cout << minValue(root);
    delete root;
    return 0;
}