#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool validateStackSequences(vector<int> &pushed, vector<int> &popped)
{
    stack<int> st;
    int j = 0;
    for (int i = 0; i < pushed.size();)
    {
        if (!st.empty() && st.top() == popped[j])
        {
            st.pop();
            j++;
            continue;
        }
        if (pushed[i] != popped[j])
        {
            st.push(pushed[i]);
        }
        else if (popped[j] == pushed[i])
        {
            j++;
        }
        i++;
    }
    while (!st.empty())
    {
        if (st.top() != popped[j])
        {
            return false;
        }
        j++;
        st.pop();
    }
    return true;
}
int main()
{
    vector<int> pushed = {1, 2, 3, 4, 5};
    vector<int> popped = {4, 5, 3, 2, 1};
    if (validateStackSequences(pushed, popped))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}