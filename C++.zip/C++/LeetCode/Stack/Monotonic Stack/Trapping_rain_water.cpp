#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int trap(vector<int> &height)
{
    stack<int> s;
    int ans = 0;
    for (int i = 0; i < height.size(); i++)
    {
        while (!s.empty() && height[i] > height[s.top()])
        {
            int top = s.top();
            s.pop();
            if (s.empty())
            {
                break;
            }
            int diff = min(height[i], height[s.top()]) - height[top];
            int distance = i - s.top() - 1;
            ans += distance * diff;
        }
        s.push(i);
    }
    return ans;
}
int main()
{
    vector<int> height = {0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1};
    cout << trap(height);
    return 0;
}