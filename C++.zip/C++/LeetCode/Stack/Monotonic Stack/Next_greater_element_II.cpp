#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
vector<int> nextGreaterElements(vector<int> &nums)
{
    vector<int> arr1(nums.size(), -1);
    stack<int> st;
    //* Double the array to find all next greater elements on right side of current element before pushing it into the vector.
    int size = (2 * nums.size());
    int n = nums.size();
    for (int i = size - 1; i >= 0; i--)
    {
        while (!st.empty() && st.top() <= nums[i % n])
        {
            st.pop();
        }
        if (!st.empty() && i < n)
        {
            arr1[i] = st.top();
        }
        st.push(nums[i % n]);
    }
    return arr1;
}
int main()
{
    vector<int> nums = {1, 2, 1};
    vector<int> result = nextGreaterElements(nums);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}