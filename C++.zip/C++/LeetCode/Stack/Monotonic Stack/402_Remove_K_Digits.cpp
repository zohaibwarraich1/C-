#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
string removeKdigits(string num, int k)
{
    if (num.size() == k)
    {
        return "0";
    }
    stack<char> st;
    int count = 0;
    for (int i = 0; i < num.size(); i++)
    {
        while (!st.empty() && st.top() > num[i] && count < k)
        {
            st.pop();
            count++;
        }
        st.push(num[i]);
    }
    while (count < k && !st.empty())
    {
        st.pop();
        count++;
    }
    string temp;
    while (!st.empty())
    {
        temp += st.top();
        st.pop();
    }
    reverse(temp.begin(), temp.end());
    //* removing leading zeros :<
    int leadingZeroRemovalIndex = 0;
    for (int i = 0; i < temp.size(); i++)
    {
        if (temp[i] == '0')
        {
            leadingZeroRemovalIndex++;
        }
        else
            break;
    }
    string result;
    for (int i = leadingZeroRemovalIndex; i < temp.size(); i++)
    {
        result += temp[i];
    }
    if (result.empty())
        return "0";
    return result;
}
int main()
{
    string nums = "10200";
    cout << removeKdigits(nums, 1);
    return 0;
}