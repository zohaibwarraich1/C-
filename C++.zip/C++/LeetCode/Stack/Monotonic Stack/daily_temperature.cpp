#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
vector<int> dailyTemperatures(vector<int> &temperatures)
{
    stack<int> stTemp;
    vector<int> dailyTemperature;
    int distance;
    for (int i = temperatures.size() - 1; i >= 0; i--)
    {
        distance = 0;
        while (!stTemp.empty() && temperatures[stTemp.top()] <= temperatures[i])
        {
            stTemp.pop();
        }
        if (!stTemp.empty())
        {
            distance = stTemp.top() - i;
        }
        stTemp.push(i);
        dailyTemperature.push_back(distance);
    }
    reverse(dailyTemperature.begin(), dailyTemperature.end());
    return dailyTemperature;
}
int main()
{
    vector<int> temperatures = {30, 40, 50, 60};
    vector<int> result = dailyTemperatures(temperatures);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}