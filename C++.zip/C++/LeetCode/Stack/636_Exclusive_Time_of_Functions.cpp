#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> exclusiveTime(int n, vector<string> &logs)
{
    vector<int> result(n, 0);
    stack<pair<int, int>> st;
    int previousTime = 0;
    for (int i = 0; i < logs.size(); i++)
    {
        stringstream store(logs[i]);
        string token;
        getline(store, token, ':');
        int id = stoi(token);
        getline(store, token, ':');
        string type = token;
        getline(store, token);
        int currentTime = stoi(token);
        if (type == "start")
        {
            if (!st.empty())
            {
                result[st.top().first] += currentTime - previousTime;
            }
            previousTime = currentTime;
            st.push({id, currentTime});
        }
        else
        {
            result[st.top().first] += currentTime - previousTime + 1;
            previousTime = currentTime + 1;
            st.pop();
        }
    }
    return result;
}
int main()
{
    vector<string> logs = {"0:start:0", "1:start:2", "1:end:5", "0:end:6"};
    vector<int> result = exclusiveTime(2, logs);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}