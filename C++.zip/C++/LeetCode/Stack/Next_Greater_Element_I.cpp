#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
vector<int> nextGreaterElement(vector<int> &nums1, vector<int> &nums2)
{
    vector<int> result;
    for (int i = 0; i < nums1.size(); i++)
    {
        for (int j = 0; j < nums2.size(); j++)
        {
            bool foundGreaterElement = false;
            if (nums1[i] == nums2[j])
            {
                for (int k = j; k < nums2.size(); k++)
                {
                    if (nums2[k] > nums2[j])
                    {
                        result.push_back(nums2[k]);
                        foundGreaterElement = true;
                        break;
                    }
                }
                if (foundGreaterElement == false)
                {
                    result.push_back(-1);
                    break;
                }
            }
        }
    }
    return result;
}
int main()
{
    vector<int> nums1 = {2, 4};
    vector<int> nums2 = {1, 2, 3, 4};
    vector<int> result = nextGreaterElement(nums1, nums2);
    for (int i = 0; i < result.size(); i++)
    {
        cout << result[i] << " ";
    }
    return 0;
}