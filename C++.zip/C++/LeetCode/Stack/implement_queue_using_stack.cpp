#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
/*
! Take a queue. While pushing a value, check if the size of that queue if greater than 1 than we use a loop n-1 times and push the front elements into the back of the same queue and then pop it out from front.
* Example: 1,2
* After Loop iteration n-1 times: 2,1
? What Happened: The front element i.e 1. Pushed at the back of queue and then popped out from the front. So, 2 comes on the front and 1 after that.
*/
class MyQueue
{
public:
    deque<int> result;
    MyQueue() {}
    void push(int x)
    {
        result.push_back(x);
        if (result.size() > 1)
        {
            for (int i = 0; i < result.size() - 1; i++)
            {
                result.push_back(result.front());
                result.pop_front();
            }
        }
    }
    int pop()
    {
        int val = top();
        result.pop_front();
        return val;
    }
    int top() { return result.front(); }
    bool empty()
    {
        if (result.empty())
            return true;
        else
            return false;
    }
};
int main()
{
    MyQueue obj = MyQueue();
    obj.push(1);
    obj.push(2);
    obj.push(3);
    cout << obj.pop() << endl;
    cout << obj.top() << endl;
    cout << obj.empty() << endl;
    return 0;
}