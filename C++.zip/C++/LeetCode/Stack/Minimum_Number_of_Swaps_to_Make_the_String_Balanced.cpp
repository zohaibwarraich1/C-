#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int minSwaps(string s)
{
    stack<char> st;
    for (int i = 0; i < s.length(); i++)
    {
        if (!st.empty() && st.top() == '[' && s[i] == ']')
        {
            st.pop();
        }
        else
        {
            st.push(s[i]);
        }
    }
    if (st.empty())
    {
        return 0;
    }
    vector<int> store;
    while (!st.empty())
    {
        store.push_back(st.top());
        st.pop();
    }
    reverse(store.begin(), store.end());
    int n = store.size();
    int count = 0;
    int mid = (n - 1) / 2;
    int l = mid - 1;
    int r = (n - 1) - l;
    while (l >= 0 && r < n)
    {
        count++;
        l = l - 2;
        r = r + 2;
    }
    if (l == -1 && r == n)
    {
        count++;
    }
    return count;
}
int main()
{
    string s = "]]][[[";
    cout << minSwaps(s);
    return 0;
}