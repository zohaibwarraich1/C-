#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
vector<int> asteroidCollision(vector<int> &asteroids)
{
    stack<int> st;
    for (int i = 0; i < asteroids.size(); i++)
    {
        bool isVanished = false;
        while (!st.empty() && asteroids[i] < 0 && st.top() > 0)
        {
            if (abs(asteroids[i]) == st.top())
            {
                st.pop();
                isVanished = true;
                break;
            }
            else if (asteroids[i] + st.top() < 0)
            {
                st.pop();
            }
            else
            {
                isVanished = true;
                break;
            }
        }
        if (isVanished == false)
            st.push(asteroids[i]);
    }
    vector<int> result;
    while (!st.empty())
    {
        result.push_back(st.top());
        st.pop();
    }
    reverse(result.begin(), result.end());
    return result;
}
int main()
{
    vector<int> asteroiods = {-1, 4, 2, -3};
    vector<int> result = asteroidCollision(asteroiods);
    for (auto a : result)
    {
        cout << a << " ";
    }
    return 0;
}