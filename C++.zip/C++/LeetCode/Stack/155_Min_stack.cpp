#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
class MinStack
{
    stack<int> s1;
    stack<int> s2;

public:
    MinStack() {}
    void push(int val)
    {
        s1.push(val);
        if (s2.empty() || val <= s2.top())
        {
            s2.push(val);
        }
    }
    void pop()
    {
        if (s1.top() == s2.top())
        {
            s2.pop();
        }
        s1.pop();
    }
    int top() { return s1.top(); }
    int getMin()
    {
        if (!s2.empty())
            return s2.top();
        return 0;
    }
};
int main()
{
    MinStack m1 = MinStack();
    m1.push(-2);
    m1.push(0);
    m1.push(-3);
    cout << m1.getMin() << endl;
    m1.pop();
    cout << m1.top() << endl;
    cout << m1.getMin() << endl;
    return 0;
}