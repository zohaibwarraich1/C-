#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void insert(TreeNode *&root, TreeNode *newNode)
{
    if (root == nullptr)
    {
        root = newNode;
        return;
    }
    else if (root->val < newNode->val)
    {
        insert(root->right, newNode);
    }
    else if (root->val > newNode->val)
    {
        insert(root->left, newNode);
    }
}
TreeNode *bstFromPreorder(vector<int> &preorder)
{
    TreeNode *root = nullptr;
    for (int i = 0; i < preorder.size(); i++)
    {
        TreeNode *newNode = new TreeNode(preorder[i]);
        insert(root, newNode);
    }
    return root;
}
void InOrder(TreeNode *root)
{
    if (root == nullptr)
    {
        return;
    }
    InOrder(root->left);
    cout << root->val << " ";
    InOrder(root->right);
}
int main()
{
    vector<int> preorder = {8, 5, 1, 7, 10, 12};
    TreeNode *root = bstFromPreorder(preorder);
    InOrder(root);
    return 0;
}