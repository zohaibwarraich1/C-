#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
TreeNode *searchBST(TreeNode *root, int val)
{
    if (root == nullptr || root->val == val)
    {
        return root;
    }
    else if (root->val < val)
    {
        return searchBST(root->right, val);
    }
    else if (root->val > val)
    {
        return searchBST(root->left, val);
    }
    return nullptr;
}
int height(TreeNode *root)
{
    if (root == nullptr)
    {
        return -1;
    }
    else
    {
        int l = height(root->left);
        int r = height(root->right);
        if (l > r)
        {
            return l + 1;
        }
        else
        {
            return r + 1;
        }
    }
}
void PrintLevelOrder(TreeNode *root, int level)
{
    if (root == nullptr)
    {
        return;
    }
    else if (level == 0)
    {
        cout << root->val << " ";
    }
    else
    {
        PrintLevelOrder(root->left, level - 1);
        PrintLevelOrder(root->right, level - 1);
    }
}
void BFS(TreeNode *root)
{
    int h = height(root);
    for (int i = 0; i <= h; i++)
    {
        PrintLevelOrder(root, i);
    }
}
int main()
{
    TreeNode *root = new TreeNode(4);
    root->left = new TreeNode(2);
    root->left->left = new TreeNode(1);
    root->left->right = new TreeNode(3);
    root->right = new TreeNode(7);
    TreeNode *result = searchBST(root, 2);
    BFS(result);
    return 0;
}