#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void PreOrder(TreeNode *r, vector<int> &sortArr)
{
    if (r == nullptr)
    {
        return;
    }
    sortArr.push_back(r->val);
    PreOrder(r->left, sortArr);
    PreOrder(r->right, sortArr);
}
TreeNode *makeBalancedTree(vector<int> &sortArr, int l, int r)
{
    if (l > r)
    {
        return nullptr;
    }
    int mid = l + (r - l) / 2;
    TreeNode *n = new TreeNode(sortArr[mid]);
    n->left = makeBalancedTree(sortArr, l, mid - 1);
    n->right = makeBalancedTree(sortArr, mid + 1, r);
    return n;
}
TreeNode *balanceBST(TreeNode *root)
{
    vector<int> sortArr;
    PreOrder(root, sortArr);
    sort(sortArr.begin(), sortArr.end());
    return makeBalancedTree(sortArr, 0, sortArr.size() - 1);
}
void InOrder(TreeNode *root)
{
    if (root == nullptr)
    {
        return;
    }
    InOrder(root->left);
    cout << root->val << " ";
    InOrder(root->right);
}
int main()
{
    TreeNode *root = new TreeNode(1);
    root->right = new TreeNode(2);
    root->right->right = new TreeNode(3);
    root->right->right->right = new TreeNode(4);
    InOrder(root);
    return 0;
}