#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int minOperations(vector<int> &nums)
{
    int count = 0;
    for (int i = 0; i < nums.size() - 1; i++)
    {
        if (nums[i + 1] <= nums[i])
        {
            int diff = (nums[i] - nums[i + 1]);
            nums[i + 1] += diff + 1;
            count += diff + 1;
        }
    }
    return count;
}
int main()
{
    vector<int> nums = {1, 5, 2, 4, 1};
    cout << minOperations(nums);
    return 0;
}