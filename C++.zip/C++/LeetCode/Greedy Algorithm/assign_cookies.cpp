#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int findContentChildren(vector<int> &g, vector<int> &s)
{
    sort(g.begin(), g.end());
    sort(s.begin(), s.end());
    int gp = 0;
    int sp = 0;
    while (gp < g.size() && sp < s.size())
    {
        if (s[sp] >= g[gp])
        {
            gp++;
            sp++;
        }
        else
        {
            sp++;
        }
    }
    return gp;
}
int main()
{
    vector<int> g = {1, 2, 3};
    vector<int> s = {1, 2};
    cout << findContentChildren(g, s);
    return 0;
}