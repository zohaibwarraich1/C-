#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int smallestDivisor(vector<int> &nums, int threshold)
{
    auto it = max_element(nums.begin(), nums.end());
    int max = *it;
    int l = 1;
    int r = max;
    while (l < r)
    {
        int mid = l + (r - l) / 2;
        int sum = 0;
        for (int i = 0; i < nums.size(); i++)
        {
            if (nums[i] % mid == 0)
            {
                sum += nums[i] / mid;
            }
            else
            {
                sum += (nums[i] / mid) + 1;
            }
        }
        if (sum > threshold)
        {
            l = mid + 1;
        }
        else
        {
            r = mid;
        }
    }
    return r;
}
int main()
{
    vector<int> nums = {7, 8, 9, 10};
    cout << smallestDivisor(nums, 7);
    return 0;
}