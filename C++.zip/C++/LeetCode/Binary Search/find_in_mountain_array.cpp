#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
class MountainArray
{
    vector<int> nums;

public:
    MountainArray(vector<int> n)
    {
        nums = n;
    }
    int get(int index)
    {
        return nums[index];
    }
    int length()
    {
        return nums.size();
    }
};
int peakIndexInMountainArray(MountainArray &mountainArr)
{
    int l = 0;
    int r = mountainArr.length() - 1;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;
        if (l == r)
        {
            break;
        }
        if (mountainArr.get(mid) < mountainArr.get(mid + 1))
        {
            l = mid + 1;
        }
        else
        {
            r = mid;
        }
    }
    return r;
}
int findInMountainArray(int target, MountainArray &mountainArr)
{
    int peak = peakIndexInMountainArray(mountainArr);
    int l = 0;
    int r = peak;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;
        if (mountainArr.get(mid) == target)
        {
            return mid;
        }
        else if (mountainArr.get(mid) < target)
        {
            l = mid + 1;
        }
        else
        {
            r = mid - 1;
        }
    }
    l = peak;
    r = mountainArr.length() - 1;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;
        if (mountainArr.get(mid) == target)
        {
            return mid;
        }
        else if (mountainArr.get(mid) > target)
        {
            l = mid + 1;
        }
        else
        {
            r = mid - 1;
        }
    }
    return -1;
}
int main()
{
    vector<int> nums = {1, 2, 3, 4, 5, 6, 4, 2, 1};
    MountainArray m = MountainArray(nums);
    cout << findInMountainArray(4, m);
    return 0;
}