#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int shipWithinDays(vector<int> &weights, int days)
{
    int l = 0;
    int r = 0;
    for (int i = 0; i < weights.size(); i++)
    {
        r += weights[i];
        if (l < weights[i])
        {
            l = weights[i];
        }
    }
    while (l < r)
    {
        int mid = l + (r - l) / 2;
        int sum = 0;
        int resultDays = 0;
        for (int i = 0; i < weights.size(); i++)
        {
            if (sum + weights[i] == mid)
            {
                resultDays++;
                sum = 0;
                continue;
            }
            else if (sum + weights[i] > mid)
            {
                resultDays++;
                sum = 0;
            }
            sum += weights[i];
        }
        if (0 < sum && sum < mid)
            resultDays++;
        if (resultDays > days)
        {
            l = mid + 1;
        }
        else
        {
            r = mid;
        }
    }
    return l;
}
int main()
{
    vector<int> weights = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    cout << shipWithinDays(weights, 5);
    return 0;
}