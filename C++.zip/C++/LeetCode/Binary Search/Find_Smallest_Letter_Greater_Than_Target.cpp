#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
char nextGreatestLetter(vector<char> &letters, char target)
{
    int l = 0;
    int r = letters.size() - 1;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;
        if (letters[mid] <= target)
        {
            l = mid + 1;
        }
        else
        {
            r = mid - 1;
        }
    }
    if (l >= letters.size())
        return letters[0];
    else
        return letters[l];
}
int main()
{
    vector<char> letters = {'a', 'z'};
    cout << nextGreatestLetter(letters, 'y');
    return 0;
}