#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
bool searchMatrix(vector<vector<int>> &matrix, int target)
{
    if (matrix.empty() || matrix[0].empty())
    {
        return false;
    }
    int cl = 0;
    int cr = matrix.size() - 1;
    while (cl <= cr)
    {
        int mid = cl + (cr - cl) / 2;
        if (matrix[mid][0] == target)
        {
            return true;
        }
        else if (matrix[mid][0] < target)
        {
            cl = mid + 1;
        }
        else
        {
            cr = mid - 1;
        }
    }
    if (cr < 0)
        return false;
    int rl = 0;
    int rc = matrix[0].size() - 1;
    while (rl <= rc)
    {
        int mid = rl + (rc - rl) / 2;
        if (matrix[cr][mid] == target)
        {
            return true;
        }
        else if (matrix[cr][mid] < target)
        {
            rl = mid + 1;
        }
        else
        {
            rc = mid - 1;
        }
    }
    return false;
}
int main()
{
    vector<vector<int>> matrix = {{}, {}, {}};
    if (searchMatrix(matrix, 1))
        cout << "True";
    else
        cout << "False";
    return 0;
}