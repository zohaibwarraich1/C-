#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
/*
 * Given an integer array nums, return an array answer such that answer[i] is equal to the 8 product of all the elements of nums except nums[i].
 * The product of any prefix or suffix of nums is guaranteed to fit in a 32-bit integer.
 * You must write an algorithm that runs in O(n) time and without using the division operation.
 */
//* Prototype
vector<int> productExceptSelf(vector<int> nums);

int main()
{
    vector<int> nums = {0, 2, 3, 7};
    vector<int> result = productExceptSelf(nums);
    for (int i = 0; i < result.size(); i++)
    {
        cout << result[i] << " ";
    }
    return 0;
}
vector<int> productExceptSelf(vector<int> nums)
{
    int zeros = 0;
    for (int i = 0; i < nums.size(); i++)
    {
        if (nums[i] == 0)
            zeros++;
    }
    if (zeros > 1)
    {
        vector<int> zero(nums.size(), 0);
        return zero;
    }
    vector<int> result;
    for (int i = 0; i < nums.size(); i++)
    {
        int product = 1;
        for (int j = 0; j < nums.size(); j++)
        {
            if (nums[i] != nums[j])
            {
                product *= nums[j];
            }
        }
        result.push_back(product);
    }
    return result;
}