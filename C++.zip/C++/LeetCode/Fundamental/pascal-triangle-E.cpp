#include <iostream>
#include <vector>
using namespace std;

//?                             ********** Question *********
//* Write a program to print pascal triangle upto given rows number.

int main()
{
    int rows = 5;
    vector<vector<int>> result;
    for (int i = 0; i < rows; ++i)
    {
        int coefficient = 1;
        vector<int> temp;
        for (int j = 0; j <= i; ++j)
        {
            temp.push_back(coefficient);
            coefficient = coefficient * (i - j) / (j + 1);
        }
        result.push_back(temp);
    }
    for (int i = 0; i < result.size(); i++)
    {
        for (int j = 0; j < result[i].size(); j++)
        {
            cout << result[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}
