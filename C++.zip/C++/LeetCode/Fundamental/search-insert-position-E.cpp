#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//* Given a sorted array of distinct integers and a target value, return the index if the target is found. If not, return the index where it would be if it were inserted in order.

//* Protoype
int searchPosition(vector<int> nums, int target);

int main()
{
    vector<int> nums = {1, 4, 5, 7};
    int target = 8;
    int result = searchPosition(nums, target);
    cout << "The position of " << target << " is index number [" << result << "]";
    return 0;
}
int searchPosition(vector<int> nums, int target)
{
    int n = nums.size();
    if (nums[0] > target)
    {
        return 0;
    }
    if (nums[n - 1] < target)
    {
        return n;
    }
    for (int i = 0; i < n; i++)
    {
        if (nums[i] == target)
        {
            return i;
        }
    }
    for (int i = 1; i < n; i++)
    {
        if (nums[i - 1] < target && nums[i] > target)
        {
            return i;
        }
    }
    return 0;
}