#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//* Prototype
int squares(int n);

int main()
{
    int n = 17;
    cout << squares(n);
    return 0;
}
int squares(int n)
{
    for (int i = 1; i <= n; i++)
    {
        int squareroot = pow(i, 2);
        if (squareroot == n)
        {
            return 1;
        }
        if (squareroot > n)
        {
            break;
        }
    }
    for (int i = 1; i <= n; i++)
    {
        bool exit = false;
        for (int j = 1; j <= i; j++)
        {
            int squareroot = pow(i, 2) + pow(j, 2);
            if (squareroot == n)
            {
                return 2;
            }
            if (squareroot > n)
            {
                exit = true;
                break;
            }
        }
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            for (int k = 1; k <= j; k++)
            {
                int squareroot = pow(i, 2) + pow(j, 2) + pow(k, 2);
                if (squareroot == n)
                {
                    return 3;
                }
            }
        }
    }
    return 4;
}