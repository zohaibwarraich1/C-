#include <iostream>
#include <string>
using namespace std;

//?                             ********** Question *********
//* Write a program to calculate the length of last word in string.

//! Execution time
auto start = chrono::steady_clock::now();

int main()
{
    string s = " Hello World   How     Are you    ";
    int length = 0;
    int space = 0;
    for (int i = s.size() - 1; i > 0; i--)
    {
        if (s[i] == ' ')
        {
            space = i;
            break;
        }
    }
    bool foundWithoutLastSpace = false;
    bool foundWord = false;
    if (space > 0)
    {
        for (int i = space; i < s.size(); i++)
        {
            if (foundWord == false && i == space)
            {
                for (int j = i + 1; j < s.size(); j++)
                {
                    if ((s[j] >= 'A' || s[j] <= 'Z' || s[j] >= 'a' || s[j] <= 'z'))
                    {
                        length++;
                        foundWithoutLastSpace = true;
                        foundWord = true;
                    }
                }
                if (foundWithoutLastSpace == false)
                {
                    for (int k = i - 1; k >= 0; k--)
                    {
                        if (s[k] != ' ')
                        {
                            length++;
                            foundWord = true;
                        }
                        else if (length != 0)
                        {
                            break;
                        }
                    }
                }
            }
        }
    }
    else
    {
        for (int i = 0; i < s.size(); i++)
        {
            if (s[i] != ' ')
            {
                length++;
            }
        }
    }
    cout << "The last word has " << length << " characters of length";

    //! Execution time code //
    cout << "\n";
    auto end = chrono::steady_clock::now();
    auto diff = end - start;
    cout << chrono::duration<double, milli>(diff).count() << " ms" << endl;
    return 0;
}