#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//* Write  program to calculate Max Profit by buying and selling stock.

//* Prototype
int maxProfit(vector<int> prices);

int main()
{
    vector<int> prices = {7, 6, 5, 4, 2, 3, 5, 7, 4, 3, 5, 6, 6, 3, 2, 6, 6, 5, 3, 6, 4, 2};
    int maxprofit = maxProfit(prices);
    cout << maxprofit;
    return 0;
}
int maxProfit(vector<int> prices)
{
    int max = 0;
    for (int i = 0; i < prices.size(); i++)
    {
        int minus = 0;
        for (int j = i + 1; j < prices.size(); j++)
        {
            minus = prices[j] - prices[i];
            if (minus > max)
            {
                max = minus;
            }
        }
    }
    return max;
}