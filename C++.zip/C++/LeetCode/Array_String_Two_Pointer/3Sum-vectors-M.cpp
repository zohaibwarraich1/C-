#include <iostream>
#include <string>
#include <vector>
using namespace std;

//?                             ********** Question *********
//* Create a program that takes Roman Numbers and convert them into Integer number and print the output on console.

//! Execution time code //
auto start = chrono::steady_clock::now();

int main()
{
    vector<vector<int>> temp;
    vector<int> nums = {0, 3, 0, 1, 1, -1, -5, -5, 3, -3, -3, 0};
    for (int i = 0; i < nums.size(); i++)
    {
        cout << nums[i] << " ";
    }
    cout << endl;
    for (int i = 0; i < nums.size(); i++)
    {
        for (int j = i + 1; j < nums.size(); j++)
        {
            for (int k = j + 1; k < nums.size(); k++)
            {
                if (nums[i] + nums[j] + nums[k] == 0)
                {
                    temp.push_back({nums[i], nums[j], nums[k]});
                }
            }
        }
    }
    for (int i = 0; i < temp.size(); i++)
    {
        sort(temp[i].begin(), temp[i].end());
    }
    vector<vector<int>> result;
    for (int i = 0; i < temp.size(); i++)
    {
        bool repeat = false;
        for (int m = i + 1; m < temp.size(); m++)
        {
            if (temp[i] == temp[m])
            {
                repeat = true;
            }
        }
        if (repeat == false)
        {
            result.push_back(temp[i]);
        }
    }
    if (result.empty() == false)
    {
        cout << "Output: ";
        for (int i = 0; i < result.size(); i++)
        {
            cout << "[[";
            for (int j = 0; j < result[i].size(); j++)
            {
                cout << result[i][j] << ",";
            }
            cout << "\b]], ";
        }
        cout << "\b\b";
    }
    else
    {
        cout << "Output: []";
    }

    //! Execution time code //
    cout << "\n";
    auto end = chrono::steady_clock::now();
    auto diff = end - start;
    cout << chrono::duration<double, milli>(diff).count() << " ms" << endl;
    return 0;
}