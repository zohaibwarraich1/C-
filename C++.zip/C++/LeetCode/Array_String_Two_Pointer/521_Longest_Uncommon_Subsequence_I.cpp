#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
int findLUSlength(string a, string b)
{
    if (a == b)
    {
        return -1;
    }
    else if (a.length() > b.length())
    {
        return a.length();
    }
    else
    {
        return b.length();
    }
}
int main()
{
    string s = "aba";
    string r = "cdcr";
    cout << findLUSlength(s, r);
    return 0;
}