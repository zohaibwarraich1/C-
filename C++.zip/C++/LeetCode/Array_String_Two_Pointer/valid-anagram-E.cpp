#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
/*
 * Given two strings s and t, return true if t is an anagram of s, and false otherwise.
 * An Anagram is a word or phrase formed by rearranging the letters of a different word or phrase, typically using all the original letters exactly once.
 */
//* Protoype
bool isAnagaram(string s, string t);
void sorting(string &a);

int main()
{
    string one = "anagram";
    string two = "nagaram";
    if (isAnagaram(one, two))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}
bool isAnagaram(string s, string t)
{
    if (s.size() != t.size())
    {
        return false;
    }
    sorting(s);
    sorting(t);
    for (int i = 0; i < s.size(); i++)
    {
        if (s[i] != t[i])
        {
            return false;
        }
    }
    return true;
}
void sorting(string &a)
{
    int size = a.size();
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (a[i] > a[j])
            {
                char temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
}