#include <iostream>
#include <string>
#include <vector>
#include <stack>
using namespace std;

//?                             ********** Question *********
//* Write a program to calculate the median of an array.

int main()
{
    int num1[] = {1, 4, 5};
    int num2[] = {3};
    int sizeNum1 = sizeof(num1) / sizeof(num1[0]); //* getting size of 1st array
    int sizeNum2 = sizeof(num2) / sizeof(num2[0]); //* getting size of 2nd array
    int num3[sizeNum1 + sizeNum2];                 //* declare a new 3rd array to merge the first 2 arrays
    int m = 0;
    for (int i = 0; i < sizeNum1; i++) //? adding 1st array's elements in 3rd array
    {
        num3[m] = num1[i];
        m++;
    }
    for (int i = 0; i < sizeNum2; i++) //? adding 2nd array's elements in 3rd array
    {
        num3[m] = num2[i];
        m++;
    }
    int sizeNum3 = sizeof(num3) / sizeof(num3[0]); //* getting size of 3rd array
    for (int i = 0; i < sizeNum3; i++)             //? Sorting 3rd array's element to get accurate median
    {
        for (int j = i + 1; j < sizeNum3; j++)
        {
            if (num3[i] > num3[j])
            {
                int temp = num3[i];
                num3[i] = num3[j];
                num3[j] = temp;
            }
        }
    }
    int median = 0;
    bool even = false; //* to check whether the 3rd array has even elements or not
    if (sizeNum3 % 2 == 0)
    {
        median = sizeNum3 / 2;
        even = true;
    }
    else
    {
        median = sizeNum3 / 2 + 1;
        even = false;
    }
    double sum = 0;
    for (int i = median - 1; i <= median; i++) //? getting median of elements
    {
        if (!even)
        {
            sum += num3[i];
            break;
        }
        sum += num3[i];
    }
    if (even) //? if array has even elements then its sum willbe divided on 2 according to median rule
    {
        sum /= 2;
    }
    cout << "The median of sorted arrays is: " << sum;
    return 0;
}