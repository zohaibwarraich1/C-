#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
/*
 * Given an integer n, return true if it is a power of two. Otherwise, return false.
 * An integer n is a power of two, if there exists an integer x such that n == 2x.
 */
//* Protoype
bool isPowerOfTwo(int n);

int main()
{
    int n = 24;
    if (isPowerOfTwo(n))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}
bool isPowerOfTwo(int n)
{
    if (n == 0 || n < 0)
    {
        return false;
    }
    int temp = n;
    for (int i = 0; i < temp; i++)
    {
        if (n == 1)
        {
            break;
        }
        if (n % 2 == 0)
        {
            n = n / 2;
        }
        else
        {
            return false;
        }
    }
    return true;
}