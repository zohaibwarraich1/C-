#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
/*
 * Given an unsorted array of integers nums, return the length of the longest consecutive elements sequence.
 * You must write an algorithm that runs in O(n) time.
 */
//* Prototype
int longestConsectiveNum(vector<int> nums);

int main()
{
    vector<int> nums = {100, 4, 200, 2, 1, 3};
    cout << longestConsectiveNum(nums);
    return 0;
}
int longestConsectiveNum(vector<int> nums)
{
    if (nums.size() == 0)
    {
        return 0;
    }
    sort(nums.begin(), nums.end());
    int longestStreak = 1;
    int currentStreak = 1;
    for (int i = 1; i < nums.size(); i++)
    {
        if (nums[i] != nums[i - 1])
        {
            if (nums[i] == nums[i - 1] + 1)
            {
                currentStreak++;
            }
            else
            {
                longestStreak = max(longestStreak, currentStreak);
                currentStreak = 1;
            }
        }
    }
    return max(longestStreak, currentStreak);
}