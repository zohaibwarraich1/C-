#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
/*
 * Given a triangle array, return the minimum path sum from top to bottom.
 * For each step, you may move to an adjacent number of the row below. More formally, if you are on index i on the current row, you may move to either index i or index i + 1 on the next row.
 */
//* Protoype
int minimumTotal(vector<vector<int>> triangle);

int main()
{
    vector<vector<int>> triangle;
    triangle.push_back({-1});
    triangle.push_back({2, 3});
    triangle.push_back({1, -1, -3});
    triangle.push_back({4, 1, 8, 3});
    cout << minimumTotal(triangle);
    return 0;
}
int minimumTotal(vector<vector<int>> triangle)
{
    int sum = 0;
    int m = 0;
    int num = 0;
    for (int i = 0; i < triangle.size(); i++)
    {
        num = triangle[i][m];
        if (num > triangle[i][m + 1] && i > 0)
        {
            cout << triangle[i][m + 1] << endl;
            num = triangle[i][m + 1];
            m++;
        }
        sum += num;
    }
    return sum;
}