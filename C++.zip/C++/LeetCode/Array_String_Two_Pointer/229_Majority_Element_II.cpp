#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
vector<int> majorityElement(vector<int> &nums)
{
    vector<int> result;
    int times = nums.size() / 3;
    int count = 0;
    sort(nums.begin(), nums.end());
    int n;
    for (int i = 0; i < nums.size(); i = n)
    {
        count = 1;
        n = i + 1;
        while (n < nums.size() && nums[i] == nums[n])
        {
            count++;
            n++;
        }
        if (count > times)
        {
            result.push_back(nums[i]);
        }
    }
    return result;
}
int main()
{
    vector<int> nums = {3, 2, 3};
    vector<int> result = majorityElement(nums);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}