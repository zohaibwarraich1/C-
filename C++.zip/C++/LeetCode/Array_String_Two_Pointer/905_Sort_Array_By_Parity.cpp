#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
vector<int> sortArrayByParityII(vector<int> &nums)
{
    vector<int> result(nums.size());
    int l = 0;
    int r = nums.size() - 1;
    while (l < r)
    {
        if (nums[l] % 2 != 0 && nums[r] % 2 == 0)
        {
            swap(nums[l], nums[r]);
            l++;
            r--;
        }
        else if (nums[l] % 2 == 0 && nums[r] % 2 == 0)
        {
            l++;
        }
        else
        {
            r--;
        }
    }
    return nums;
}
int main()
{
    vector<int> nums = {4, 2, 5, 7};
    vector<int> result = sortArrayByParityII(nums);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}