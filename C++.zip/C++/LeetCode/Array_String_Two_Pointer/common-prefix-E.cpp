#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//* Write a function to find the longest common prefix string amongst an array of strings. If there is no common prefix, return an empty string "".

//* Prototype
string commonPrefix(vector<string> input);

int main()
{
    vector<string> input{"flower", "flow", "flight"};
    string result = commonPrefix(input);
    cout << "\"" << result << "\"";
    return 0;
}
string commonPrefix(vector<string> input)
{
    string result;
    int m = 0;
    for (int i = 0; i < input[0].size(); i++)
    {
        int temp = 1;
        for (int j = 1; j < input.size(); j++)
        {
            if (input[0][m] == input[j][m])
            {
                temp++;
            }
            else
            {
                break;
            }
        }
        if (temp == input.size())
        {
            result += input[0][m];
            m++;
        }
    }
    return result;
}