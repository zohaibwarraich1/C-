#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//* Write a program to move zeroes to left side.

int main()
{
    vector<int> nums = {1, 0, 5, 1, 1, 0, 6};
    int m = 0;
    for (int i = 0; i < nums.size(); i++)
    {
        if (nums[i] != 0)
        {
            int temp = nums[i];
            nums[i] = nums[m];
            nums[m] = temp;
            m++;
        }
    }
    for (int elem : nums)
    {
        cout << elem << " ";
    }
    return 0;
}