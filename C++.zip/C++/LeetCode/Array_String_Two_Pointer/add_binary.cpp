#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
string addBinary(string a, string b)
{
    string result;
    int as = a.length() - 1;
    int bs = b.length() - 1;
    int carry = 0;
    int sum = 0;
    while (as >= 0 || bs >= 0)
    {
        sum = carry;
        if (as >= 0)
        {
            sum += a[as] - '0';
        }
        if (bs >= 0)
        {
            sum += b[bs] - '0';
        }
        result += to_string(sum % 2);
        carry = sum / 2;
        as--;
        bs--;
    }
    if (carry == 1)
    {
        result += "1";
    }
    reverse(result.begin(), result.end());
    return result;
}
int main()
{
    string a = "1010";
    string b = "1011";
    cout << addBinary(a, b);
    return 0;
}