#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
string addStrings(string num1, string num2)
{
    int sum = 0;
    int carry = 0;
    int n1 = num1.length() - 1;
    int n2 = num2.length() - 1;
    string result = "";
    while (n1 >= 0 || n2 >= 0)
    {
        sum = carry;
        if (n1 >= 0)
        {
            sum += num1[n1] - '0';
        }
        if (n2 >= 0)
        {
            sum += num2[n2] - '0';
        }
        result += to_string(sum % 10);
        carry = sum / 10;
        n1--;
        n2--;
    }
    if (carry > 0)
    {
        result += to_string(carry);
    }
    reverse(result.begin(), result.end());
    return result;
}
int main()
{
    cout << addStrings("11", "123");
    return 0;
}