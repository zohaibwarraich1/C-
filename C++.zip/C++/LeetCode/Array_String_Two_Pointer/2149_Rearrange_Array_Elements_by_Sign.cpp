#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
vector<int> rearrangeArray(vector<int> &nums)
{
    vector<int> result(nums.size());
    int p1 = 0;
    int p2 = 1;
    for (int i = 0; i < nums.size(); i++)
    {
        if (nums[i] >= 0)
        {
            result[p1] = nums[i];
            p1 += 2;
        }
        else
        {
            result[p2] = nums[i];
            p2 += 2;
        }
    }
    return result;
}
int main()
{
    vector<int> nums = {3, 1, -2, -5, 2, -4};
    vector<int> result = rearrangeArray(nums);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}