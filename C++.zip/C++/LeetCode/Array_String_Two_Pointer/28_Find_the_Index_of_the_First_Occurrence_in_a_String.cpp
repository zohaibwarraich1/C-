#include <iostream>
#include <string>
using namespace std;

//?                             ********** Question *********
//* Write a program to find a substring in string at first occurence and print the index on console.

int main()
{
    string haystack = "baabbbbababbbabab";
    string needle = "abbab";
    int occurence = -1;
    int m = 0;
    for (int i = 0; i < haystack.size(); i++)
    {
        bool found = false;
        if (haystack[i] == needle[m])
        {
            found = true;
            for (int j = 0; j < needle.size(); j++)
            {
                if (haystack[i + j] != needle[j])
                {
                    found = false;
                    break;
                }
            }
        }
        if (found)
        {
            occurence = i;
            break;
        }
    }
    cout << "First occurence of string is: " << occurence;
    return 0;
}