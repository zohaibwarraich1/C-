#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//* Given an integer array nums, return true if any value appears at least twice in the array, and return false if every element is distinct.

//* Prototype
bool duplicate(vector<int> nums);

int main()
{
    vector<int> nums = {1, 2, 3, 6, 8, 4, 6};
    if (duplicate(nums))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}
bool duplicate(vector<int> nums)
{
    sort(nums.begin(), nums.end());
    for (int i = 0; i < nums.size(); i++)
    {
        if (nums[i] == nums[i + 1])
        {
            return true;
        }
    }
    return false;
}