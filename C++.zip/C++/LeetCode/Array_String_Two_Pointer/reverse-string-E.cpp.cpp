#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//* Write a function that reverses a string. The input string is given as an array of characters s.

int main()
{
    string s = "helloo";
    int m = s.size() - 1;
    for (int i = 0; i < s.size() / 2; i++)
    {
        char temp = s[i];
        s[i] = s[m];
        s[m] = temp;
        m--;
    }
    cout << s;
    return 0;
}