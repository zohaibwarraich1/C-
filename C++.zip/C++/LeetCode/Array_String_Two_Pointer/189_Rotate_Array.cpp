#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
void Reverse(vector<int> &nums, int l, int r)
{
    int s = l;
    int e = r;
    while (s < e)
    {
        swap(nums[s], nums[e]);
        s++;
        e--;
    }
}
void rotate(vector<int> &nums, int k)
{
    k = k % nums.size();
    int firstHalf = nums.size() - k;
    Reverse(nums, 0, firstHalf - 1);
    Reverse(nums, firstHalf, nums.size() - 1);
    Reverse(nums, 0, nums.size() - 1);
}
int main()
{
    vector<int> nums = {1, 2, 3, 4, 5, 6, 7};
    rotate(nums, 3);
    for (auto ele : nums)
    {
        cout << ele << " ";
    }
    return 0;
}