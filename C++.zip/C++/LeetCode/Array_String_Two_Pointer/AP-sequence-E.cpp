#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
/*
 * Given an array of numbers, return true if the array can be rearranged to form an arithmetic progression. Otherwise, return false.
 * Input: arr = [3,5,1]
 * Output: true
 * Explanation: We can reorder the elements as [1,3,5] or [5,3,1] with differences 2 and -2 respectively, between each consecutive elements.
 */
//! Protoype
bool canMakeArithmeticProgression(vector<int> &arr);

int main()
{
    vector<int> nums = {2, 4, 6, 9};
    bool result = canMakeArithmeticProgression(nums);
    if (result)
    {
        cout << "true";
    }
    else
    {
        cout << "false";
    }
    return 0;
}
bool canMakeArithmeticProgression(vector<int> &nums)
{
    for (int i = 0; i < nums.size(); i++)
    {
        for (int j = i + 1; j < nums.size(); j++)
        {
            if (nums[i] < nums[j])
            {
                int temp = nums[i];
                nums[i] = nums[j];
                nums[j] = temp;
            }
        }
    }
    int diff = nums[0] - nums[1];
    for (int i = 0; i < nums.size() - 1; i++)
    {
        if (nums[i] - nums[i + 1] != diff)
        {
            return false;
        }
    }
    return true;
}