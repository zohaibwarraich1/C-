#include <iostream>
#include <stack>
using namespace std;

//?                             ********** Question *********
//* Write a program to find valid paranthesis.

int main()
{
    string s = "[()]";
    vector<char> brackets;
    int m = -1;
    for (int i = 0; i < s.size(); ++i)
    {
        if (s[i] == ')' || s[i] == ']' || s[i] == '}')
        {
            if (brackets.empty())
            {
                cout << "False";
                return 0;
            }
            char openingBracket = brackets[m];
            brackets.pop_back();
            m--;
            if ((s[i] == ')' && openingBracket != '(') || (s[i] == ']' && openingBracket != '[') || (s[i] == '}' && openingBracket != '{'))
            {
                cout << "False";
                return 0;
            }
        }
        else
        {
            brackets.push_back(s[i]); //! m=1
            m++;
        }
    }
    if (brackets.empty())
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}
