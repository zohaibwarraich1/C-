#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int maxArea(vector<int> &height)
{
    int p1 = 0;
    int p2 = height.size() - 1;
    int area = 0;
    int tempArea = 0;
    while (p1 < p2)
    {
        if (height[p1] > height[p2])
        {
            tempArea = height[p2] * (p2 - p1);
            p2--;
        }
        else
        {
            tempArea = height[p1] * (p2 - p1);
            p1++;
        }
        if (tempArea > area)
        {
            area = tempArea;
        }
    }
    return area;
}
int main()
{
    vector<int> height = {1, 8, 6, 2, 5, 4, 8, 3, 7};
    cout << maxArea(height);
    return 0;
}