#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
int addDigits(int num)
{
    while (num >= 10)
    {
        int tempNum = num;
        int sum = 0;
        while (tempNum)
        {
            sum += (tempNum % 10);
            tempNum /= 10;
        }
        num = sum;
    }
    return num;
}
int main()
{
    int num = 39;
    cout << addDigits(num);
    return 0;
}