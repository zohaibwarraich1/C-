#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
/*
 * Given a non-empty array of integers nums, every element appears twice except for one. Find that single one.
 * Hint: XOR of two same integers = 0.
 */
//* Protoype
int singleNumber(vector<int> nums);

int main()
{
    vector<int> nums = {1, 2, 4, 2, 4};
    int num = singleNumber(nums);
    cout << num;
    return 0;
}
int singleNumber(vector<int> nums)
{
    int num = 0;
    for (int i = 0; i < nums.size(); i++)
    {
        num = num ^ nums[i];
    }
    return num;
}