#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
int removeElement(vector<int> &nums, int val)
{
    int count = 0;
    vector<int> result;
    for (int i = 0; i < nums.size(); i++)
    {
        if (nums[i] != val)
        {
            result.push_back(nums[i]);
            count++;
        }
    }
    nums.clear();
    nums = result;
    return count;
}
int main()
{
    vector<int> nums = {0, 1, 2, 2, 3, 0, 4, 2};
    int count = removeElement(nums, 2);
    cout << count << ", nums: [";
    for (int i = 0; i < nums.size(); i++)
    {
        cout << nums[i] << ",";
    }
    cout << "\b]";
    return 0;
}