#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
bool isSubsequence(string s, string t)
{
    int p1 = 0;
    int p2 = 0;
    while (p1 < s.length())
    {
        bool found = false;
        while (p2 < t.length())
        {
            if (s[p1] == t[p2])
            {
                found = true;
                break;
            }
            else
                p2++;
        }
        if (found == false)
        {
            return false;
        }
        p1++;
        p2++;
    }
    return true;
}
int main()
{
    string s = "abc";
    string r = "akbgcjk";
    if (isSubsequence(s, r))
    {
        cout << "True";
    }
    else
        cout << "False";
    return 0;
}