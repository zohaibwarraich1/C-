#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
/*
 * You are given two integer arrays nums1 and nums2, sorted in non-decreasing order, and two integers m and n, representing the number of elements in nums1 and nums2 respectively.
 * Merge nums1 and nums2 into a single array sorted in non-decreasing order.
 */
//* Prototype
void merge(vector<int> nums1, int m, vector<int> nums2, int n);

int main()
{
    vector<int> nums1 = {1};
    int m = 1;
    vector<int> nums2 = {2};
    int n = 0;
    merge(nums1, m, nums2, n);
    return 0;
}
void merge(vector<int> nums1, int m, vector<int> nums2, int n)
{
    vector<int> nums3;
    for (int i = 0; i < m; i++)
    {
        nums3.push_back(nums1[i]);
    }
    for (int i = 0; i < n; i++)
    {
        nums3.push_back(nums2[i]);
    }
    sort(nums3.begin(), nums3.end());
    cout << "[";
    for (int i = 0; i < nums3.size(); i++)
    {
        cout << nums3[i] << ",";
    }
    cout << "\b]";
}