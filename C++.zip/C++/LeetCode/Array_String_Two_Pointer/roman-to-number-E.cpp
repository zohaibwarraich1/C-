#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//*  Create a program that takes Roman Numbers and convert them into Integer number and print the output on console.

//* Protoype
int romanSum(string a);

int main()
{
    string s;
    cout << "Enter a Roman Value: ";
    getline(cin, s);
    cout << "Output is: " << romanSum(s);
    return 0;
}
int romanSum(string a)
{
    int last = 0;
    int recent = 0;
    int sum = 0;
    for (int i = a.size() - 1; i >= 0; i--)
    {
        if (a[i] == 'I')
            last = 1;
        else if (a[i] == 'V')
            last = 5;
        else if (a[i] == 'X')
            last = 10;
        else if (a[i] == 'L')
            last = 50;
        else if (a[i] == 'C')
            last = 100;
        else if (a[i] == 'D')
            last = 500;
        else if (a[i] == 'M')
            last = 1000;
        if (last < recent)
        {
            sum -= last;
        }
        else if (last > recent || last == recent)
        {
            sum += last;
        }
        recent = last;
    }
    return sum;
}