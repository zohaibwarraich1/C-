#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
/*
 *An ugly number is a positive integer whose prime factors are limited to 2, 3, and 5.
 *Given an integer n, return true if n is an ugly number.
 */
//* Prototype
bool uglyNumber(int n);
int main()
{
    int num = 1;
    if (uglyNumber(num))
        cout << "True";
    else
        cout << "False";
    return 0;
}
bool uglyNumber(int n)
{
    while (n > 1)
    {
        if (n % 2 == 0)
            n = n / 2;
        else if (n % 3 == 0)
            n = n / 3;
        else if (n % 5 == 0)
            n = n / 5;
        else
            break;
    }
    if (n == 1)
        return true;
    return false;
}