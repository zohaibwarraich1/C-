#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
ListNode *getIntersectionNode(ListNode *headA, ListNode *headB)
{
    set<ListNode *> nodesInA;
    ListNode *tempA = headA;
    while (tempA != nullptr)
    {
        nodesInA.insert(tempA);
        tempA = tempA->next;
    }
    ListNode *tempB = headB;
    while (tempB != nullptr)
    {
        if (nodesInA.find(tempB) != nodesInA.end())
        {
            return tempB;
        }
        tempB = tempB->next;
    }
    return nullptr;
}
void print(ListNode *head)
{
    ListNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val;
        if (temp->next != nullptr)
            cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}
int main()
{
    ListNode a4 = ListNode(5);
    ListNode a3 = ListNode(4, &a4);
    ListNode a2 = ListNode(8, &a3);
    ListNode a1 = ListNode(1, &a2);
    ListNode listA = ListNode(4, &a1);

    ListNode b2 = ListNode(1, &a2);
    ListNode b1 = ListNode(6, &b2);
    ListNode listB = ListNode(5, &b1);

    ListNode *result = getIntersectionNode(&listA, &listB);
    cout << "Intersected at: " << result->val;
    return 0;
}