#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
ListNode *removeNodes(ListNode *head)
{
    stack<ListNode *> list;
    ListNode *temp = head;
    while (temp != nullptr)
    {
        while (!list.empty() && temp->val > list.top()->val)
        {
            list.pop();
        }
        if (list.empty() == false)
            list.top()->next = temp;
        list.push(temp);
        temp = temp->next;
        list.top()->next = nullptr;
    }
    ListNode *temp2 = nullptr;
    while (!list.empty())
    {
        list.top()->next = temp2;
        temp2 = list.top();
        list.pop();
    }
    return temp2;
}
void print(ListNode *head)
{
    ListNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val;
        if (temp->next != nullptr)
            cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}
int main()
{
    ListNode n4 = ListNode(8);
    ListNode n3 = ListNode(3, &n4);
    ListNode n2 = ListNode(13, &n3);
    ListNode n1 = ListNode(2, &n2);
    ListNode head = ListNode(5, &n1);
    ListNode *result = removeNodes(&head);
    print(result);
    return 0;
}