#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
ListNode *removeNthFromEnd(ListNode *head, int n)
{
    if (head->next == nullptr)
    {
        return nullptr;
    }
    int count = 0;
    ListNode *temp = head;
    while (temp != nullptr)
    {
        temp = temp->next;
        count++;
    }
    if (n < count)
    {
        int remaining = count - n;
        int countTemp = 1;
        ListNode *prev = head;
        ListNode *curr = head->next;
        while (countTemp < remaining)
        {
            prev = prev->next;
            curr = curr->next;
            countTemp++;
        }
        if (curr != nullptr && curr->next != nullptr)
            prev->next = curr->next;
        else
            prev->next = nullptr;
    }
    else if (count == n)
    {
        head = head->next;
    }
    else
    {
        head = nullptr;
    }
    return head;
}
void print(ListNode *head)
{
    ListNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val;
        if (temp->next != nullptr)
            cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}
int main()
{
    ListNode n4 = ListNode(5);
    ListNode n3 = ListNode(4, &n4);
    ListNode n2 = ListNode(3, &n3);
    ListNode n1 = ListNode(2, &n2);
    ListNode head = ListNode(1, &n1);
    ListNode *result = removeNthFromEnd(&head, 2);
    print(result);
    return 0;
}