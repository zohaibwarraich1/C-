#include <iostream>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
class Solution
{
public:
    ListNode *deleteDuplicates(ListNode *head)
    {
        if (head == nullptr)
            return nullptr;

        ListNode *prev = head;
        ListNode *current = head->next;

        while (current != nullptr)
        {
            if (prev->val != current->val)
            {
                prev->next = current;
                prev = current;
            }
            current = current->next;
        }
        prev->next = current;
        prev = current;
        return head;
    }
};
void print(ListNode *head)
{
    ListNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val;
        if (temp->next != nullptr)
        {
            cout << " -> ";
        }
        temp = temp->next;
    }
    cout << endl;
}
int main()
{
    ListNode n4 = ListNode(1);
    ListNode n3 = ListNode(4, &n4);
    ListNode n2 = ListNode(1, &n3);
    ListNode head = ListNode(2, &n2);
    Solution s = Solution();
    s.deleteDuplicates(&head);
    print(&head);
}