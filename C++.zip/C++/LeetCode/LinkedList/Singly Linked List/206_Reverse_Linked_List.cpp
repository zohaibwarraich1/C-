#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
ListNode *reverseList(ListNode *head)
{
    if (head->next == nullptr || head == nullptr)
    {
        return head;
    }
    ListNode *prev_2x = nullptr;
    ListNode *prev = head;
    ListNode *next_to_prev = head->next;
    while (next_to_prev->next != nullptr)
    {
        prev->next = prev_2x;
        prev_2x = prev;
        prev = next_to_prev;
        next_to_prev = next_to_prev->next;
    }
    prev->next = prev_2x;
    prev_2x = prev;
    prev = next_to_prev;
    next_to_prev = next_to_prev->next;
    prev->next = prev_2x;
    return prev;
}
void print(ListNode *head)
{
    ListNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val;
        if (temp->next != nullptr)
            cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}
int main()
{
    ListNode n4 = ListNode(5);
    ListNode n3 = ListNode(4, &n4);
    ListNode n2 = ListNode(3, &n3);
    ListNode n1 = ListNode(2, &n2);
    ListNode head = ListNode(1, &n1);
    ListNode *result = reverseList(&head);
    print(result);
    return 0;
}