#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
using namespace std::chrono;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
bool isPalindrome(ListNode *head)
{
    if (head == nullptr || head->next == nullptr)
        return true;
    ListNode *first = head;
    ListNode *sec = head;
    while (sec->next != nullptr && sec->next->next != nullptr)
    {
        first = first->next;
        sec = sec->next->next;
    }
    ListNode *prev = nullptr;
    while (first != nullptr)
    {
        ListNode *temp = first->next;
        first->next = prev; 
        prev = first;
        first = temp;
    }
    ListNode *firstHalf = head;
    ListNode *secHalf = prev;
    while (firstHalf != nullptr)
    {
        if (firstHalf->val != secHalf->val)
        {
            return false;
        }
        else
        {
            firstHalf = firstHalf->next;
            secHalf = secHalf->next;
        }
    }

    return true;
}
int main()
{
    ListNode n4 = ListNode(1);
    ListNode n3 = ListNode(2, &n4);
    ListNode n2 = ListNode(3, &n3);
    ListNode n1 = ListNode(2, &n2);
    ListNode head = ListNode(1, &n1);
    bool result = isPalindrome(&head);
    if (result)
        cout << "True" << endl;
    else
        cout << "False" << endl;
    return 0;
}
