#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
ListNode *addTwoNumbers(ListNode *l1, ListNode *l2)
{
    int sum = 0;
    int carry = 0;
    ListNode dummy(0);
    ListNode *point = &dummy;
    while (l1 != nullptr || l2 != nullptr)
    {
        sum = carry;
        if (l1 != nullptr)
        {
            sum += l1->val;
            l1 = l1->next;
        }
        if (l2 != nullptr)
        {
            sum += l2->val;
            l2 = l2->next;
        }
        carry = sum / 10;
        ListNode *store = new ListNode(sum % 10);
        point->next = store;
        point = point->next;
    }
    if (carry > 0)
    {
        ListNode *store = new ListNode(carry);
        point->next = store;
        point = point->next;
    }
    return dummy.next;
}
void print(ListNode *head)
{
    ListNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val;
        if (temp->next != nullptr)
            cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}
int main()
{
    ListNode n2 = ListNode(3);
    ListNode n1 = ListNode(4, &n2);
    ListNode l1 = ListNode(2, &n1);

    ListNode n4 = ListNode(4);
    ListNode n3 = ListNode(6, &n4);
    ListNode l2 = ListNode(5, &n3);
    ListNode *result = addTwoNumbers(&l1, &l2);
    print(result);
    return 0;
}