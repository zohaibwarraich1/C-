#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int minOperations(vector<int> &nums)
{
    int k = 3; //? --> Window Size
    int flips = 0;
    for (int i = 0; i < nums.size() - 2; i++)
    {
        if (nums[i] == 1)
        {
            continue;
        }
        for (int j = i; j < i + k; j++)
        {
            if (nums[j] == 0)
            {
                nums[j] = 1;
            }
            else
            {
                nums[j] = 0;
            }
        }
        flips++;
    }
    if (nums[nums.size() - 1] == 1 && nums[nums.size() - 2] == 1)
        return flips;
    else
        return -1;
}
int main()
{
    vector<int> nums = {0, 1, 1, 1, 0, 0};
    cout << minOperations(nums);
    return 0;
}