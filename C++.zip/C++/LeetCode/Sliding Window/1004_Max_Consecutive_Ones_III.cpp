#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int longestOnes(vector<int> &nums, int k)
{
    int s = 0;
    int e = 0;
    int Max = INT_MIN;
    int tempK = 0;
    while (e < nums.size())
    {
        if (nums[e] == 1)
        {
            e++;
        }
        else if (nums[e] == 0 && tempK < k)
        {
            e++;
            tempK++;
        }
        else
        {
            while (tempK >= k)
            {
                if (nums[s] == 0)
                {
                    s++;
                    tempK--;
                }
                else
                    s++;
            }
        }
        Max = max(Max, e - s);
    }
    return Max;
}
int main()
{
    vector<int> nums = {1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0};
    cout << longestOnes(nums, 2);
    return 0;
}