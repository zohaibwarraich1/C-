#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> decrypt(vector<int> &code, int k)
{
    vector<int> result(code.size(), 0);
    if (k == 0)
    {
        return result;
    }
    if (k > 0)
    {
        for (int i = 0; i < code.size(); i++)
        {
            int sum = 0;
            for (int j = 1; j <= k; j++)
            {
                sum += code[(i + j) % code.size()];
            }
            result[i] = sum;
        }
    }
    else if (k < 0)
    {
        k = -k;
        for (int i = 0; i < code.size(); i++)
        {
            int sum = 0;
            for (int j = 1; j <= k; j++)
            {
                sum += code[(i - j + code.size()) % code.size()];
            }
            result[i] = sum;
        }
    }
    return result;
}
int main()
{
    vector<int> code = {5, 7, 1, 4};
    vector<int> result = decrypt(code, 3);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}