#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
bool canBeEqual(vector<int> &target, vector<int> &arr)
{
    unordered_map<int, int> mp;
    for (int i = 0; i < target.size(); i++)
    {
        mp[target[i]]++;
    }
    for (int i = 0; i < arr.size(); i++)
    {
        mp[arr[i]]--;
        if (mp[arr[i]] < 0)
        {
            return false;
        }
    }
    return true;
}
int main()
{
    vector<int> target = {1, 2, 2, 3};
    vector<int> arr = {1, 1, 2, 3};
    if (canBeEqual(target, arr))
        cout << "true";
    else
        cout << "false";
    return 0;
}