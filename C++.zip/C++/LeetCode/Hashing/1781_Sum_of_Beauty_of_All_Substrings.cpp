#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int beautySum(string s)
{
    int count = 0;
    for (int i = 0; i < s.length(); i++)
    {
        map<char, int> mp;
        for (int j = i; j < s.length(); j++)
        {
            mp[s[j]]++;
            int Max = INT_MIN;
            int Min = INT_MAX;
            for (auto it : mp)
            {
                if (it.second > Max)
                {
                    Max = it.second;
                }
                if (it.second < Min)
                {
                    Min = it.second;
                }
            }
            count += Max - Min;
        }
        mp.clear();
    }
    return count;
}
int main()
{
    string s = "aabcbaa";
    cout << beautySum(s);
    return 0;
}