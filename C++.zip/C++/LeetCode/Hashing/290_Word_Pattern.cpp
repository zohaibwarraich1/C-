#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool wordPattern(string pattern, string s)
{
    vector<string> words;
    stringstream ss(s);
    string temp;
    while (getline(ss, temp, ' '))
    {
        words.push_back(temp);
    }
    map<char, string> mp;
    if (pattern.size() != words.size())
    {
        return false;
    }
    for (int i = 0; i < pattern.size(); i++)
    {
        bool found = false;
        for (auto it : mp)
        {
            if (it.second == words[i])
            {
                found = true;
            }
        }
        if (found == false)
        {
            mp[pattern[i]] = words[i];
        }
    }
    for (int i = 0; i < pattern.size(); i++)
    {
        char ch = pattern[i];
        string st = words[i];
        if (mp.find(ch) != mp.end() && mp.find(ch)->second != st)
        {
            return false;
        }
        else if (mp.find(ch) == mp.end())
        {
            return false;
        }
    }
    return true;
}
int main()
{
    string pattern = "abba";
    string s = "dog cat cat dog";
    if (wordPattern(pattern, s))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}