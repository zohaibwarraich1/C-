#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int longestConsecutive(vector<int> &nums)
{
    map<int, bool> mp;
    int count = 1;
    for (int i = 0; i < nums.size(); i++)
    {
        mp[nums[i]] = false;
    }
    int tempCount;
    int nextNum;
    int prevNum;
    for (int i = 0; i < nums.size(); i++)
    {
        tempCount = 1;
        nextNum = nums[i] + 1;
        while (mp.find(nextNum) != mp.end() && mp[nextNum] == false)
        {
            tempCount++;
            mp[nextNum] = true;
            nextNum++;
        }
        prevNum = nums[i] - 1;
        while (mp.find(prevNum) != mp.end() && mp[prevNum] == false)
        {
            tempCount++;
            mp[prevNum] = true;
            prevNum--;
        }
        if (tempCount > count)
            count = tempCount;
    }
    return count;
}
int main()
{
    vector<int> nums = {100, 4, 200, 1, 3, 2};
    cout << longestConsecutive(nums);
    return 0;
}