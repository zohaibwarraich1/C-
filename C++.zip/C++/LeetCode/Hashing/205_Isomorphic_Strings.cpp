#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool isIsomorphic(string s, string t)
{
    unordered_map<char, char> mp;
    unordered_map<char, char> mp2;
    int n = s.size();
    for (int i = 0; i < n; i++)
    {
        if ((mp.find(s[i]) != mp.end() && mp[s[i]] != t[i]) || (mp2.find(t[i]) != mp2.end() && mp2[t[i]] != s[i]))
        {
            return false;
        }
        mp[s[i]] = t[i];
        mp2[t[i]] = s[i];
    }
    return true;
}
int main()
{
    string s = "egg";
    string t = "add";
    if (isIsomorphic(s, t))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}