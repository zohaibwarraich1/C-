#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
vector<int> findDisappearedNumbers(vector<int> &nums)
{
    unordered_map<int, int> mp;
    for (int i = 1; i <= nums.size(); i++)
    {
        mp[i]++;
    }
    vector<int> result;
    for (int i = 0; i < nums.size(); i++)
    {
        if (mp.count(nums[i]))
        {
            mp.erase(nums[i]);
        }
    }
    for (auto ele : mp)
    {
        result.push_back(ele.first);
    }
    return result;
}
int main()
{
    vector<int> nums = {4, 3, 2, 7, 8, 2, 3, 1};
    vector<int> result = findDisappearedNumbers(nums);
    for (int i = 0; i < result.size(); i++)
    {
        cout << result[i] << endl;
    }
    return 0;
}