#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int countWords(vector<string> &words1, vector<string> &words2)
{
    map<string, int> mp1;
    map<string, int> mp2;
    for (int i = 0; i < words1.size(); i++)
    {
        mp1[words1[i]]++;
    }
    for (int i = 0; i < words2.size(); i++)
    {
        mp2[words2[i]]++;
    }
    int count = 0;
    auto it1 = mp1.begin();
    while (it1 != mp1.end())
    {
        if (mp2[it1->first] == 1 && it1->second == 1)
        {
            count++;
        }
        it1++;
    }
    return count;
}
int main()
{
    vector<string> words1 = {"a", "ab"};
    vector<string> words2 = {"a", "a", "a", "ab"};
    cout << countWords(words1, words2);
    return 0;
}