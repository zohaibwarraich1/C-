#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
int findLucky(vector<int> &arr)
{
    unordered_map<int, int> nums;
    for (int i = 0; i < arr.size(); i++)
    {
        nums[arr[i]]++;
    }
    int count = -1;
    unordered_map<int, int>::iterator it = nums.begin();
    for (; it != nums.end(); it++)
    {
        if (it->first == it->second)
        {
            if (count < it->first)
                count = it->second;
        }
    }
    return count;
}
int main()
{
    vector<int> arr = {2, 2, 2, 3, 3};
    cout << findLucky(arr);
    return 0;
}