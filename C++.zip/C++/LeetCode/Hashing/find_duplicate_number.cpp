#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
int findDuplicate(vector<int> nums)
{
    map<int, int> mp;
    for (int i = 0; i < nums.size(); i++)
    {
        mp[nums[i]]++;
    }
    int duplicate = -1;
    for (int i = 0; i < nums.size(); i++)
    {
        if (mp[nums[i]] > 1)
        {
            duplicate = nums[i];
            break;
        }
    }
    return duplicate;
}
int main()
{
    vector<int> nums = {3, 3, 4, 2, 1};
    cout << findDuplicate(nums);
    return 0;
}