#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int nthUglyNumber(int n)
{
    if (n <= 0)
        return 0;
    if (n == 1)
        return 1;
    vector<int> primes = {2, 3, 5};
    unordered_set<long> seen;
    priority_queue<long, vector<long>, greater<long>> minHeap;
    minHeap.push(1);
    seen.insert(1);
    long currentUgly = 1;
    for (int i = 1; i < n; ++i)
    {
        currentUgly = minHeap.top();
        minHeap.pop();
        for (int prime : primes)
        {
            long newUgly = currentUgly * prime;
            if (seen.find(newUgly) == seen.end())
            {
                minHeap.push(newUgly);
                seen.insert(newUgly);
            }
        }
    }
    return (int)(minHeap.top());
}
int main()
{
    cout << nthUglyNumber(10);
    return 0;
}