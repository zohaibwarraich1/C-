#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
#include <iterator>
using namespace std;
string kthDistinct(vector<string> &arr, int k)
{
    unordered_map<string, int> count;
    vector<string> distinct;
    for (auto s : arr)
    {
        count[s]++;
    }
    for (auto s : arr)
    {
        if (count[s] == 1)
        {
            distinct.push_back(s);
        }
    }
    if (distinct.size() >= k && k > 0)
    {
        string result = distinct[k - 1];
        return result;
    }
    else
    {
        return "";
    }
}
int main()
{
    vector<string> arr = {"d", "b", "c", "b", "c", "a"};
    cout << kthDistinct(arr, 2);
    return 0;
}