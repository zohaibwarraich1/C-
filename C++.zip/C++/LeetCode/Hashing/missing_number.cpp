#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
int missingNumber(vector<int> nums)
{
    unordered_map<int, int> mp;
    for (int i = 0; i < nums.size(); i++)
    {
        mp[nums[i]]++;
    }
    int num = 0;
    for (int i = 0; i <= nums.size(); i++)
    {
        if (mp.find(i) == mp.end())
        {
            num = i;
            break;
        }
    }
    return num;
}
int main()
{
    vector<int> nums = {3, 0, 1};
    cout << missingNumber(nums);
    return 0;
}