#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int firstMissingPositive(vector<int> &nums)
{
    map<int, int> mp;
    for (int i = 0; i < nums.size(); i++)
    {
        mp[nums[i]]++;
    }
    for (int i = 1; i <= nums.size() + 1; i++)
    {
        if (mp.find(i) == mp.end())
        {
            return i;
        }
    }
    return 0;
}
int main()
{
    vector<int> nums = {3, 4, 5, 6, 8};
    cout << firstMissingPositive(nums);
    return 0;
}