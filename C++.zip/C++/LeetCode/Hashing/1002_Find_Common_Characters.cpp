#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<string> commonChars(vector<string> &words)
{
    map<char, int> mp1;
    for (int i = 0; i < words[0].length(); i++)
    {
        mp1[words[0][i]]++;
    }
    for (int i = 1; i < words.size(); i++)
    {
        map<char, int> mp2;
        for (int j = 0; j < words[i].length(); j++)
        {
            mp2[words[i][j]]++;
        }
        for (map<char, int>::iterator it1 = mp1.begin(); it1 != mp1.end(); it1++)
        {
            if (mp2.find(it1->first) != mp2.end())
            {
                auto it2 = mp2.find(it1->first);
                it1->second = min(it1->second, it2->second);
            }
            else
            {
                it1->second = 0;
            }
        }
        mp2.clear();
    }
    vector<string> result;
    for (auto it : mp1)
    {
        if (it.second == 0)
        {
            continue;
        }
        for (int i = 0; i < it.second; i++)
        {
            string s;
            s.push_back(it.first);
            result.push_back(s);
        }
    }
    return result;
}
int main()
{
    vector<string> words = {"cool", "lock", "cook"};
    vector<string> result = commonChars(words);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}