#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int longestSubarray(vector<int> &nums, int limit)
{
    queue<int> increasing;
    queue<int> decreasing;
    int max = 0;
    int count = 0;
    for (int i = 0; i < nums.size(); i++)
    {
        while (!increasing.empty() && increasing.front() >= nums[i])
        {
            increasing.pop();
        }
        while (!decreasing.empty() && decreasing.front() <= nums[i]) //* 10,1,2,4,7,2 | 5 | count = 2
        {
            decreasing.pop();
        }
        decreasing.push(nums[i]); //? 7
        increasing.push(nums[i]); //? 1,2,4
        if (decreasing.front() - increasing.front() > limit)
        {
            decreasing.pop();
            count = 0;
        }
        else if (decreasing.front() - increasing.front() <= limit)
        {
            count++;
        }
        if (count > max)
        {
            max = count;
        }
    }
    return max + 1;
}
int main()
{
    vector<int> nums = {10, 1, 2, 4, 7, 2};
    cout << longestSubarray(nums, 5);
    return 0;
}