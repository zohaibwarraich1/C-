#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int timeRequiredToBuy(vector<int> &tickets, int k)
{
    queue<int> queue;
    int n = tickets.size();
    int counter = 0;
    for (int i = 0; i < n; i++)
    {
        queue.push(i);
    }
    while (tickets[k] != 0)
    {
        tickets[queue.front()] = tickets[queue.front()] - 1;
        if (tickets[queue.front()] > 0)
        {
            queue.push(queue.front());
        }
        queue.pop();
        counter++;
    }
    return counter;
}
int main()
{
    vector<int> tickets = {5, 1, 1, 1};
    cout << timeRequiredToBuy(tickets, 0);
    return 0;
}