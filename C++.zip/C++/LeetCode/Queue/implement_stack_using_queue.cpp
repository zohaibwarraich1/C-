#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
class MyQueue
{
public:
    stack<int> first;
    stack<int> result;
    deque<int> result2;
    MyQueue() {}
    void push(int x) { first.push(x); }
    int pop()
    {
        int val = peek();
        result.pop();
        return val;
    }
    int peek()
    {
        if (result.empty())
        {
            while (first.empty() == false)
            {
                result.push(first.top());
                first.pop();
            }
        }
        return result.top();
    }
    bool empty()
    {
        if (first.empty() && result.empty())
            return true;
        else
            return false;
    }
};
int main()
{
    MyQueue obj = MyQueue();
    obj.push(1);
    obj.push(2);
    obj.push(3);
    cout << obj.pop() << endl;
    cout << obj.peek() << endl;
    cout << obj.empty() << endl;
    return 0;
}