#include <iostream>
#include "Student.cpp"
using namespace std;
class Exam : public Student
{
protected:
    float maths;
    float physics;

public:
    Exam()
    {
    }
    Exam(int roll, float maths, float physics):Student(roll)
    {
        this->maths = maths;
        this->physics = physics;
    }
    void set_marks(float m1, float m2)
    {
        roll_number = 0;
        maths = m1;
        physics = m2;
    }
    void get_marks()
    {
        cout << "The marks obtained in maths are: " << maths << endl;
        cout << "The marks obtained in physics are: " << physics << endl;
    }
};