#include <iostream>
#include "Exam.cpp"
class Result : public Exam
{
    float percentage;

public:
    Result()
    {
    }
    Result(int roll, float maths, float physics) : Exam(roll, maths, physics)
    {
    }
    void display_results()
    {
        Student::get_roll_number();
        Exam::get_marks();
        cout << "Your result is " << (maths + physics) / 2 << "%" << endl;
    }
};
