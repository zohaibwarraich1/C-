#include <iostream>
using namespace std;
class Student
{
protected:
    int roll_number;

public:
    Student()
    {
    }
    Student(int roll)
    {
        this->roll_number = roll;
    }
    void set_roll_number(int r)
    {
        roll_number = r;
    }
    void get_roll_number()
    {
        cout << "The roll number is " << roll_number << endl;
    }
};