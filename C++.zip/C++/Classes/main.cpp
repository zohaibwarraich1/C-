// Count is the static data member of class Employee
#include <iostream>
#include "Result.cpp"
using namespace std;
class Base1
{
public:
    virtual void greet()
    {
        cout<<"Hi";
    }
};
class Derived : public Base1
{
    int a;

public:
    void greet() override
    {
        cout << "Hello";
    }
};
int main()
{
    Derived d = Derived();
    d.greet();
    return 0;
}