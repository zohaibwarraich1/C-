#include <iostream>
using namespace std;
class Employee
{
    int id;
    static int count;

public:
    Employee()
    {
        count = 0;
    }
    Employee(int a)
    {
        count = a;
    }
    void setData()
    {
        cout << "Enter the id" << endl;
        cin >> id;
        count++;
    }
    void getData()
    {
        cout << "The id of this employee is " << id << " and this is employee number " << count << endl;
    }

    static void getCount()
    {
        // cout<<id; // throws an error
        cout << "The value of count is " << count << endl;
    }
};
int Employee::count;