#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
using namespace std;
int main()
{
    int array[5] = {5, 2, 1, 4, 8};
    for (int i = 0; i < 5; i++)
    {
        for (int j = i + 1; j > 0; j--)
        {
            if (array[j] < array[j - 1])
            {
                int temp = array[j];
                array[j] = array[j - 1];
                array[j - 1] = temp;
            }
        }
    }
    for (int i = 0; i < 5; i++)
    {
        cout << array[i] << " ";
    }
    return 0;
}