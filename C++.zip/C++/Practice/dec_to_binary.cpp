#include <iostream>
using namespace std;

int main()
{
    //! Program for decimal to binary //

    int decimalNumber;
    cout << "Enter a decimal number: ";
    cin >> decimalNumber;
    int binary = 0;
    int base = 1;
    while (decimalNumber != 0)
    {
        int remainder = decimalNumber % 2;
        binary = binary + (remainder * base);
        decimalNumber = decimalNumber / 2;
        base = base * 10;
    }
    cout << "Binary equivalent: " << binary << endl;

    return 0;
}
