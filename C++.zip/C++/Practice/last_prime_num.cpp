#include <iostream>
using namespace std;
int main()
{
    int num;
    cout << "Enter a number: ";
    cin >> num;
    for (int i = num - 1; i >= 2; i--)
    {
        if (i == 2 || i == 3 || i == 5 || i == 7)
        {
            cout << i << " is the prime number.";
            break;
        }
        else if (i % 2 == 0 || i % 3 == 0 || i % 5 == 0 || i % 7 == 0)
        {
            continue;
        }
        else
        {
            cout << i << " is the prime number.";
            break;
        }
    }
    return 0;
}
