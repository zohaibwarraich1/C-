#include <iostream>
using namespace std;
int main()
{
    //! datatype section //

    float first_num, second_num, third_num;
    float sum;
    char op, equal;

    //! datatype section closed //
    //! input section //

    cout << "Enter a number: ";
    cin >> first_num;
    cout << "Enter an operator: ";
    cin >> op;
    cout << "Enter a number: ";
    cin >> second_num;

    //! input section closed//
    //! first if section //

    if (op == '+')
    {
        sum = first_num + second_num;
        cout << "Press = \n";
        cin >> equal;
        cout << "Your sum is: " << sum;
    }
    else if (op == '-')
    {
        sum = first_num - second_num;
        cout << "Press = \n";
        cin >> equal;
        cout << "Your sum is: " << sum;
    }
    else if (op == '*')
    {
        sum = first_num * second_num;
        cout << "Press = \n";
        cin >> equal;
        cout << "Your sum is: " << sum;
    }
    else if (op == '/')
    {
        sum = first_num / second_num;
        cout << "Press = \n";
        cin >> equal;
        cout << "Your sum is: " << sum;
    }
    else
    {
        cout << "Enter the correct operator";
    }

    //! first if section closed //
    //! while section //

    string new_equal;
    string ac;
    cout << "\nEnter AC or Operator: ";
    cin >> new_equal;
    if (new_equal == "+" || new_equal == "-" || new_equal == "*" || new_equal == "/" || new_equal == "ac" || new_equal == "AC")
    {
        while (new_equal == "+" || new_equal == "-" || new_equal == "*" || new_equal == "/" || new_equal == "ac" || new_equal == "AC")
        {

            if (new_equal == "+")
            {
                cout << "\nEnter number: ";
                cin >> third_num;
                sum = third_num + sum;
                cout << "Your sum is: " << sum;
                cout << "\nEnter AC or Operator: ";
                cin >> new_equal;
            }
            else if (new_equal == "-")
            {
                cout << "\nEnter number: ";
                cin >> third_num;
                sum = sum - third_num;
                cout << "Your sum is: " << sum;
                cout << "\nEnter AC or Operator: ";
                cin >> new_equal;
            }
            else if (new_equal == "*")
            {
                cout << "\nEnter number: ";
                cin >> third_num;
                sum = sum * third_num;
                cout << "Your sum is: " << sum;
                cout << "\nEnter AC or Operator: ";
                cin >> new_equal;
            }
            else if (new_equal == "/")
            {
                cout << "\nEnter number: ";
                cin >> third_num;
                sum = sum / third_num;
                cout << "Your sum is: " << sum;
                cout << "\nEnter AC or Operator: ";
                cin >> new_equal;
            }
            else if (new_equal == "AC" || new_equal == "ac")
            {
                cout << "Enter a number: ";
                cin >> first_num;
                cout << "Enter an operator: ";
                cin >> op;
                cout << "Enter a number: ";
                cin >> second_num;
                if (op == '+')
                {
                    sum = first_num + second_num;
                    cout << "Press = \n";
                    cin >> equal;
                    cout << "Your sum is: " << sum;
                    cout << "\nEnter AC or Operator: ";
                    cin >> new_equal;
                }
                else if (op == '-')
                {
                    sum = first_num - second_num;
                    cout << "Press = \n";
                    cin >> equal;
                    cout << "Your sum is: " << sum;
                    cout << "\nEnter AC or Operator: ";
                    cin >> new_equal;
                }
                else if (op == '*')
                {
                    sum = first_num * second_num;
                    cout << "Press = \n";
                    cin >> equal;
                    cout << "Your sum is: " << sum;
                    cout << "\nEnter AC or Operator: ";
                    cin >> new_equal;
                }
                else if (op == '/')
                {
                    sum = first_num / second_num;
                    cout << "Press = \n";
                    cin >> equal;
                    cout << "Your sum is: " << sum;
                    cout << "\nEnter AC or Operator or OFF: ";
                    cin >> new_equal;
                }
                else
                {
                    cout << "Enter the correct operator";
                }
            }
        }
        if (new_equal == "off")
        {
            cout << "Bye";
        }
    }
    else if (new_equal == "off")
    {
        cout << "Bye";
    }

    //! while section close //

    return 0;
}