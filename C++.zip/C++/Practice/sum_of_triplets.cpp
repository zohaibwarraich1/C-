#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
using namespace std;
int main()
{
    
    //! Program to check the sum of three digits is equal to given target or not //

    int numbers[5] = {1, 2, 3, 4, 5};
    int target = 9;
    int counter = 1;
    for (int i = 0; i < 5; i++)
    {
        for (int j = i + 1; j < 5; j++)
        {
            for (int k = j + 1; k < 5; k++)
            {
                if (numbers[i] + numbers[j] + numbers[k] == target)
                {
                    cout << counter << ": ";
                    cout << numbers[i] << "+" << numbers[j] << "+" << numbers[k] << "=" << target << endl;
                    counter++;
                }
            }
        }
    }
    return 0;
}