#include <iostream>
using namespace std;
int main()
{
    //! --> Program for changing letter with next letter using string <-- //

    // string word;
    // getline(cin,word);
    // int char_code;
    // for(int i=0;i<word.length();i++)
    // {
    //     char_code=(int)word[i];
    //     if(char_code==90)
    //     {
    //         word[i]=static_cast<char>(65);
    //     }
    //     else if(char_code==122)
    //     {
    //         word[i]=static_cast<char>(97);
    //     }
    //     else if(char_code>=65&&char_code<=90||char_code>=97&&char_code<=122)
    //     {
    //         word[i]=static_cast<char>(char_code)+1;
    //     }
    // }
    // cout<<word;

    //! --> Program for changing letter with next letter using char arrays <-- //

    // char word[30]="";
    // cin.getline(word,30);
    // int char_code;
    // for(int i=0;word[i]!='\0';i++)
    // {
    //     char_code=(int)word[i];
    //     if(char_code==90)
    //     {
    //         word[i]=static_cast<char>(65);
    //     }
    //     else if(char_code==122)
    //     {
    //         word[i]=static_cast<char>(97);
    //     }
    //     else if(char_code>=65&&char_code<=90||char_code>=97&&char_code<=122)
    //     {
    //         word[i]=static_cast<char>(char_code)+1;
    //     }
    // }
    // cout<<word;
    return 0;
}