#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
using namespace std;
int main()
{
    //! Program for generating random password //
    
    srand(time(0));
    int length;
    cout << "Enter the length of password: ";
    cin >> length;
    int max = 126;
    int min = 48;
    string password;
    for (int i = 0; i < length; i++)
    {
        int random_pass = min + (rand() % (max - min));
        if (random_pass >= 58 && random_pass <= 64)
        {
            i--;
            continue;
        }
        password += static_cast<char>(random_pass);
    }
    cout<<password;
    return 0;
}
