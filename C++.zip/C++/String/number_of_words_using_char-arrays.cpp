#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
    //! Program for finding number of words using char array //

    char mystr[] = "zohaib warraich";
    int count = 0;
    if (mystr[0] != ' ')
    {
        count++;
    }
    for (int i = 0; mystr[i] != '\0'; i++)
    {
        if (mystr[i] == ' ')
        {
            if (mystr[i + 1] != ' ' && mystr[i + 1] != '\0')
            {
                count++;
            }
        }
    }
    cout << count;
    return 0;
}