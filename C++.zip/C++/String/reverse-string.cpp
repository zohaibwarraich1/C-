#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
    //! Program for printing reverse of a string //
    
    string word;
    getline(cin,word);
    for(int i=word.length()-1;i>=0;i--)
    {
        cout<<word[i];
    }
    return 0;
}