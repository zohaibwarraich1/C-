#include <iostream>
using namespace std;
int main()
{
    //! Program for finding the substring in string //
    char text[] = "my name is zohaib";
    char string[] = "zohaib";
    bool found = false;
    for (int i = 0; text[i] != '\0'; ++i)
    {
        if (text[i] == string[0])
        {
            int j;
            for (j = 0; string[j] != '\0'; ++j)
            {
                if (text[i + j] != string[j])
                {
                    break;
                }
            }
            if (string[j] == '\0')
            {
                found = true;
                break;
            }
        }
    }
    if (found)
    {
        cout << "string is present." << endl;
    }
    else
    {
        cout << "string is not present." << endl;
    }
    return 0;
}
