#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <iomanip>
#include <cctype>
#include <string>
#include <cstring>
using namespace std;
void pas(int *p, int rows, int column);
int main()
{
    int rows, col;
    cout << "Enter rows: ";
    cin >> rows;
    cout << "Enter columns: ";
    cin >> col;
    int array[rows][col];
    pas(&array[0][0], rows, col);
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cout << array[i][j];
        }
        cout << endl;
    }
    return 0;
}
void pas(int *p, int rows, int column)
{
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < column; j++)
        {
            cin >> *p;
            p++;
        }
    }
}