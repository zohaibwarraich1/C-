#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
double minimumAverage(vector<int> &nums)
{
    sort(nums.begin(), nums.end());
    int l = 0;
    int r = nums.size() - 1;
    double minimum = 100000;
    while (l < r)
    {
        double average = (nums[l] + nums[r]) / 2.0;
        if (average < minimum)
        {
            minimum = average;
        }
        l++;
        r--;
    }
    return minimum;
}
int main()
{
    vector<int> nums = {7, 8, 3, 4, 15, 13, 4, 1};
    cout << minimumAverage(nums);
    return 0;
}