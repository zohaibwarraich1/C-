#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
vector<string> summaryRanges(vector<int> &nums)
{
    vector<string> ans;
    int point = 0;
    int size = nums.size();
    for (int i = 0; i < size; i++)
    {
        point = i;
        if (i < size - 1)
        {
            while (nums[i] + 1 == nums[i + 1])
            {
                i++;
                if (i >= size - 1)
                    break;
            }
        }
        if (nums[point] != nums[i])
        {
            ans.push_back(to_string(nums[point]) + "->" +
                          to_string(nums[i]));
        }
        else
        {
            ans.push_back(to_string(nums[point]));
        }
    }
    return ans;
}
int main()
{
    vector<int> nums = {0, 2, 3, 4, 6, 8, 9};
    vector<string> result = summaryRanges(nums);
    cout << "\"";
    for (int i = 0; i < result.size(); i++)
    {
        cout << result[i];
        if (i < result.size() - 1)
            cout << "\",\"";
    }
    cout << "\"";
    return 0;
}