#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
vector<int> sortArrayByParityII(vector<int> &nums)
{
    vector<int> result(nums.size());
    int even = 0;
    int odd = 1;
    for (int i = 0; i < nums.size(); i++)
    {
        if (nums[i] % 2 == 0)
        {
            result[even] = nums[i];
            even += 2;
        }
        else
        {
            result[odd] = nums[i];
            odd += 2;
        }
    }
    return result;
}
int main()
{
    vector<int> nums = {4, 2, 5, 7};
    vector<int> result = sortArrayByParityII(nums);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}