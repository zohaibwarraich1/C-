#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//* Write a program that sum 2 indexes and that indexes should be equal to given target and print that index on console.

int main()
{
    vector<int> nums = {2, 7, 8, 9, 4, 1};
    int target = 9;
    vector<int> result;
    for (int i = 0; i < nums.size(); i++)
    {
        for (int j = i + 1; j < nums.size(); j++)
        {
            if (nums[i] + nums[j] == target)
            {
                result.push_back(i);
                result.push_back(j);
            }
        }
    }
    cout << "[";
    for (int i = 0; i < result.size(); i++)
    {
        cout << result[i] << ",";
    }
    cout << "\b]";
    return 0;
}