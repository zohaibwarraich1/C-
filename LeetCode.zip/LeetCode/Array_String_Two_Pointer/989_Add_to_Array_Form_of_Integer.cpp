#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
vector<int> addToArrayForm(vector<int> &num, int k)
{
    int sum;
    int carry;
    int index = num.size() - 1;
    vector<int> result;
    while (k != 0 || index >= 0)
    {
        sum = carry;
        if (k != 0)
        {
            sum += k % 10;
            k /= 10;
        }
        if (index >= 0)
        {
            sum += num[index];
        }
        result.push_back(sum % 10);
        carry = sum / 10;
        index--;
    }
    if (carry > 0)
    {
        result.push_back(carry);
    }
    reverse(result.begin(), result.end());
    return result;
}
int main()
{
    vector<int> num = {0};
    vector<int> result = addToArrayForm(num, 340);
    for (int i = 0; i < result.size(); i++)
    {
        cout << result[i] << " ";
    }
    return 0;
}