#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
string reverseVowels(string s)
{
    int p1 = 0;
    int p2 = s.length() - 1;
    bool isSwap;
    while (p1 <= p2)
    {
        isSwap = true;
        if (tolower(s[p1]) != 'a' && tolower(s[p1]) != 'e' && tolower(s[p1]) != 'i' && tolower(s[p1]) != 'o' &&
            tolower(s[p1]) != 'u')
        {
            p1++;
            isSwap = false;
        }
        if (tolower(s[p2]) != 'a' && tolower(s[p2]) != 'e' && tolower(s[p2]) != 'i' && tolower(s[p2]) != 'o' &&
            tolower(s[p2]) != 'u')
        {
            p2--;
            isSwap = false;
        }
        if (isSwap)
        {
            swap(s[p1], s[p2]);
            p1++;
            p2--;
        }
    }
    return s;
}
int main()
{
    string s = "hello";
    cout << reverseVowels(s);
    return 0;
}