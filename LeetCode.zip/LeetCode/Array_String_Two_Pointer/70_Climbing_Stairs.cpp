#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
int climbStairs(int n)
{
    int first = 0;
    int sec = 0;
    int fibonacci = 1;
    while (n != 0)
    {
        first = sec;
        sec = fibonacci;
        fibonacci = first + sec;
        n--;
    }
    return fibonacci;
}
int main()
{
    cout << "Steps: " << climbStairs(4);
    return 0;
}