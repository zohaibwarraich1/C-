#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int nextGreaterElement(int n)
{
    vector<int> nums;
    int temp = n;
    while (temp)
    {
        nums.push_back(temp % 10);
        temp /= 10;
    }
    reverse(nums.begin(), nums.end());
    int index = -1;
    for (int i = nums.size() - 2; i >= 0; i--)
    {
        if (nums[i] < nums[i + 1])
        {
            index = i;
            break;
        }
    }
    if (index == -1)
    {
        return -1;
    }
    for (int i = nums.size() - 1; i >= index; i--)
    {
        if (nums[index] < nums[i])
        {
            swap(nums[index], nums[i]);
            break;
        }
    }
    reverse(nums.begin() + index + 1, nums.end());
    long long result = 0;
    for (int i = 0; i < nums.size(); i++)
    {
        result = (result * 10) + nums[i];
    }
    if (result > n && result <= 2147483647)
        return result;
    else
        return -1;
}
int main()
{
    cout << nextGreaterElement(12);
    return 0;
}