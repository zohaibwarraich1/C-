#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int numberOfChild(int n, int k)
{
    bool starting;
    bool ending;
    int tempK = 0;
    int i = 0;
    for (; tempK < k; tempK++)
    {
        if (i == 0)
        {
            ending = false;
            starting = true;
        }
        else if (i == n - 1)
        {
            ending = true;
            starting = false;
        }
        if (starting)
        {
            i++;
        }
        else if (ending)
        {
            i--;
        }
    }
    return i;
}
int main()
{
    cout << numberOfChild(4, 2);
    return 0;
}