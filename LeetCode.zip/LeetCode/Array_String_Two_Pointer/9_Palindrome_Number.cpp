#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//* Write a C++ Program to check the given number is palindrome or not.

//* Prototype
bool isPalidrome(int num);

int main()
{
    int num = 79797;
    if (isPalidrome(num))
    {
        cout << "It is palindrome";
    }
    else
    {
        cout << "Its is not palindrome";
    }
    return 0;
}
bool isPalidrome(int num)
{
    int temp = num;
    int reverse = 0;
    while (temp > 0)
    {
        int last = temp % 10;
        reverse = last + (10 * reverse);
        temp /= 10;
    }
    if (num == reverse)
    {
        return true;
    }
    return false;
}