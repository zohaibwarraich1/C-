#include <iostream>
#include <vector>
using namespace std;

//* Prototype
void incrementLargeInteger(vector<int> &digits);

int main()
{
    vector<int> originalDigits = {2, 7, 8, 4, 9, 9, 3, 9};
    incrementLargeInteger(originalDigits);
    for (int i = 0; i < originalDigits.size(); i++)
    {
        cout << originalDigits[i] << " ";
    }
    return 0;
}
void incrementLargeInteger(vector<int> &digits)
{
    int n = digits.size() - 1;
    for (int i = n; i >= 0; i--)
    {
        if (i == n)
            digits[i]++;
        if (digits[i] == 10)
        {
            digits[i] = 0;
            if (i != 0)
            {
                digits[i - 1]++;
            }
            else
            {
                digits.push_back(0);
                digits[i] = 1;
            }
        }
    }
}