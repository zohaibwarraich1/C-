#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
int titleToNumber(string columnTitle)
{
    int sum;
    int base = 26;
    int size = columnTitle.length();
    int result = 0;
    for (int i = 1; i <= size; i++)
    {
        int sum = 0;
        int power = size - i;
        int ascii = ((columnTitle[i - 1]) - 64);
        sum += ((pow(base, power)) * ascii);
        result += sum;
    }
    return result;
}
int main()
{
    cout << titleToNumber("AA");
    return 0;
}