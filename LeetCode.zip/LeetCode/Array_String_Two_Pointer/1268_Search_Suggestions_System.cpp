#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<vector<string>> suggestedProducts(vector<string> &products, string searchWord)
{
    sort(products.begin(), products.end());
    int l = 0;
    int r = products.size() - 1;
    vector<vector<string>> res;
    for (int i = 0; i < searchWord.length(); i++)
    {
        while (l <= r && products[l][i] != searchWord[i])
        {
            l++;
        }
        while (l <= r && products[r][i] != searchWord[i])
        {
            r--;
        }
        int len = min((r - l) + 1, 3);
        vector<string> store;
        for (int i = 0; i < len; i++)
        {
            store.push_back(products[i + l]);
        }
        res.push_back(store);
    }
    return res;
}
int main()
{
    vector<string> products = {"mobile", "mouse", "moneypot", "monitor", "mousepad"};
    vector<vector<string>> res = suggestedProducts(products, "mouse");
    for (auto i : res)
    {
        for (auto j : i)
        {
            cout << j << " ";
        }
        cout << endl;
    }
    return 0;
}