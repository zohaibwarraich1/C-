#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
int countAsterisks(string s)
{
    int count = 0;
    int bars = 0;
    for (int i = 0; i < s.length(); i++)
    {
        if (bars % 2 == 0 && s[i] == 42)
        {
            count++;
        }
        else if (s[i] == 124)
        {
            bars++;
        }
    }
    return count;
}
int main()
{
    cout << countAsterisks("l|*e*et|c***o|*de|");
    return 0;
}