#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
vector<int> luckyNumbers(vector<vector<int>> &matrix)
{
    vector<int> maxV;
    vector<int> minV;
    for (int i = 0; i < matrix.size(); i++)
    {
        int min = matrix[i][0];
        for (int j = 0; j < matrix[i].size(); j++)
        {
            if (matrix[i][j] < min)
            {
                min = matrix[i][j];
            }
        }
        minV.push_back(min);
    }
    for (int i = 0; i < matrix[0].size(); i++)
    {
        int max = matrix[0][i];
        for (int j = 1; j < matrix.size(); j++)
        {
            if (matrix[j][i] > max)
            {
                max = matrix[j][i];
            }
        }
        maxV.push_back(max);
    }
    vector<int> result;
    for (int i = 0; i < maxV.size(); i++)
    {
        for (int j = 0; j < minV.size(); j++)
        {
            if (maxV[i] == minV[j])
            {
                result.push_back(maxV[i]);
                break;
            }
        }
    }
    return result;
}
int main()
{
    vector<vector<int>> matrix = {{3, 7, 8},
                                  {9, 11, 13},
                                  {15, 16, 17}};
    vector<int> result = luckyNumbers(matrix);
    cout << result[0];
    return 0;
}