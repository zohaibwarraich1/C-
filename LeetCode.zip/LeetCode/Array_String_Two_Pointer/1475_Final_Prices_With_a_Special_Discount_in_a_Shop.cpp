#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
vector<int> finalPrices(vector<int> &prices)
{
    for (int i = 0; i < prices.size() - 1; i++)
    {
        for (int j = i + 1; j < prices.size(); j++)
        {
            if (prices[j] <= prices[i])
            {
                int dis = prices[i] - prices[j];
                prices[i] = dis;
                break;
            }
        }
    }
    return prices;
}
int main()
{
    vector<int> nums = {8, 4, 6, 2, 3};
    vector<int> result = finalPrices(nums);
    cout << "[";
    for (int i = 0; i < result.size(); i++)
    {
        cout << result[i];
        if (i < result.size() - 1)
            cout << ",";
    }
    cout << "]";
    return 0;
}