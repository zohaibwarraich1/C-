#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool lemonadeChange(vector<int> &bills)
{
    int fives = 0;
    int tens = 0;
    int twenties = 0;
    for (int i = 0; i < bills.size(); i++)
    {
        if (bills[i] == 5)
        {
            fives++;
        }
        else if (bills[i] == 10)
        {
            if (fives > 0)
            {
                fives--;
                tens++;
            }
            else 
            {
                return false;
            }
        }
        else if (bills[i] == 20)
        {
            if (fives == 1 && tens == 1)
            {
                fives--;
                tens--;
                twenties++;
            }
            else if (fives >= 3)
            {
                fives -= 3;
                twenties++;
            }
            else
            {
                return false;
            }
        }
    }
    return true;
}
int main()
{
    vector<int> bills = {5, 5, 5, 10, 20};
    if (lemonadeChange(bills))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}