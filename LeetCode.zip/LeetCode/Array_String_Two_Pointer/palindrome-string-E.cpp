#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//* Write a program to check whether a string is palindrome or not.

//* Prototype
string removeAlphaNumerics(string str);
bool isPalindrome(string str);

int main()
{
    string str = "0P";
    string result = removeAlphaNumerics(str);
    bool palindrome = isPalindrome(result);
    if (palindrome)
        cout << "It is palindrome";
    else
        cout << "It is not palindrome";
    return 0;
}
string removeAlphaNumerics(string str)
{
    string result;
    for (int i = 0; i < str.size(); i++)
    {
        if (str[i] >= '0' && str[i] <= '9' || str[i] >= 'A' && str[i] <= 'Z' || str[i] >= 'a' && str[i] <= 'z')
        {
            result += tolower(str[i]);
        }
    }
    return result;
}
bool isPalindrome(string str)
{
    int m = str.size() - 1;
    for (int i = 0; i < str.size(); i++, m--)
    {
        if (str[i] != str[m])
        {
            return false;
        }
    }
    return true;
}