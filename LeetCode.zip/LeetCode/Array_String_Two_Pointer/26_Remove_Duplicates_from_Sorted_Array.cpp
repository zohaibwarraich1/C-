#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//* Write a program to remove duplicates from an array.

int main()
{
    int nums[8] = {0, 1, 1, 1, 2, 2, 5, 1};
    int sizeNums = sizeof(nums) / sizeof(nums[0]);
    for (int i = 0; i < sizeNums; i++)
    {
        for (int j = i + 1; j < sizeNums; j++)
        {
            if (nums[i] > nums[j])
            {
                int temp = nums[i];
                nums[i] = nums[j];
                nums[j] = temp;
            }
        }
    }
    vector<int> result;
    for (int i = 0; i < sizeNums; i++)
    {
        if (i == 0 || nums[i] != nums[i - 1])
        {
            result.push_back(nums[i]);
        }
    }
    for (int i = 0; i < result.size(); i++)
    {
        nums[i] = result[i];
    }
    for (int i = 0; i < result.size(); i++)
    {
        cout << nums[i] << " ";
    }
    return 0;
}