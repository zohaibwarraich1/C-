#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
void sortColors(vector<int> &nums)
{
    int l = 0;
    int r = nums.size() - 1;
    for (int i = 0; i <= r;)
    {
        if (nums[i] == 0)
        {
            swap(nums[l], nums[i]);
            l++;
            i++;
        }
        else if (nums[i] == 2)
        {
            swap(nums[i], nums[r]);
            r--;
        }
        else if (nums[i] == 1)
        {
            i++;
        }
    }
}
int main()
{
    vector<int> nums = {2, 0, 1};
    sortColors(nums);
    for (auto ele : nums)
    {
        cout << ele << " ";
    }
    return 0;
}