#include <iostream>
#include <vector>
using namespace std;

//?                             ********** Question *********
//* Write a program to print pascal triangle upto given rows number.
vector<vector<int>> generate(int numRows)
{
    vector<vector<int>> mat;
    for (int i = 0; i < numRows; i++)
    {
        mat.resize(mat.size() + 1);
        for (int j = 0; j <= i; j++)
        {
            if (j == 0 || j == i)
            {
                mat[i].push_back(1);
            }
            else
            {
                mat[i].push_back(mat[i - 1][j - 1] + mat[i - 1][j]);
            }
        }
    }
    return mat;
}
int main()
{
    int rows = 5;
    vector<vector<int>> result = generate(rows);
    for (int i = 0; i < result.size(); i++)
    {
        for (int j = 0; j < result[i].size(); j++)
        {
            cout << result[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}
