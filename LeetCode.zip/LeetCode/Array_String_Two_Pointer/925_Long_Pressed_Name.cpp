#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
/*
 * Your friend is typing his name into a keyboard. Sometimes, when typing a character c, the key might get long pressed, and the character will be typed 1 or more times.
 * You examine the typed characters of the keyboard. Return True if it is possible that it was your friends name, with some characters (possibly none) being long pressed.
 */
//* Prototype
bool isLongPressedName(string name, string typed);

int main()
{
    string name = "pyplrz";
    string typed = "ppyypllr";
    if (isLongPressedName(name, typed))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}
bool isLongPressedName(string name, string typed)
{
    int m = name.size();
    int n = typed.size();
    if (name.length() > typed.length())
        return false;
    int i = 0, j = 0;
    while (i < m)
    {
        if (name[i] == typed[j])
        {
            i++;
            j++;
        }
        else if (i > 0 && name[i - 1] == typed[j])
        {
            j++;
        }
        else
            return false;
    }
    while (j < n)
    {
        if (name[i - 1] != typed[j])
            return false;
        j++;
    }
    return true;
}