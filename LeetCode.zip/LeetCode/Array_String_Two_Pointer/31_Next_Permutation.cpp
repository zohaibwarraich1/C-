#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
void nextPermutation(vector<int> &nums)
{
    int index = -1;
    for (int i = nums.size() - 2; i >= 0; i--)
    {
        if (nums[i] < nums[i + 1])
        {
            index = i;
            break;
        }
    }
    if (index == -1)
    {
        reverse(nums.begin(), nums.end());
        return;
    }
    for (int i = nums.size() - 1; i >= index; i--)
    {
        if (nums[index] < nums[i])
        {
            swap(nums[index], nums[i]);
            break;
        }
    }
    reverse(nums.begin() + index + 1, nums.end());
}
int main()
{
    vector<int> nums = {3, 4, 8, 6};
    nextPermutation(nums);
    for (auto ele : nums)
    {
        cout << ele << " ";
    }
    return 0;
}