#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
string reverseWords(string s)
{
    stringstream ss(s);
    string temp;
    string result;
    while (ss >> temp)
    {
        reverse(temp.begin(), temp.end());
        result += temp + " ";
    }
    result.pop_back();
    return result;
}
int main()
{
    string s = "Let's take LeetCode contest";
    cout << reverseWords(s);
    return 0;
}