#include <iostream>
using namespace std;

//?                             ********** Question *********
/*
 * Write an algorithm to determine if a number n is happy.
 * A happy number is a number defined by the following process:
 * Starting with any positive integer, replace the number by the sum of the squares of its digits.
 * Repeat the process until the number equals 1 (where it will stay), or it loops endlessly in a cycle which does not include 1.
 * Those numbers for which this process ends in 1 are happy.
 * Return true if n is a happy number, and false if not.
 */
//* Protoype
bool isHappy(int num);

int main()
{
    int number = 19;
    if (isHappy(number))
    {
        cout << number << " is a happy number." << endl;
    }
    else
    {
        cout << number << " is not a happy number." << endl;
    }
    return 0;
}
bool isHappy(int num)
{
    while (num != 1 && num != 4)
    {
        int sum = 0;
        int n = num;
        while (n > 0)
        {
            int digit = n % 10;
            sum += digit * digit;
            n /= 10;
        }
        num = sum;
    }
    if (num == 1)
        return true;
    return false;
}
//!                            ********** NOTE *********
/*
 * We used 4 number in while condition because all the unhappy number's sum is equal to 4 at the end when asnwer comes out.
 * Example: 2 is an unhappy number if we calculate its sum:
 * 2*2=4, 4*4=16, 1*1+6*6=37, 3*3+7*7=58, 5*5+8*8=89, 8*8+9*9=145, 1*1+4*4+5*5=42, 4*4+2*2=20, 2*2+0*0=4. Here the some comes out is equal to 4. So, when sum will be 4 then loop will termiinate and return false.
 * Similarly, We used 1 number in while condition because all the happy number's sum is equal to 1 at the end when asnwer comes out.
 * Example: 19 is a happy number if we calculate its sum:
 * 1*1+9*9=82, 8*8+2*2=68, 6*6+8*8=100, 1*1+0*0+0*0=1. Here the some comes out is equal to 1. So, when sum will be 1 then loop will termiinate and return true.
 */