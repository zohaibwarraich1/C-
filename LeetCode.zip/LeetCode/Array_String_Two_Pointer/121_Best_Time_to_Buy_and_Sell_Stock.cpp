#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
#include <unistd.h>
using namespace std;

//?                             ********** Question *********
//* Write  program to calculate Max Profit by buying and selling stock.

//* Prototype
int maxProfit(vector<int> prices);

int main()
{
    vector<int> prices = {9, 3, 8, 2, 6};
    int maxprofit = maxProfit(prices);
    cout << maxprofit;
    return 0;
}
int maxProfit(vector<int> prices)
{
    int max = 0;
    int min = prices[0];
    for (int i = 0; i < prices.size(); i++)
    {
        if (prices[i] < min)
        {
            min = prices[i];
        }
        int profit = prices[i] - min;
        if (max < profit)
        {
            max = profit;
        }
    }
    return max;
}