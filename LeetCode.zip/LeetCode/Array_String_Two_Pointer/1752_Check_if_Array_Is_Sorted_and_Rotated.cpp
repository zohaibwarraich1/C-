#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
bool check(vector<int> &nums)
{
    int size = nums.size();
    int count = 0;
    for (int i = 0; i < nums.size(); i++)
    {
        if (i == size - 1)
        {
            if (nums[i] > nums[0])
            {
                count++;
            }
        }
        else if (nums[i] > nums[i + 1] && i != size - 1)
        {
            count++;
        }
    }
    if (count <= 1)
        return true;
    else
        return false;
}
int main()
{
    vector<int> nums = {3, 4, 5, 1, 2};
    if (check(nums))
        cout << "True";
    else
    {
        cout << "False";
    }
    return 0;
}