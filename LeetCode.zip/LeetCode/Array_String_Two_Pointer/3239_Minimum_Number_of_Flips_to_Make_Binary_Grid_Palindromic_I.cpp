#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int minFlips(vector<vector<int>> &grid)
{
    int first = 0;
    for (int i = 0; i < grid.size(); i++)
    {
        int l = 0;
        int r = grid[i].size() - 1;
        while (l < r)
        {
            if (grid[i][l] != grid[i][r])
            {
                first++;
            }
            l++;
            r--;
        }
    }
    int second = 0;
    for (int i = 0; i < grid[0].size(); i++)
    {
        int l = 0;
        int r = grid.size() - 1;
        while (l < r)
        {
            if (grid[l][i] != grid[r][i])
            {
                second++;
            }
            l++;
            r--;
        }
    }
    return min(first, second);
}
int main()
{
    vector<vector<int>> grid = {{1, 0, 0}, {0, 0, 0}, {0, 0, 1}};
    cout << minFlips(grid);
    return 0;
}