#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool isPalindrome(string word)
{
    int l = 0;
    int r = word.size() - 1;
    while (l < r)
    {
        if (word[l] != word[r])
        {
            return false;
        }
        l++;
        r--;
    }
    return true;
}
string firstPalindrome(vector<string> &words)
{
    for (int i = 0; i < words.size(); i++)
    {
        if (isPalindrome(words[i]))
        {
            return words[i];
        }
    }
    return "";
}
int main()
{
    vector<string> words = {"abc", "car", "ada", "racecar", "cool"};
    cout << firstPalindrome(words);
    return 0;
}