#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
void setZeroes(vector<vector<int>> &matrix)
{
    multimap<int, int> mp;
    for (int i = 0; i < matrix.size(); i++)
    {
        for (int j = 0; j < matrix[i].size(); j++)
        {
            if (matrix[i][j] == 0)
            {
                mp.insert({i, j});
            }
        }
    }
    for (auto it = mp.begin(); it != mp.end(); it++)
    {
        for (int i = 0; i < matrix[it->first].size(); i++)
        {
            matrix[it->first][i] = 0;
        }
    }
    for (auto it = mp.begin(); it != mp.end(); it++)
    {
        for (int i = 0; i < matrix.size(); i++)
        {
            matrix[i][it->second] = 0;
        }
    }
}
int main()
{
    vector<vector<int>> matrix = {{0, 1, 2, 0}, {3, 4, 5, 2}, {1, 3, 1, 5}};
    setZeroes(matrix);
    for (auto ele : matrix)
    {
        for (auto ele2 : ele)
        {
            cout << ele2 << " ";
        }
        cout << endl;
    }
    return 0;
}