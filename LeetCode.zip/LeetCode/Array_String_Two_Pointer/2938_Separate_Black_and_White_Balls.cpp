#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
long long minimumSteps(string s)
{
    long long swaps = 0;
    int countOnes = 0;
    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == '1')
        {
            countOnes++;
        }
        else if (s[i] == '0')
        {
            swaps += countOnes;
        }
    }
    return swaps;
}
int main()
{
    string s = "101";
    cout << minimumSteps(s);
    return 0;
}