#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int countSeniors(vector<string> &details)
{
    int count = 0;
    for (int i = 0; i < details.size(); i++)
    {
        string temp;
        temp.push_back(details[i][11]);
        temp.push_back(details[i][12]);
        int age = stoi(temp);
        if (age > 60)
        {
            count++;
        }
    }
    return count;
}
int main()
{
    vector<string> details = {"7868190130M7522", "5303914400F9211", "9273338290F4010"};
    cout << countSeniors(details);
    return 0;
}