#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
bool threeConsecutiveOdds(vector<int> &arr)
{
    int oddCount = 0;
    for (int i = 0; i < arr.size(); i++)
    {
        if (oddCount == 3)
        {
            break;
        }
        if (arr[i] % 2 != 0)
        {
            oddCount++;
        }
        else
            oddCount = 0;
    }
    if (oddCount == 3)
    {
        return true;
    }
    return false;
}
int main()
{
    vector<int> arr = {1, 2, 3, 4, 5, 8, 23, 12};
    if (threeConsecutiveOdds(arr))
        cout << "True";
    else
        cout << "False";
    return 0;
}