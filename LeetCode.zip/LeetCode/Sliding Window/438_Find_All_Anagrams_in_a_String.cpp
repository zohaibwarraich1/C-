#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> findAnagrams(string s, string p)
{
    multimap<char, int> mpS;
    multimap<char, int> mpP;
    for (int i = 0; i < p.length(); i++)
    {
        mpS.insert(make_pair(s[i], 1));
        mpP.insert(make_pair(p[i], 1));
    }
    vector<int> result;
    for (int i = p.length(); i <= s.length(); i++)
    {
        if (mpS == mpP)
            result.push_back(i - p.length());
        auto it = mpS.find(s[i - p.length()]);
        mpS.erase(it);
        mpS.insert(make_pair(s[i], 1));
    }
    return result;
}
int main()
{
    string s = "cbaebabacd";
    string p = "abc";
    vector<int> result = findAnagrams(s, p);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}