#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> maxSlidingWindow(vector<int> &nums, int k)
{
    deque<int> q1;
    vector<int> result;
    for (int i = 0; i < nums.size(); i++)
    {
        if (!q1.empty() && q1.front() == i - k)
        {
            q1.pop_front();
        }
        while (!q1.empty() && nums[q1.back()] < nums[i])
        {
            q1.pop_back();
        }
        q1.push_back(i);
        if (i >= k - 1)
        {
            result.push_back(nums[q1.front()]);
        }
    }
    return result;
}
int main()
{
    vector<int> nums = {1, 2, 3, 4, 8, 6};
    vector<int> result = maxSlidingWindow(nums, 2);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}