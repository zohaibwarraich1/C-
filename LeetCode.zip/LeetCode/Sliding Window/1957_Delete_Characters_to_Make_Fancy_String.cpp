#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
string makeFancyString(string s)
{
    int l = 0;
    int r = 0;
    string res;
    while (r < s.length())
    {
        while ((r - l) + 1 >= 3)
        {
            l++;
        }
        r++;
        while (l < r && s[l] != s[r])
        {
            res.push_back(s[l]);
            l++;
        }
    }
    return res;
}
int main()
{
    string s = "leeetcode";
    cout << makeFancyString(s);
    return 0;
}