#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int divisorSubstrings(int num, int k)
{
    string numToString = to_string(num);
    string temp;
    int count = 0;
    for (int i = 0; i < k; i++)
    {
        temp.push_back(numToString[i]);
    }
    if (num % stoi(temp) == 0)
    {
        count++;
    }
    for (int i = k; i < numToString.size(); i++)
    {
        temp.push_back(numToString[i]);
        temp.erase(0, 1);
        int diff = stoi(temp);
        if (diff == 0)
        {
            continue;
        }
        if (num % stoi(temp) == 0)
        {
            count++;
        }
    }
    return count;
}
int main()
{
    int num = 240;
    cout << divisorSubstrings(num, 2);
    return 0;
}