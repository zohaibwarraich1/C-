#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
string findSubstring(string s, int k)
{
    unordered_set<char> vowels = {'a', 'e', 'i', 'o', 'u'};
    int cur = 0, best = 0, ans = 0;

    for (int i = 0; i < k; ++i)
    {
        if (vowels.count(s[i]))
        {
            cur++;
        }
    }
    best = cur;
    int start = 0;
    int end = 0;
    if (cur > 0)
    {
        end = k - 1;
    }
    for (int i = k; i < s.length(); ++i)
    {
        if (vowels.count(s[i]))
        {
            cur++;
        }
        if (vowels.count(s[i - k]))
        {
            cur--;
        }
        if (cur > best)
        {
            best = cur;
            start = i - k + 1;
            end = i;
        }
    }
    string result;
    if (end > 0)
    {
        for (int i = start; i <= end; i++)
        {
            result.push_back(s[i]);
        }
    }
    if (result != "")
    {
        return result;
    }
    else
    {
        return "Not found!";
    }
}
int main()
{
    string s = "azerdii";
    cout << findSubstring(s, 5);
    return 0;
}