#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int numberOfSubarrays(vector<int> &nums, int k)
{
    int r = 0;
    int l = 0;
    int countOdds = 0;
    int result = 0;
    int prev = 0;
    while (r < nums.size())
    {
        if (nums[r] % 2 == 1 && countOdds < k)
        {
            prev = 0;
            countOdds++;
        }
        while (countOdds == k)
        {
            if (nums[l] % 2 == 1)
            {
                countOdds--;
            }
            prev++;
            l++;
        }
        if (prev != 0)
        {
            result += prev;
        }
        else if (nums[r] % 2 == 0 && countOdds < k)
        {
            result += prev;
        }
        r++;
    }
    return result;
}
int main()
{
    vector<int> nums = {2, 1, 2};
    cout << numberOfSubarrays(nums, 1);
    return 0;
}