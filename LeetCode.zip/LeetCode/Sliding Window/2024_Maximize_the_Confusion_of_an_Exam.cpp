#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int maxConsecutiveAnswers(string answerKey, int k)
{
    int s = 0;
    int e = 0;
    int tempK = 0;
    int MaxTs = INT_MIN;
    while (e < answerKey.size())
    {
        if (answerKey[e] == 'T')
        {
            e++;
        }
        else if (answerKey[e] == 'F' && tempK < k)
        {
            e++;
            tempK++;
        }
        else
        {
            while (tempK >= k)
            {
                if (answerKey[s] == 'F')
                {
                    tempK--;
                }
                s++;
            }
        }
        MaxTs = max(MaxTs, e - s);
    }
    int s2 = 0;
    int e2 = 0;
    int tempK2 = 0;
    int MaxFs = INT_MIN;
    while (e2 < answerKey.size())
    {
        if (answerKey[e2] == 'F')
        {
            e2++;
        }
        else if (answerKey[e2] == 'T' && tempK2 < k)
        {
            e2++;
            tempK2++;
        }
        else
        {
            while (tempK2 >= k)
            {
                if (answerKey[s2] == 'T')
                {
                    tempK2--;
                }
                s2++;
            }
        }
        MaxFs = max(MaxFs, e2 - s2);
    }
    return max(MaxTs, MaxFs);
}
int main()
{
    string answerKey = "TFFT";
    cout << maxConsecutiveAnswers(answerKey, 1);
    return 0;
}