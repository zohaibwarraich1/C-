#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int numOfSubarrays(vector<int> &arr, int k, int threshold)
{
    int sum = 0;
    int subarrays = 0;
    int l = 0;
    int r = 0;
    while (r < k)
    {
        sum += arr[r];
        r++;
    }
    if ((sum / k) >= threshold)
    {
        subarrays++;
    }
    while (r < arr.size())
    {
        sum -= arr[l];
        sum += arr[r];
        if ((sum / k) >= threshold)
        {
            subarrays++;
        }
        l++;
        r++;
    }
    return subarrays;
}
int main()
{
    vector<int> arr = {2, 2, 2, 2, 5, 5, 5, 8};
    cout << numOfSubarrays(arr, 3, 4);
    return 0;
}