#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int maxSatisfied(vector<int> &customers, vector<int> &grumpy, int minutes)
{
    int satisfied = 0;
    for (int i = 0; i < customers.size(); i++)
    {
        if (grumpy[i] == 0)
        {
            satisfied += customers[i];
        }
    }
    int Max = INT_MIN;
    int sum = 0;
    for (int i = 0; i < minutes; i++)
    {
        if (grumpy[i] == 1)
        {
            sum += customers[i];
        }
    }
    Max = sum;
    for (int i = minutes; i < customers.size(); i++)
    {
        if (grumpy[i - minutes] == 1)
        {
            sum = sum - customers[i - minutes];
        }
        if (grumpy[i] == 1)
        {
            sum += customers[i];
        }
        Max = max(Max, sum);
    }
    return satisfied + Max;
}
int main()
{
    vector<int> customers = {1, 0, 1, 2, 1, 1, 7, 5};
    vector<int> grumpy = {0, 1, 0, 1, 0, 1, 0, 1};
    cout << maxSatisfied(customers, grumpy, 3);
    return 0;
}