#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void generate(int n, string s, vector<string> &ans)
{
    if (n == 0)
    {
        bool flag = true;
        for (int i = 0; i < s.length() - 1; i++)
        {
            if (s[i] == '0' && s[i + 1] == '0')
            {
                flag = false;
                break;
            }
        }
        if (flag)
            ans.push_back(s);
        return;
    }
    for (int i = 0; i <= 1; i++)
    {
        s.push_back(i + 48);
        generate(n - 1, s, ans);
        s.pop_back();
    }
}
vector<string> validStrings(int n)
{
    vector<string> ans;
    generate(n, "", ans);
    return ans;
}
int main()
{
    vector<string> res = validStrings(3);
    for (auto i : res)
    {
        cout << i << " ";
    }
    return 0;
}