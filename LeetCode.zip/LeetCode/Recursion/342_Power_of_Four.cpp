#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool isPowerOfFour(int n)
{
    if (n == 1)
        return true;
    if (n > 1)
    {
        int div = n % 4;
        if (div == 0)
            return isPowerOfFour(n / 4);
    }
    return false;
}
int main()
{
    if (isPowerOfFour(64))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}