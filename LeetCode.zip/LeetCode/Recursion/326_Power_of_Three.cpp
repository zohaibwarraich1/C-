#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool isPowerOfThree(int n)
{
    if (n == 1)
        return true;
    if (n > 1)
    {
        int div = n % 3;
        if (div == 0)
            return isPowerOfThree(n / 3);
    }
    return false;
}
int main()
{
    if (isPowerOfThree(27))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}