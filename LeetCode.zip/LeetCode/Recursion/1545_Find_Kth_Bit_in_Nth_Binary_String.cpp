#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
string makeBits(int n)
{
    if (n <= 1)
    {
        return "0";
    }
    string s = makeBits(n - 1);
    string tempS = s;
    for (int i = 0; i < tempS.length(); i++)
    {
        if (tempS[i] == '0')
            tempS[i] = '1';
        else
            tempS[i] = '0';
    }
    reverse(tempS.begin(), tempS.end());
    s += "1" + tempS;
    return s;
}
char findKthBit(int n, int k)
{
    string s = makeBits(n);
    return s[k - 1];
}
int main()
{
    cout << findKthBit(4, 11);
    return 0;
}