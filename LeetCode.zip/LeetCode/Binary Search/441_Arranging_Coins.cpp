#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int arrangeCoins(int n)
{
    int count = 0;
    for (int i = 1; i <= n; i++)
    {
        int diff = n - i;
        if (diff < 0)
        {
            break;
        }
        else
        {
            count++;
        }
        n = diff;
    }
    return count;
}
int main()
{
    cout << arrangeCoins(5);
    return 0;
}