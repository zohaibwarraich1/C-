#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int singleNonDuplicate(vector<int> &nums)
{
    int l = 0;
    int r = nums.size() - 1;
    while (l < r)
    {
        int mid = l + (r - l) / 2;
        if (mid % 2 != 0)
        {
            mid--;
        }
        if (nums[mid] == nums[mid + 1])
        {
            l = mid + 2;
        }
        else
        {
            r = mid;
        }
    }
    return nums[l];
}
int main()
{
    vector<int> nums = {1, 1, 2, 3, 3, 4, 4};
    cout << singleNonDuplicate(nums);
    return 0;
}