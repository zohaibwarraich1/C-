#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
int peakIndexInMountainArray(vector<int> &arr)
{
    int l = 0;
    int r = arr.size() - 1;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;
        if (l == r)
        {
            break;
        }
        if (arr[mid] < arr[mid + 1])
        {
            l = mid + 1;
        }
        else
        {
            r = mid;
        }
    }
    return r;
}
int main()
{
    vector<int> nums = {1, 3, 4, 5};
    cout << "Peak index in array: " << peakIndexInMountainArray(nums);
    return 0;
}