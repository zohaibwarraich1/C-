#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int getfirst(int i, int lower, int upper, vector<int> &nums)
{
    int l = i + 1;
    int r = nums.size() - 1;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;
        long long sum = nums[i] + nums[mid];
        if (sum < lower)
        {
            l = mid + 1;
        }
        else
        {
            r = mid - 1;
        }
    }
    return l;
}
int getLast(int i, int lower, int upper, vector<int> &nums)
{
    int l = i + 1;
    int r = nums.size() - 1;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;
        long long sum = nums[i] + nums[mid];
        if (sum > upper)
        {
            r = mid - 1;
        }
        else
        {
            l = mid + 1;
        }
    }
    return r;
}
long long countFairPairs(vector<int> &nums, int lower, int upper)
{
    long long ans = 0;
    int n = nums.size();
    sort(nums.begin(), nums.end());
    for (int i = 0; i < n; i++)
    {
        int first = getfirst(i, lower, upper, nums);
        int last = getLast(i, lower, upper, nums);
        if (last >= first)
        {
            ans += (last - first + 1);
        }
    }
    return ans;
}
int main()
{
    vector<int> nums = {0, 1, 7, 4, 4, 5};
    cout << countFairPairs(nums, 3, 6);
    return 0;
}