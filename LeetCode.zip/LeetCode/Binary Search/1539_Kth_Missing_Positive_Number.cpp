#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int findKthPositive(vector<int> &arr, int k)
{
    int ans = 1;
    int count = 0;
    int index = 0;
    while (count < k)
    {
        if (index < arr.size() && ans == arr[index])
        {
            index++;
        }
        else
            count++;
        if (count < k)
            ans++;
    }
    return ans;
}
int main()
{
    vector<int> nums = {1, 2, 3, 4};
    cout << findKthPositive(nums, 2);
    return 0;
}