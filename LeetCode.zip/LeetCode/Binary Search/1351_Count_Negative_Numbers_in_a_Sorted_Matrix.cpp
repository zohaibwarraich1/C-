#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int countNegatives(vector<vector<int>> &grid)
{
    int count = 0;
    for (int i = 0; i < grid.size(); i++)
    {
        int l = 0;
        int r = grid[i].size() - 1;
        while (l <= r)
        {
            int mid = l + (r - l) / 2;
            if (grid[i][mid] < 0)
            {
                count += (r - mid) + 1;
                r = mid - 1;
            }
            else
            {
                l = mid + 1;
            }
        }
    }
    return count;
}
int main()
{
    vector<vector<int>> grid = {{3, 2}, {1, 0}};
    cout << countNegatives(grid);
    return 0;
}