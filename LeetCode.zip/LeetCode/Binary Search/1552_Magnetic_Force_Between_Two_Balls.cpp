#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool validDistance(vector<int> &position, int mid, int balls)
{
    int counter = 1;
    int place = position[0];
    for (int i = 1; i < position.size(); i++)
    {
        if (position[i] >= place + mid)
        {
            place = position[i];
            counter++;
        }
        if (counter == balls)
        {
            return true;
        }
    }
    return false;
}
int maxDistance(vector<int> &position, int m)
{
    sort(position.begin(), position.end());
    int l = 1;
    int r = position[position.size() - 1] - position[0];
    int ans = 0;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;
        if (validDistance(position, mid, m))
        {
            ans = mid;
            l = mid + 1;
        }
        else
        {
            r = mid - 1;
        }
    }
    return ans;
}
int main()
{
    vector<int> position = {1, 2, 3, 4, 7};
    cout << maxDistance(position, 3);
    return 0;
}