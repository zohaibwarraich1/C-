#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
int findMin(vector<int> &nums)
{
    int l = 0;
    int r = nums.size() - 1;
    int mid;
    while (l < r)
    {
        mid = l + (r - l) / 2;
        if (nums[mid] > nums[r])
        {
            l = mid + 1;
        }
        else if (nums[mid] < nums[r])
        {
            r = mid;
        }
        else
        {
            r--;
        }
    }
    return nums[l];
}
int main()
{
    vector<int> nums = {3, 4, 5, 1, 2};
    cout << findMin(nums);
    return 0;
}