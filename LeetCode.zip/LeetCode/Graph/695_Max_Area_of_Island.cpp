#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int dfs(vector<vector<int>> &grid, int i, int j)
{
    if (i < 0 || i == grid.size() || j < 0 || j == grid[0].size() || grid[i][j] == 0)
    {
        return 0;
    }
    int count = 1;
    grid[i][j] = 0;
    vector<pair<int, int>> pairs = {{i + 1, j}, {i - 1, j}, {i, j + 1}, {i, j - 1}};
    for (int i = 0; i < 4; i++)
    {
        count += dfs(grid, pairs[i].first, pairs[i].second);
    }
    return count;
}
int maxAreaOfIsland(vector<vector<int>> &grid)
{
    int result = 0;
    for (int i = 0; i < grid.size(); i++)
    {
        for (int j = 0; j < grid[0].size(); j++)
        {
            if (grid[i][j] == 1)
            {
                int count = dfs(grid, i, j);
                result = max(result, count);
            }
        }
    }
    return result;
}
int main()
{

    return 0;
}