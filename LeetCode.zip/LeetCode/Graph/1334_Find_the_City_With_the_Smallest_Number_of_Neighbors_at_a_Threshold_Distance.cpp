#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> Dijkstra(int start, int n,
                     vector<vector<pair<int, int>>> &adj)
{
    vector<int> distances(n, INT_MAX);
    distances[start] = 0;
    priority_queue<pair<int, int>, vector<pair<int, int>>,
                   greater<pair<int, int>>>
        pq;
    pq.push({0, start});
    map<int, int> visited;
    while (!pq.empty())
    {
        pair<int, int> p = pq.top();
        pq.pop();
        if (visited[p.second] == false)
        {
            visited[p.second] = true;
            for (int i = 0; i < adj[p.second].size(); i++)
            {
                if (adj[p.second][i].second + distances[p.second] <
                    distances[adj[p.second][i].first])
                {
                    distances[adj[p.second][i].first] =
                        adj[p.second][i].second + distances[p.second];
                    pq.push({distances[adj[p.second][i].first],
                             adj[p.second][i].first});
                }
            }
        }
    }
    return distances;
}
int findTheCity(int n, vector<vector<int>> &edges, int distanceThreshold)
{
    vector<vector<pair<int, int>>> adj(n);
    for (int i = 0; i < edges.size(); i++)
    {
        adj[edges[i][0]].push_back({edges[i][1], edges[i][2]});
        adj[edges[i][1]].push_back({edges[i][0], edges[i][2]});
    }
    int minReachableCities = INT_MAX;
    int resultCity = -1;
    for (int i = 0; i < n; i++)
    {
        vector<int> distances = Dijkstra(i, n, adj);
        int reachableCities = 0;
        for (int j = 0; j < n; j++)
        {
            if (i != j && distances[j] <= distanceThreshold)
            {
                reachableCities++;
            }
        }
        if (reachableCities <= minReachableCities)
        {
            minReachableCities = reachableCities;
            resultCity = i;
        }
    }
    return resultCity;
}
int main()
{
    vector<vector<int>> edges = {{0, 1, 3}, {1, 2, 1}, {1, 3, 4}, {2, 3, 1}};
    cout << findTheCity(4, edges, 4);
    return 0;
}