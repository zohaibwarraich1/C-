#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void DFS(vector<vector<int>> &isConnected, map<int, bool> &visited,
         int curr)
{
    visited[curr] = true;
    for (int i = 0; i < isConnected[curr].size(); i++)
    {
        if (isConnected[curr][i] == 1 && visited[i] == false)
        {
            DFS(isConnected, visited, i);
        }
    }
}
int findCircleNum(vector<vector<int>> &isConnected)
{
    map<int, bool> visited;
    int count = 0;
    for (int i = 0; i < isConnected.size(); i++)
    {
        if (visited[i] == false)
        {
            DFS(isConnected, visited, i);
            count++;
        }
    }
    return count;
}
int main()
{
    vector<vector<int>> isConnected = {{1, 1, 0}, {1, 1, 0}, {0, 0, 1}};
    cout << findCircleNum(isConnected);
    return 0;
}