#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int findCenter(vector<vector<int>> &edges)
{
    int firstEle = edges[0][0];
    int secEle = edges[0][1];
    int center = firstEle;
    if (edges[1][0] == firstEle || edges[1][1] == firstEle)
    {
        center = firstEle;
    }
    else if (edges[1][0] == secEle || edges[1][1] == secEle)
    {
        center = secEle;
    }
    return center;
}
int main()
{
    vector<vector<int>> edges{{1, 2}, {2, 3}, {4, 2}};
    cout << findCenter(edges);
    return 0;
}