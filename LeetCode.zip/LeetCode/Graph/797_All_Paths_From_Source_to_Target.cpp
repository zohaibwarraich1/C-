#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void DFS(vector<vector<int>> &res, vector<vector<int>> &graph, int curr, vector<int> store, int target)
{
    store.push_back(curr);
    for (int i = 0; i < graph[curr].size(); i++)
    {
        DFS(res, graph, graph[curr][i], store, target);
    }
    if (curr == target)
        res.push_back(store);
}
vector<vector<int>> allPathsSourceTarget(vector<vector<int>> &graph)
{
    vector<vector<int>> res;
    vector<int> store;
    int target = graph.size() - 1;
    DFS(res, graph, 0, store, target);
    return res;
}
int main()
{
    vector<vector<int>> graph = {{4, 3, 1}, {3, 2, 4}, {3}, {4}, {}};
    vector<vector<int>> res = allPathsSourceTarget(graph);
    for (int i = 0; i < res.size(); i++)
    {
        for (int j = 0; j < res[i].size(); j++)
        {
            cout << res[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}