#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> findSmallestSetOfVertices(int n, vector<vector<int>> &edges)
{
    vector<vector<int>> adj(n);
    vector<int> res;
    for (int i = 0; i < edges.size(); i++)
    {
        adj[edges[i][0]].push_back(edges[i][1]);
    }
    map<int, bool> visited;
    for (int i = 0; i < adj.size(); i++)
    {
        for (int j = 0; j < adj[i].size(); j++)
        {
            visited[adj[i][j]] = true;
        }
    }
    for (int i = 0; i < n; i++)
    {
        if (visited.find(i) == visited.end())
        {
            res.push_back(i);
        }
    }
    return res;
}
int main()
{
    vector<vector<int>> edges = {{0, 1}, {0, 2}, {2, 5}, {3, 4}, {4, 2}};
    vector<int> res = findSmallestSetOfVertices(5, edges);
    for (auto ele : res)
    {
        cout << ele << " ";
    }
    return 0;
}