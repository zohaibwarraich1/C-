#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int DFS(vector<vector<int>> &adj, map<int, int> &visited, int curr,
        int seats, long long &ans)
{
    visited[curr] = true;
    int people = 1;
    for (int i = 0; i < adj[curr].size(); i++)
    {
        if (!visited[adj[curr][i]])
        {
            people += DFS(adj, visited, adj[curr][i], seats, ans);
        }
    }
    if (curr != 0)
    {
        ans += (people + seats - 1) / seats;
    }
    return people;
}
long long minimumFuelCost(vector<vector<int>> &roads, int seats)
{
    int n = roads.size();
    vector<vector<int>> adj(n + 1);
    map<int, int> visited;
    for (int i = 0; i < roads.size(); i++)
    {
        adj[roads[i][0]].push_back(roads[i][1]);
        adj[roads[i][1]].push_back(roads[i][0]);
    }
    long long ans = 0;
    DFS(adj, visited, 0, seats, ans);
    return ans;
}
int main()
{
    vector<vector<int>> roads = {{0, 1}, {0, 2}, {1, 3}, {1, 4}, {2, 5}, {2, 6}};
    cout << minimumFuelCost(roads, 3);
    return 0;
}