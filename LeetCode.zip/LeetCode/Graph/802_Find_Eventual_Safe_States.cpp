#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool isCyclicUtil(vector<vector<int>> adj, int u, map<int, bool> &visited, map<int, bool> &recStack)
{
    visited[u] = true;
    recStack[u] = true;
    for (int x : adj[u])
    {
        if (!visited[x])
        {
            if (isCyclicUtil(adj, x, visited, recStack))
            {
                return true;
            }
        }
        else if (recStack[x])
        {
            return true;
        }
    }
    recStack[u] = false;
    return false;
}
vector<int> eventualSafeNodes(vector<vector<int>> &graph)
{
    int V = graph.size();
    vector<vector<int>> adj;
    for (int i = 0; i < V; i++)
    {
        adj.push_back(graph[i]);
    }
    map<int, bool> visited;
    map<int, bool> recStack;
    for (int i = 0; i < V; i++)
    {
        if (!visited[i])
        {
            isCyclicUtil(adj, i, visited, recStack);
        }
    }
    vector<int> safeNodes;
    for (int i = 0; i < V; i++)
    {
        if (recStack[i] == false)
        {
            safeNodes.push_back(i);
        }
    }
    return safeNodes;
}
int main()
{
    vector<vector<int>> graph = {{1, 2}, {2, 3}, {5}, {0}, {5}, {}, {}};
    vector<int> result = eventualSafeNodes(graph);
    for (int i = 0; i < result.size(); i++)
    {
        cout << result[i] << " ";
    }
    return 0;
}