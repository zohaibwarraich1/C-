#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void DFS(map<int, bool> &vis, vector<vector<int>> &graph, int curr)
{
    vis[curr] = true;
    for (int neighbor : graph[curr])
    {
        if (!vis[neighbor])
        {
            DFS(vis, graph, neighbor);
        }
    }
}
int makeConnected(int n, vector<vector<int>> &connections)
{
    if (connections.size() < n - 1)
    {
        return -1;
    }
    vector<vector<int>> graph(n);
    for (const auto &conn : connections)
    {
        graph[conn[0]].push_back(conn[1]);
        graph[conn[1]].push_back(conn[0]);
    }
    map<int, bool> vis;
    int components = 0;
    for (int i = 0; i < n; i++)
    {
        if (!vis[i])
        {
            components++;
            DFS(vis, graph, i);
        }
    }
    return components - 1;
}
int main()
{
    vector<vector<int>> connections = {{0, 1}, {0, 2}, {1, 2}};
    cout << makeConnected(4, connections);
    return 0;
}