#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void dfs(int i, vector<vector<int>> &stones, vector<bool> &visited)
{
    visited[i] = true;
    for (int j = 0; j < stones.size(); ++j)
    {
        if (!visited[j] && (stones[i][0] == stones[j][0] ||
                            stones[i][1] == stones[j][1]))
        {
            dfs(j, stones, visited);
        }
    }
}
int removeStones(vector<vector<int>> &stones)
{
    int n = stones.size();
    vector<bool> visited(n, false);
    int numOfComponents = 0;
    for (int i = 0; i < n; ++i)
    {
        if (!visited[i])
        {
            dfs(i, stones, visited);
            numOfComponents++;
        }
    }
    return n - numOfComponents;
}
int main()
{
    vector<vector<int>> stones = {{0, 0}};
    cout << removeStones(stones);
    return 0;
}