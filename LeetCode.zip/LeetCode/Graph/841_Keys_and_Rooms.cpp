#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void DFS(vector<vector<int>> &rooms, map<int, bool> &visited, int curr)
{
    visited[curr] = true;
    for (int i = 0; i < rooms[curr].size(); i++)
    {
        if (!visited[rooms[curr][i]])
        {
            DFS(rooms, visited, rooms[curr][i]);
        }
    }
}
bool canVisitAllRooms(vector<vector<int>> &rooms)
{
    map<int, bool> visited;
    DFS(rooms, visited, 0);
    for (int i = 1; i < rooms.size(); i++)
    {
        if (!visited[i])
        {
            return false;
        }
    }
    return true;
}
int main()
{
    vector<vector<int>> rooms = {{1, 3}, {3, 0, 1}, {2}, {0}};
    if (canVisitAllRooms(rooms))
        cout << "True";
    else
        cout << "False";
    return 0;
}