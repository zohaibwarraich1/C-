#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void DFS(vector<vector<int>> &adj, map<int, bool> &visited, int curr, int &nodes, int &edges)
{
    visited[curr] = true;
    nodes++;
    edges += adj[curr].size();
    for (int i = 0; i < adj[curr].size(); i++)
    {
        if (!visited[adj[curr][i]])
        {
            DFS(adj, visited, adj[curr][i], nodes, edges);
        }
    }
}
int countCompleteComponents(int n, vector<vector<int>> &edges)
{
    vector<vector<int>> adj(n);
    for (int i = 0; i < edges.size(); i++)
    {
        adj[edges[i][0]].push_back(edges[i][1]);
        adj[edges[i][1]].push_back(edges[i][0]);
    }
    map<int, bool> visited;
    int completeComponents = 0;
    for (int i = 0; i < adj.size(); i++)
    {
        if (!visited[i])
        {
            int nodes = 0;
            int edges = 0;
            DFS(adj, visited, i, nodes, edges);
            if (edges / 2 == nodes * (nodes - 1) / 2) //* formula to calculate edges and vertices in a single connected component.
            {
                completeComponents++;
            }
        }
    }
    return completeComponents;
}
int main()
{
    vector<vector<int>> edges = {{0, 1}, {0, 2}, {1, 2}, {3, 4}};
    cout << countCompleteComponents(6, edges);
    return 0;
}