#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int networkDelayTime(vector<vector<int>> &times, int n, int k)
{
    vector<vector<pair<int, int>>> adj(n + 1);
    for (int i = 0; i < times.size(); i++)
    {
        adj[times[i][0]].push_back({times[i][1], times[i][2]});
    }
    vector<int> distances(n + 1, INT_MAX);
    map<int, int> visited;
    distances[k] = 0;
    priority_queue<pair<int, int>, vector<pair<int, int>>,
                   greater<pair<int, int>>>
        pq;
    pq.push({0, k});
    while (!pq.empty())
    {
        int u = pq.top().second;
        pq.pop();
        if (visited[u] == false)
        {
            visited[u] = true;
            for (int i = 0; i < adj[u].size(); i++)
            {
                int w = adj[u][i].second;
                int v = adj[u][i].first;
                if (distances[u] + w < distances[v])
                {
                    distances[v] = distances[u] + w;
                    pq.push({distances[v], v});
                }
            }
        }
    }
    int res = 0;
    for (int i = 1; i <= n; i++)
    {
        if (distances[i] == INT_MAX)
        {
            return -1;
        }
        res = max(res, distances[i]);
    }
    return res;
}
int main()
{
    vector<vector<int>> times = {{2, 1, 1}, {2, 3, 1}, {3, 4, 1}};
    cout << networkDelayTime(times, 4, 2);
    return 0;
}