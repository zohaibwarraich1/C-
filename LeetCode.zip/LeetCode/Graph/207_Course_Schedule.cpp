#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool isCyclicUtil(vector<vector<int>> adj, int u, map<int, bool> &visited,
                  map<int, bool> &recStack)
{
    visited[u] = true;
    recStack[u] = true;
    for (int x : adj[u])
    {
        if (!visited[x])
        {
            if (isCyclicUtil(adj, x, visited, recStack))
            {
                return true;
            }
        }
        else if (recStack[x])
        {
            return true;
        }
    }
    recStack[u] = false;
    return false;
}
bool canFinish(int numCourses, vector<vector<int>> &prerequisites)
{
    int V = numCourses;
    vector<vector<int>> adj(V);
    for (int i = 0; i < prerequisites.size(); i++)
    {
        adj[prerequisites[i][1]].push_back(prerequisites[i][0]);
    }
    map<int, bool> visited;
    map<int, bool> recStack;
    for (int i = 0; i < adj.size(); i++)
    {
        if (!visited[i] && isCyclicUtil(adj, i, visited, recStack))
        {
            return false;
        }
    }
    return true;
}
int main()
{
    vector<vector<int>> prerequisites = {{1, 0}, {0, 1}};
    if (canFinish(2, prerequisites))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}