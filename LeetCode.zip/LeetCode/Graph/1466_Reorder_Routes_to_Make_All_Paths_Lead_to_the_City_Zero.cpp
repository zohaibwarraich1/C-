#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void DFS(vector<vector<int>> &adj, set<pair<int, int>> &list, map<int, bool> &visited, int curr, int &routes)
{
    visited[curr] = true;
    for (int i = 0; i < adj[curr].size(); i++)
    {
        if (!visited[adj[curr][i]])
        {
            if (list.find({curr, adj[curr][i]}) != list.end())
            {
                routes++;
            }
            DFS(adj, list, visited, adj[curr][i], routes);
        }
    }
}
int minReorder(int n, vector<vector<int>> &connections)
{
    vector<vector<int>> adj(n);
    set<pair<int, int>> list;
    map<int, bool> visited;
    for (int i = 0; i < connections.size(); i++)
    {
        adj[connections[i][0]].push_back(connections[i][1]);
        adj[connections[i][1]].push_back(connections[i][0]);
        list.insert(make_pair(connections[i][0], connections[i][1]));
    }
    int routes = 0;
    for (int i = 0; i < adj.size(); i++)
    {
        if (!visited[i])
        {
            DFS(adj, list, visited, i, routes);
        }
    }
    return routes;
}
int main()
{
    vector<vector<int>> connections = {{0, 1}, {1, 3}, {2, 3}, {4, 0}, {4, 5}};
    cout << minReorder(6, connections);
    return 0;
}