#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
double maxProbability(int n, vector<vector<int>> &edges, vector<double> &succProb, int start_node, int end_node)
{
    vector<vector<pair<int, double>>> adj(n);
    for (int i = 0; i < edges.size(); i++)
    {
        adj[edges[i][0]].push_back({edges[i][1], succProb[i]});
        adj[edges[i][1]].push_back({edges[i][0], succProb[i]});
    }
    map<int, int> visited;
    priority_queue<pair<double, int>> pq;
    pq.push({1, start_node});
    vector<double> dist(n, 0);
    dist[start_node] = 1;
    while (!pq.empty())
    {
        int u = pq.top().second;
        pq.pop();
        if (visited[u] == false)
        {
            visited[u] = true;
            for (int i = 0; i < adj[u].size(); i++)
            {
                int v = adj[u][i].first;
                double w = adj[u][i].second;
                if (dist[u] * w > dist[v])
                {
                    dist[v] = dist[u] * w;
                    pq.push({dist[v], v});
                }
            }
        }
    }
    if (dist[end_node] == INT_MIN)
    {
        return 0;
    }
    else
    {
        return dist[end_node];
    }
}
int main()
{
    vector<vector<int>> edges = {{0, 1}, {1, 2}, {0, 2}};
    vector<double> succProb = {0.5, 0.5, 0.2};
    cout << maxProbability(3, edges, succProb, 0, 2);
    return 0;
}