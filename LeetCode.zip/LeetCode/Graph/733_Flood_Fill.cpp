#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<vector<int>> floodFill(vector<vector<int>> &image, int sr, int sc,
                              int color)
{
    int rows = image.size();
    int cols = image[0].size();
    int originalColor = image[sr][sc];
    if (originalColor == color)
        return image;
    vector<pair<int, int>> directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
    queue<pair<int, int>> q;
    q.push({sr, sc});
    image[sr][sc] = color;
    while (!q.empty())
    {
        int currentRow = q.front().first;
        int currentCol = q.front().second;
        q.pop();
        for (auto dir : directions)
        {
            int newRow = currentRow + dir.first;
            int newCol = currentCol + dir.second;
            if (newRow >= 0 && newRow < rows && newCol >= 0 &&
                newCol < cols && image[newRow][newCol] == originalColor)
            {
                image[newRow][newCol] = color;
                q.push({newRow, newCol});
            }
        }
    }
    return image;
}
int main()
{
    vector<vector<int>> image{{1, 1, 1}, {1, 1, 0}, {1, 0, 1}};
    vector<vector<int>> res = floodFill(image, 1, 1, 2);
    for (int i = 0; i < res.size(); i++)
    {
        for (int j = 0; j < res[i].size(); j++)
        {
            cout << res[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}