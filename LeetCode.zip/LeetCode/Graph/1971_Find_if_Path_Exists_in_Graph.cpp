#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void check(map<int, bool> &vis, vector<vector<int>> &adj, int curr)
{
    vis[curr] = true;
    for (int i = 0; i < adj[curr].size(); i++)
    {
        if (!vis[adj[curr][i]])
        {
            check(vis, adj, adj[curr][i]);
        }
    }
}
bool validPath(int n, vector<vector<int>> &edges, int source,
               int destination)
{
    vector<vector<int>> adj(n);
    for (auto edge : edges) //? creating adjacency list because the give array is in pair form of edges. First we convert that into a list of edges of each vertex and then apply dfs.
    {
        adj[edge[0]].push_back(edge[1]);
        adj[edge[1]].push_back(edge[0]);
    }
    map<int, bool> vis;
    check(vis, adj, source);
    return vis[destination];
}
int main()
{
    vector<vector<int>> edges = {{0, 1}, {0, 2}, {3, 5}, {5, 4}, {4, 3}};
    if (validPath(6, edges, 0, 5))
        cout << "True";
    else
        cout << "False";
    return 0;
}