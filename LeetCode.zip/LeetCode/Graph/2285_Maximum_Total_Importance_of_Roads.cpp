#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
long long maximumImportance(int n, vector<vector<int>> &roads)
{
    vector<vector<int>> adj(n);
    for (int i = 0; i < roads.size(); i++)
    {
        adj[roads[i][0]].push_back(roads[i][1]);
        adj[roads[i][1]].push_back(roads[i][0]);
    }
    priority_queue<pair<int, int>> pq;
    for (int i = 0; i < adj.size(); i++)
    {
        pq.push(make_pair(adj[i].size(), i));
    }
    map<int, long long> mapping;
    while (!pq.empty())
    {
        mapping[pq.top().second] = n;
        n--;
        pq.pop();
    }
    long long sum = 0;
    for (int i = 0; i < roads.size(); i++)
    {
        sum += mapping[roads[i][0]] + mapping[roads[i][1]];
    }
    return sum;
}
int main()
{
    vector<vector<int>> roads = {{0, 1}, {1, 2}, {2, 3}, {0, 2}, {1, 3}, {2, 4}};
    cout << maximumImportance(5, roads);
    return 0;
}