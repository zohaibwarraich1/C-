#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void DFS(vector<vector<pair<int, double>>> adj, map<int, bool> &visited,
         int start, int end, double product, double &ans)
{
    visited[start] = true;
    if (start == end)
    {
        ans = product;
        return;
    }
    for (int i = 0; i < adj[start].size(); i++)
    {
        int v = adj[start][i].first;
        double w = adj[start][i].second;
        if (!visited[v])
        {
            DFS(adj, visited, v, end, product * w, ans);
        }
    }
}
vector<double> calcEquation(vector<vector<string>> &equations,
                            vector<double> &values,
                            vector<vector<string>> &queries)
{
    unordered_map<string, int> strToIndex;
    int count = 0;
    for (int i = 0; i < equations.size(); i++)
    {
        string u = equations[i][0], v = equations[i][1];
        if (strToIndex.find(u) == strToIndex.end())
        {
            strToIndex[u] = count++;
        }
        if (strToIndex.find(v) == strToIndex.end())
        {
            strToIndex[v] = count++;
        }
    }
    int n = equations.size();
    vector<vector<pair<int, double>>> adj(strToIndex.size());
    for (int i = 0; i < equations.size(); i++)
    {
        int u = strToIndex[equations[i][0]];
        int v = strToIndex[equations[i][1]];
        adj[u].push_back({v, values[i]});
        adj[v].push_back({u, 1.0 / values[i]});
    }
    vector<double> res;
    for (int i = 0; i < queries.size(); i++)
    {
        string s = queries[i][0];
        string e = queries[i][1];
        double product = 1;
        double ans = -1;
        map<int, bool> visited;
        if (strToIndex.find(s) != strToIndex.end() &&
            strToIndex.find(e) != strToIndex.end())
        {
            int start = strToIndex[s];
            int end = strToIndex[e];
            DFS(adj, visited, start, end, product, ans);
        }
        res.push_back(ans);
    }
    return res;
}
int main()
{
    vector<vector<string>> equations = {{"a", "b"}, {"b", "c"}};
    vector<double> values = {2.0, 3.0};
    vector<vector<string>> queries = {{"a", "c"}, {"b", "a"}, {"a", "e"}, {"a", "a"}, {"x", "x"}};
    vector<double> res = calcEquation(equations, values, queries);
    for (auto i : res)
    {
        cout << i << " ";
    }
    return 0;
}