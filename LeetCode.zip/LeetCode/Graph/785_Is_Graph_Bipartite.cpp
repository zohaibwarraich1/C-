#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
bool isBipartite(vector<vector<int>> &graph)
{
    int n = graph.size();
    vector<int> vis(n, -1);
    for (int start = 0; start < n; ++start)
    {
        if (vis[start] == -1)
        {
            queue<int> q;
            q.push(start);
            vis[start] = 0;
            while (!q.empty())
            {
                int top = q.front();
                q.pop();
                for (int i = 0; i < graph[top].size(); i++)
                {
                    if (vis[graph[top][i]] == -1)
                    {
                        q.push(graph[top][i]);
                        if (vis[top] == 0)
                        {
                            vis[graph[top][i]] = 1;
                        }
                        else if (vis[top] == 1)
                        {
                            vis[graph[top][i]] = 0;
                        }
                    }
                    else if (vis[top] == vis[graph[top][i]])
                    {
                        return false;
                    }
                }
            }
        }
    }
    return true;
}
int main()
{
    vector<vector<int>> graph = {{1, 3}, {0, 2}, {1, 3}, {0, 2}};
    if (isBipartite(graph))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}