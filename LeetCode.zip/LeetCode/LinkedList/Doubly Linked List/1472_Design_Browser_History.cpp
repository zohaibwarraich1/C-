#include <iostream>
using namespace std;
class Node
{
public:
    string val;
    Node *prev = nullptr;
    Node *next = nullptr;
    Node(string a) { val = a; }
};

class BrowserHistory
{
    Node *head = nullptr;
    Node *current = nullptr;

public:
    BrowserHistory(string homepage)
    {
        head = new Node(homepage);
        current = head;
    }
    void visit(string url)
    {
        if (head == nullptr)
        {
            Node *n1 = new Node(url);
            head = n1;
            current = n1;
        }
        else
        {
            Node *n2 = new Node(url);
            n2->prev = current;
            current->next = n2;
            current = n2;
        }
    }
    string back(int steps)
    {
        string result;
        if (steps > 0)
        {
            while (steps > 0)
            {
                if (current->prev != nullptr)
                {
                    current = current->prev;
                    steps--;
                }
                else
                {
                    break;
                }
            }
            result = current->val;
        }
        else
        {
            result = current->val;
        }
        return result;
    }
    string forward(int steps)
    {
        string result;
        if (steps > 0)
        {
            while (steps > 0)
            {
                if (current->next != nullptr)
                {
                    current = current->next;
                    steps--;
                }
                else
                {
                    break;
                }
            }
            result = current->val;
        }
        else
        {
            result = current->val;
        }
        return result;
    }
};
int main()
{
    BrowserHistory b1 = BrowserHistory("leetcode.com");
    b1.visit("google.com");
    b1.visit("facebook.com");
    b1.visit("youtube.com");
    cout << b1.back(1) << endl;
    cout << b1.back(1) << endl;
    cout << b1.forward(1) << endl;
    b1.visit("linkedin.com");
    cout << b1.forward(2) << endl;
    cout << b1.back(2) << endl;
    cout << b1.back(7) << endl;

    return 0;
}