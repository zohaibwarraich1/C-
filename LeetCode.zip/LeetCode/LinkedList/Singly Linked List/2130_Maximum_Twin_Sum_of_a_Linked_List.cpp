#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
int pairSum(ListNode *head)
{
    vector<int> storeValues;
    ListNode *temp = head;
    while (temp != nullptr)
    {
        storeValues.push_back(temp->val);
        temp = temp->next;
    }
    int l = 0;
    int r = storeValues.size() - 1;
    int maxSum = 0;
    while (l < r)
    {
        int sum = storeValues[l] + storeValues[r];
        if (maxSum < sum)
        {
            maxSum = sum;
        }
        l++;
        r--;
    }
    return maxSum;
}
int main()
{
    ListNode n3 = ListNode(4);
    ListNode n2 = ListNode(3, &n3);
    ListNode n1 = ListNode(2, &n2);
    ListNode head = ListNode(1, &n1);
    cout << pairSum(&head);
    return 0;
}