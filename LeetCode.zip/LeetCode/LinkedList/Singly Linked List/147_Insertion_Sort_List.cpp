#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
ListNode *InsertionSort(ListNode *head)
{
    if (head == nullptr || head->next == nullptr)
    {
        return head;
    }
    else
    {
        ListNode dummy = ListNode(0, head);
        ListNode *curr = head->next;
        ListNode *prev = head;
        while (curr != nullptr)
        {
            if (curr->val < prev->val)
            {
                ListNode *prev2x = &dummy;
                ListNode *temp = curr->next;
                while (prev2x->next->val < curr->val)
                {
                    prev2x = prev2x->next;
                }
                curr->next = prev2x->next;
                prev2x->next = curr;
                prev->next = temp;
                curr = temp;
            }
            else
            {
                prev = curr;
                curr = curr->next;
            }
        }
        return dummy.next;
    }
}
void print(ListNode *head)
{
    ListNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val;
        if (temp->next != nullptr)
            cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}
int main()
{
    ListNode n4 = ListNode(3);
    ListNode n3 = ListNode(5, &n4);
    ListNode n2 = ListNode(1, &n3);
    ListNode n1 = ListNode(2, &n2);
    ListNode head = ListNode(4, &n1);
    ListNode *result = InsertionSort(&head);
    print(result);
    return 0;
}