#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
void reorderList(ListNode *head)
{
    if (head == nullptr || head->next == nullptr || head->next->next == nullptr)
    {
        return;
    }
    else
    {
        int countNodes = 0;
        stack<ListNode *> nodeStack;
        ListNode *to_Add_Node_Into_Stack = head;
        while (to_Add_Node_Into_Stack != nullptr)
        {
            nodeStack.push(to_Add_Node_Into_Stack);
            to_Add_Node_Into_Stack = to_Add_Node_Into_Stack->next;
            countNodes++;
        }
        countNodes /= 2;
        ListNode *prev = head;
        ListNode *current = head->next;
        for (int i = 0; i < countNodes; i++)
        {
            prev->next = nodeStack.top();
            nodeStack.pop();
            prev = prev->next;

            prev->next = current;
            current = current->next;
            prev = prev->next;
            prev->next = nullptr;
        }
    }
}
void print(ListNode *head)
{
    ListNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val << " -> ";
        temp = temp->next;
    }
    cout << endl;
}
int main()
{
    ListNode n5 = ListNode(6);
    ListNode n4 = ListNode(5, &n5);
    ListNode n3 = ListNode(4, &n4);
    ListNode n2 = ListNode(3, &n3);
    ListNode n1 = ListNode(2, &n2);
    ListNode head = ListNode(1, &n1);
    reorderList(&head);
    print(&head);
    return 0;
}