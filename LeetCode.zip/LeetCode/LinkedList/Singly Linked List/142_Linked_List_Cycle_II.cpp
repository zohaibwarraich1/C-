#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
ListNode *detectCycle(ListNode *head)
{
    if (head == nullptr || head->next == nullptr)
    {
        return nullptr;
    }
    unordered_map<ListNode *, bool> mp;
    ListNode *temp = head;
    while (temp->next != nullptr && temp != nullptr)
    {
        if (mp[temp])
        {
            return temp;
        }
        else
        {
            mp[temp] = true;
            temp = temp->next;
        }
    }
    return nullptr;
}
int main()
{
    ListNode a3 = ListNode(1);
    ListNode a2 = ListNode(0, &a3);
    ListNode a1 = ListNode(2, &a2);
    a3.next = &a1;
    ListNode head = ListNode(3, &a1);
    ListNode *result = detectCycle(&head);
    cout << "Cycle Started at " << result->val << " node.";
    return 0;
}