#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
void print(ListNode *head)
{
    ListNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val;
        if (temp->next != nullptr)
            cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}
ListNode *reverse(ListNode *head)
{
    if (head == nullptr || head->next == nullptr)
    {
        return head;
    }
    ListNode *prev_2x = nullptr;
    ListNode *prev = head;
    ListNode *next = head->next;
    while (prev != nullptr)
    {
        prev->next = prev_2x; 
        prev_2x = prev;
        prev = next;
        if (next != nullptr)
            next = next->next;
    }
    return prev_2x;
}
ListNode *addTwoNumbers(ListNode *l1, ListNode *l2)
{
    stack<ListNode *> st1;
    stack<ListNode *> st2;
    while (l1 != nullptr)
    {
        st1.push(l1);
        l1 = l1->next;
    }
    while (l2 != nullptr)
    {
        st2.push(l2);
        l2 = l2->next;
    }
    ListNode dummy = ListNode(0);
    ListNode *point = &dummy;
    int sum = 0;
    int carry = 0;
    while (!st1.empty() || !st2.empty() || carry > 0)
    {
        sum = carry;
        if (!st1.empty())
        {
            sum += st1.top()->val;
            st1.pop();
        }
        if (!st2.empty())
        {
            sum += st2.top()->val;
            st2.pop();
        }
        carry = sum / 10;
        ListNode *store = new ListNode(sum % 10);
        point->next = store;
        point = point->next;
    }
    point = reverse(dummy.next);
    return point;
}
int main()
{
    ListNode a3 = ListNode(3);
    ListNode a2 = ListNode(4, &a3);
    ListNode a1 = ListNode(2, &a2);
    ListNode listA = ListNode(7, &a1);

    ListNode b2 = ListNode(4);
    ListNode b1 = ListNode(6, &b2);
    ListNode listB = ListNode(5, &b1);

    ListNode *result = addTwoNumbers(&listA, &listB);
    print(result);
    return 0;
}