#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class ListNode
{
public:
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
void print(ListNode *head)
{
    ListNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val;
        if (temp->next != nullptr)
            cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}
ListNode *reverseList(ListNode *head)
{
    if (head->next == nullptr || head == nullptr)
    {
        return head;
    }
    ListNode *prev_2x = nullptr;
    ListNode *prev = head;
    ListNode *next_to_prev = head->next;
    while (next_to_prev->next != nullptr)
    {
        prev->next = prev_2x;
        prev_2x = prev;
        prev = next_to_prev;
        next_to_prev = next_to_prev->next;
    }
    prev->next = prev_2x;
    prev_2x = prev;
    prev = next_to_prev;
    next_to_prev = next_to_prev->next;
    prev->next = prev_2x;
    return prev;
}
ListNode *doubleIt(ListNode *head)
{
    if (head == nullptr)
    {
        return nullptr;
    }
    ListNode dummy = ListNode(0);
    ListNode *pointer = &dummy;
    ListNode *reversed = reverseList(head);
    int value = 0;
    int carry = 0;
    while (reversed != nullptr)
    {
        value = carry;
        value += (reversed->val * 2);
        reversed = reversed->next;
        carry = value / 10;
        ListNode *store = new ListNode(value % 10);
        pointer->next = store;
        pointer = pointer->next;
    }
    if (carry > 0)
    {
        ListNode *store = new ListNode(carry);
        pointer->next = store;
        pointer = pointer->next;
    }
    pointer = reverseList(dummy.next);
    return pointer;
}
int main()
{
    ListNode n2 = ListNode(9);
    ListNode n1 = ListNode(8, &n2);
    ListNode head = ListNode(1, &n1);
    ListNode *result = doubleIt(&head);
    print(result);
    return 0;
}