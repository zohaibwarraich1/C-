#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
class Solution
{
public:
    ListNode *mergeTwoLists(ListNode *list1, ListNode *list2)
    {
        ListNode *head = new ListNode();
        ListNode *temp = head;

        //! Method 1
        while (list1 != nullptr || list2 != nullptr)
        {
            if (list1 != nullptr && (list2 == nullptr || list1->val <= list2->val))
            {
                temp->next = list1;
                list1 = list1->next;
            }
            else if (list2 != nullptr)
            {
                temp->next = list2;
                list2 = list2->next;
            }
            temp = temp->next;
        }

        //! Method 2
        /*
        while (list1->next != nullptr && list2->next != nullptr)
        {
            if (list1->val < list2->val)
            {
                temp->next = list1;
                list1 = list1->next;
            }
            else
            {
                temp->next = list2;
                list2 = list2->next;
            }
            temp = temp->next;
        }
        if (list1->next != nullptr)
        {
            temp->next = list1;
        }
        else
        {
            temp->next = list2;
        }
        */
        return head->next;
    }
};
void display(ListNode *head, ListNode *l1, ListNode *l2)
{
    while (head != nullptr)
    {
        cout << head->val << " -> ";
        head = head->next;
    }
}
int main()
{
    ListNode *l1 = new ListNode(1);
    l1->next = new ListNode(3);
    l1->next->next = new ListNode(5);
    l1->next->next->next = new ListNode(6);
    l1->next->next->next->next = new ListNode(8);
    ListNode *l2 = new ListNode(2);
    l2->next = new ListNode(3);
    l2->next->next = new ListNode(4);
    Solution s = Solution();
    ListNode *head = s.mergeTwoLists(l1, l2);
    display(head, l1, l2);
    return 0;
}