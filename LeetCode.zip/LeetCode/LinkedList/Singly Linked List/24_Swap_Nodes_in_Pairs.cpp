#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
ListNode *swapPairs(ListNode *head)
{
    if (head == NULL || head->next == NULL)
    {
        return head;
    }
    ListNode *p1 = head;
    ListNode *p2 = p1->next;
    ListNode *point = nullptr;
    bool stop = true;
    bool headChanged = false;
    while (stop)
    {
        p1->next = p2->next;
        p2->next = p1;
        if (headChanged == false)
        {
            head = p2;
            headChanged = true;
        }
        if (p1->next != nullptr && p1->next->next != nullptr)
        {
            point = p1;
            p1 = p1->next;
            p2 = p1->next;
            point->next = p2;
        }
        else
        {
            stop = false;
        }
    }
    return head;
}
void print(ListNode *head)
{
    ListNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val;
        if (temp->next != nullptr)
            cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}
int main()
{
    ListNode n4 = ListNode(5);
    ListNode n3 = ListNode(4, &n4);
    ListNode n2 = ListNode(3, &n3);
    ListNode n1 = ListNode(2, &n2);
    ListNode head = ListNode(1, &n1);
    ListNode *result = swapPairs(&head);
    print(result);
    return 0;
}