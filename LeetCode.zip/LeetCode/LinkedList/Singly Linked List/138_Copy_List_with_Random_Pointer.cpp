#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
class Node
{
public:
    int val;
    Node *next;
    Node *random;

    Node(int val)
    {
        this->val = val;
        next = NULL;
        random = NULL;
    }
};
Node *copyRandomList(Node *head)
{
    if (head == nullptr)
        return nullptr;
    Node *curr = head;
    while (curr != nullptr)
    {
        Node *newNode = new Node(curr->val);
        newNode->next = curr->next;
        curr->next = newNode;
        curr = newNode->next;
    }
    curr = head;
    while (curr != nullptr)
    {
        if (curr->random == nullptr)
        {
            curr->next->random = curr->random;
        }
        else
        {
            curr->next->random = curr->random->next;
        }
        curr = curr->next->next;
    }
    Node *resultHead = head->next;
    Node *currHead = resultHead;
    Node *currOld = head;
    while (currHead != nullptr && currHead->next != nullptr)
    {
        currOld->next = currHead->next;
        currHead->next = currHead->next->next;
        currOld = currOld->next;
        currHead = currHead->next;
    }
    currOld->next = currHead->next;
    return resultHead;
}
void printList(Node *head)
{
    Node *curr = head;
    while (curr)
    {
        cout << "[" << curr->val << ",";
        if (curr->random)
            cout << curr->random->val;
        else
            cout << "null";
        cout << "] ";
        curr = curr->next;
    }
    cout << endl;
}
int main()
{
    Node *head = new Node(7);
    head->next = new Node(13);
    head->next->next = new Node(11);
    head->next->next->next = new Node(10);
    head->next->next->next->next = new Node(1);
    head->random = nullptr;
    head->next->random = head;
    head->next->next->next->random = head->next;
    head->next->next->next->next->random = head;
    Node *copiedList = copyRandomList(head);

    cout << "Copied List: ";
    printList(copiedList);
    delete head;
    delete copiedList;
    return 0;
}