#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void InOrder(TreeNode *root, vector<int> &nums)
{
    if (root == nullptr)
    {
        return;
    }
    InOrder(root->left, nums);
    nums.push_back(root->val);
    InOrder(root->right, nums);
}
vector<int> inorderTraversal(TreeNode *root)
{
    vector<int> result;
    InOrder(root, result);
    return result;
}
int main()
{
    TreeNode *root = new TreeNode(1);
    root->right = new TreeNode(2);
    root->right->left = new TreeNode(3);
    vector<int> result = inorderTraversal(root);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}