#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
TreeNode *split(vector<int> &preorder, int &index, int l, int r,
                map<int, int> &map)
{
    if (index >= preorder.size() || l > r)
    {
        return nullptr;
    }
    TreeNode *root = new TreeNode(preorder[index]);
    int mid = map[preorder[index]];
    index++;
    root->left = split(preorder, index, l, mid - 1, map);
    root->right = split(preorder, index, mid + 1, r, map);
    return root;
}
TreeNode *buildTree(vector<int> &preorder, vector<int> &inorder)
{
    map<int, int> map;
    int n = inorder.size() - 1;
    int index = 0;
    for (int i = 0; i < inorder.size(); i++)
    {
        map[inorder[i]] = i;
    }
    return split(preorder, index, 0, n, map);
}
int main()
{
    vector<int> inorder = {9, 3, 15, 20, 7};
    vector<int> preorder = {3, 9, 20, 15, 7};
    TreeNode *root = buildTree(inorder, preorder);
    return 0;
}