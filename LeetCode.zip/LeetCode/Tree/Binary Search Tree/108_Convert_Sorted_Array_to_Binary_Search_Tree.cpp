#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
TreeNode *midRoots(vector<int> &nums, int l, int r)
{
    if (l > r)
    {
        return nullptr;
    }
    int mid = l + (r - l) / 2;
    TreeNode *root = new TreeNode(nums[mid]);
    root->left = midRoots(nums, l, mid - 1);
    root->right = midRoots(nums, mid + 1, r);
    return root;
}
TreeNode *sortedArrayToBST(vector<int> &nums)
{
    return midRoots(nums, 0, nums.size() - 1);
}
void InOrder(TreeNode *root)
{
    if (root == nullptr)
    {
        return;
    }
    InOrder(root->left);
    cout << root->val << " ";
    InOrder(root->right);
}
int main()
{
    vector<int> nums = {1, 3};
    TreeNode *root = sortedArrayToBST(nums);
    InOrder(root);
    return 0;
}