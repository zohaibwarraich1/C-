#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void InOrder(TreeNode *root, TreeNode *&pointer)
{
    if (root == nullptr)
    {
        return;
    }
    InOrder(root->left, pointer);
    TreeNode *temp = new TreeNode(root->val);
    pointer->right = temp;
    pointer = pointer->right;
    InOrder(root->right, pointer);
}
TreeNode *increasingBST(TreeNode *root)
{
    TreeNode *dummy = new TreeNode(0);
    TreeNode *pointer = dummy;
    InOrder(root, pointer);
    return dummy->right;
}
void print(TreeNode *head)
{
    TreeNode *temp = head;
    while (temp != nullptr)
    {
        cout << temp->val;
        if (temp->right != nullptr)
            cout << " -> ";
        temp = temp->right;
    }
    cout << endl;
}
int main()
{
    TreeNode *root = new TreeNode(5);
    root->left = new TreeNode(1);
    root->right = new TreeNode(7);
    TreeNode *result = increasingBST(root);
    print(result);
    return 0;
}