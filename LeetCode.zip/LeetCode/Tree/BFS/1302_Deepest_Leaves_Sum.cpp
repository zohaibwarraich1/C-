#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
int height(TreeNode *root)
{
    if (root == nullptr)
    {
        return -1;
    }
    else
    {
        int l = height(root->left);
        int r = height(root->right);
        if (l > r)
            return l + 1;
        else
            return r + 1;
    }
}
int bfs(TreeNode *root, int level)
{
    int sum = 0;
    if (root == nullptr)
    {
        return 0;
    }
    if (level == 0)
    {
        return root->val;
    }
    sum += bfs(root->left, level - 1);
    sum += bfs(root->right, level - 1);
    return sum;
}
int deepestLeavesSum(TreeNode *root)
{
    int h = height(root);
    return bfs(root, h);
}
int main()
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);
    root->right->right = new TreeNode(6);
    root->left->left->left = new TreeNode(7);
    root->right->right->right = new TreeNode(8);
    cout << deepestLeavesSum(root);
    return 0;
}