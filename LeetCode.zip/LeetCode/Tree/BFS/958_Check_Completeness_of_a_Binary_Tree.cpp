#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
bool isCompleteTree(TreeNode *root)
{
    vector<TreeNode *> nodes;
    queue<TreeNode *> q;
    q.push(root);
    while (!q.empty())
    {
        int n = q.size();
        for (int i = 0; i < n; i++)
        {
            TreeNode *r = q.front();
            q.pop();
            nodes.push_back(r);
            if (r == nullptr)
            {
                continue;
            }
            q.push(r->left);
            q.push(r->right);
        }
    }
    bool foundNull = false;
    for (int i = 0; i < nodes.size(); i++)
    {
        if (nodes[i] == nullptr)
        {
            foundNull = true;
        }
        if (foundNull == true && nodes[i] != nullptr)
        {
            return false;
        }
    }
    return true;
}
int main()
{
    TreeNode *root = new TreeNode(4);
    root->left = new TreeNode(2);
    root->left->left = new TreeNode(1);
    root->left->right = new TreeNode(3);
    root->right = new TreeNode(7);
    if (isCompleteTree(root))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}