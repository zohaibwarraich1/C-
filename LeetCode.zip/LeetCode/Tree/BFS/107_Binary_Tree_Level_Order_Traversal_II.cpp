#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode *next;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr), next(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right, TreeNode *next) : val(x), left(left), right(right), next(next) {}
};
int height(TreeNode *r)
{
    if (r == nullptr)
    {
        return -1;
    }
    else
    {
        int l = height(r->left);
        int ri = height(r->right);
        if (l > ri)
        {
            return l + 1;
        }
        else
        {
            return ri + 1;
        }
    }
}
void LevelOrder(TreeNode *r, int level, vector<int> &temp)
{
    if (r == nullptr)
    {
        return;
    }
    if (level == 0)
    {
        temp.push_back(r->val);
    }
    LevelOrder(r->left, level - 1, temp);
    LevelOrder(r->right, level - 1, temp);
}
vector<vector<int>> BFS(TreeNode *r)
{
    vector<vector<int>> result;
    int h = height(r);
    for (int i = h; i >= 0; i--)
    {
        vector<int> temp;
        LevelOrder(r, i, temp);
        result.push_back(temp);
    }
    return result;
}
vector<vector<int>> levelOrderBottom(TreeNode *root)
{
    return BFS(root);
}
int main()
{
    TreeNode *root = new TreeNode(3);
    root->left = new TreeNode(9);
    root->right = new TreeNode(20);
    root->right->left = new TreeNode(15);
    root->right->right = new TreeNode(7);
    vector<vector<int>> result = levelOrderBottom(root);
    for (auto i : result)
    {
        for (auto j : i)
        {
            cout << j << " ";
        }
        cout << endl;
    }
    return 0;
}