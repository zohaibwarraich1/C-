#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode *next;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr), next(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right, TreeNode *next) : val(x), left(left), right(right), next(next) {}
};
int height(TreeNode *root)
{
    if (root == nullptr)
    {
        return -1;
    }
    else
    {
        int l = height(root->left);
        int r = height(root->right);
        return max(l, r) + 1;
    }
}
void LevelOrder(TreeNode *r, int level, vector<int> &ans, bool &addValue)
{
    if (r == nullptr)
    {
        return;
    }
    if (level == 0 && addValue)
    {
        ans.push_back(r->val);
        addValue = false;
    }
    LevelOrder(r->right, level - 1, ans, addValue);
    LevelOrder(r->left, level - 1, ans, addValue);
}
vector<int> BFS(TreeNode *r)
{
    vector<int> ans;
    int h = height(r);
    for (int i = 0; i <= h; i++)
    {
        bool addValue = true;
        LevelOrder(r, i, ans, addValue);
    }
    return ans;
}
vector<int> rightSideView(TreeNode *root) { return BFS(root); }
int main()
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->right->right = new TreeNode(4);
    vector<int> result = rightSideView(root);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}