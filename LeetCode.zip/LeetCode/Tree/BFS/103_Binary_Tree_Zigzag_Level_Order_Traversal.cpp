#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode *next;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr), next(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right, TreeNode *next) : val(x), left(left), right(right), next(next) {}
};
int height(TreeNode *root)
{
    if (root == nullptr)
    {
        return -1;
    }
    else
    {
        int l = height(root->left);
        int r = height(root->right);
        return max(l, r) + 1;
    }
}
void LevelOrder(vector<int> &temp, TreeNode *r, int level, bool leftToRight)
{
    if (r == nullptr)
    {
        return;
    }
    if (level == 0)
    {
        temp.push_back(r->val);
    }
    if (leftToRight)
    {
        LevelOrder(temp, r->left, level - 1, leftToRight);
        LevelOrder(temp, r->right, level - 1, leftToRight);
    }
    else
    {
        LevelOrder(temp, r->right, level - 1, leftToRight);
        LevelOrder(temp, r->left, level - 1, leftToRight);
    }
}
vector<vector<int>> BFS(TreeNode *r)
{
    vector<vector<int>> result;
    int h = height(r);
    bool leftToRight = true;
    for (int i = 0; i <= h; i++)
    {
        if (i % 2 == 0)
        {
            leftToRight = true;
        }
        else
        {
            leftToRight = false;
        }
        vector<int> temp;
        LevelOrder(temp, r, i, leftToRight);
        result.push_back(temp);
    }
    return result;
}
vector<vector<int>> zigzagLevelOrder(TreeNode *root)
{
    return BFS(root);
}
int main()
{
    TreeNode *root = new TreeNode(3);
    root->left = new TreeNode(9);
    root->right = new TreeNode(20);
    root->right->left = new TreeNode(15);
    root->right->right = new TreeNode(7);
    vector<vector<int>> result = zigzagLevelOrder(root);
    for (auto i : result)
    {
        for (auto j : i)
        {
            cout << j << " ";
        }
        cout << endl;
    }
    return 0;
}