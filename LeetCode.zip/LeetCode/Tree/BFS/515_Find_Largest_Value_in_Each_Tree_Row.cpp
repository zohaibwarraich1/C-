#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
int height(TreeNode *r)
{
    if (r == nullptr)
    {
        return -1;
    }
    else
    {
        int left = height(r->left);
        int right = height(r->right);
        if (left > right)
        {
            return left + 1;
        }
        else
        {
            return right + 1;
        }
    }
}
void LevelOrder(TreeNode *r, int level, int &Max)
{
    if (r == nullptr)
    {
        return;
    }
    else if (level == 0 && r->val > Max)
    {
        Max = r->val;
    }
    LevelOrder(r->left, level - 1, Max);
    LevelOrder(r->right, level - 1, Max);
}
vector<int> BFS(TreeNode *r)
{
    int h = height(r);
    vector<int> result;
    for (int i = 0; i <= h; i++)
    {
        int Max = INT_MIN;
        LevelOrder(r, i, Max);
        result.push_back(Max);
    }
    return result;
}
vector<int> largestValues(TreeNode *root) { return BFS(root); }
int main()
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(3);
    root->left->left = new TreeNode(5);
    root->left->right = new TreeNode(3);
    root->right = new TreeNode(2);
    root->right->right = new TreeNode(9);
    vector<int> result = largestValues(root);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}