#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode *next;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr), next(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right, TreeNode *next) : val(x), left(left), right(right), next(next) {}
};
int height(TreeNode *root)
{
    if (root == nullptr)
    {
        return -1;
    }
    else
    {
        int l = height(root->left);
        int r = height(root->right);
        return max(l, r) + 1;
    }
}
void LevelOrder(TreeNode *r, int level, int &sum)
{
    if (r == nullptr)
    {
        return;
    }
    if (level == 0)
    {
        sum += r->val;
    }
    LevelOrder(r->right, level - 1, sum);
    LevelOrder(r->left, level - 1, sum);
}
int BFS(TreeNode *r)
{
    int ans = 0;
    int h = height(r);
    int maxSum = INT_MIN;
    for (int i = 0; i <= h; i++)
    {
        int sum = 0;
        LevelOrder(r, i, sum);
        if (sum > maxSum)
        {
            ans = i + 1;
            maxSum = sum;
        }
    }
    return ans;
}
int maxLevelSum(TreeNode *root)
{
    return BFS(root);
}
int main()
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(7);
    root->left->left = new TreeNode(7);
    root->left->right = new TreeNode(-8);
    root->right = new TreeNode(0);
    cout << maxLevelSum(root);
    return 0;
}