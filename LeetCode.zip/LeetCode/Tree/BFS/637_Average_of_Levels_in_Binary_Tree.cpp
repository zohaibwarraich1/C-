#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
int height(TreeNode *r)
{
    if (r == nullptr)
    {
        return -1;
    }
    else
    {
        int left = height(r->left);
        int right = height(r->right);
        if (left > right)
        {
            return left + 1;
        }
        else
        {
            return right + 1;
        }
    }
}
void SumByLevel(TreeNode *r, int level, double &sum, int &count)
{
    if (r == nullptr)
    {
        return;
    }
    else if (level == 0)
    {
        count++;
        sum += r->val;
    }
    else
    {
        SumByLevel(r->left, level - 1, sum, count);
        SumByLevel(r->right, level - 1, sum, count);
    }
}
vector<double> BFS(TreeNode *r)
{
    int h = height(r);
    vector<double> result;
    for (int i = 0; i <= h; i++)
    {
        double sum = 0;
        int count = 0;
        SumByLevel(r, i, sum, count);
        double average = (double)sum / count;
        result.push_back(average);
    }
    return result;
}
vector<double> averageOfLevels(TreeNode *root)
{
    return BFS(root);
}
int main()
{
    TreeNode *root = new TreeNode(3);
    root->left = new TreeNode(9);
    root->right = new TreeNode(20);
    root->right->left = new TreeNode(15);
    root->right->right = new TreeNode(7);
    vector<double> result = averageOfLevels(root);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}