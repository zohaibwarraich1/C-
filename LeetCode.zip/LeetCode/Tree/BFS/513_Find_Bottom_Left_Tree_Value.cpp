#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
int height(TreeNode *r)
{
    if (r == nullptr)
    {
        return -1;
    }
    else
    {
        int left = height(r->left);
        int right = height(r->right);
        if (left > right)
        {
            return left + 1;
        }
        else
        {
            return right + 1;
        }
    }
}
void LevelOrder(TreeNode *r, int level, bool &found, int &ans)
{
    if (r == nullptr)
    {
        return;
    }
    else if (level == 0 && found == false)
    {
        found = true;
        ans = r->val;
    }
    LevelOrder(r->left, level - 1, found, ans);
    LevelOrder(r->right, level - 1, found, ans);
}
void BFS(TreeNode *r, int &ans)
{
    int h = height(r);
    bool found = false;
    LevelOrder(r, h, found, ans);
}
int findBottomLeftValue(TreeNode *root)
{
    int ans = 0;
    BFS(root, ans);
    return ans;
}
int main()
{
    TreeNode *root = new TreeNode(2);
    root->left = new TreeNode(1);
    root->right = new TreeNode(3);
    cout << findBottomLeftValue(root);
    return 0;
}