#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;

//! Note: It is Iterative BFS using queue.

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode *next;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr), next(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right, TreeNode *next) : val(x), left(left), right(right), next(next) {}
};
bool isSymmetric(TreeNode *root)
{
    if (root == nullptr)
    {
        return true;
    }
    queue<TreeNode *> q1;
    queue<TreeNode *> q2;
    q1.push(root->left);
    q2.push(root->right);
    while (!q1.empty() && !q2.empty())
    {
        TreeNode *l = q1.front();
        TreeNode *r = q2.front();
        q1.pop();
        q2.pop();
        if (l == nullptr && r == nullptr)
        {
            continue;
        }
        if ((l == nullptr && r != nullptr) ||
            (l != nullptr && r == nullptr))
        {
            return false;
        }
        if (l->val != r->val)
        {
            return false;
        }
        q1.push(l->left);
        q1.push(l->right);
        q2.push(r->right);
        q2.push(r->left);
    }
    return true;
}
int main()
{
    TreeNode *root = new TreeNode(3);
    root->left = new TreeNode(9);
    root->right = new TreeNode(20);
    root->right->left = new TreeNode(15);
    root->right->right = new TreeNode(7);
    return 0;
}