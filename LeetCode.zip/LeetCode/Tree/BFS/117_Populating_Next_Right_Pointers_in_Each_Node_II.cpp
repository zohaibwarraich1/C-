#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode *next;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr), next(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right, TreeNode *next) : val(x), left(left), right(right), next(next) {}
};
int height(TreeNode *root)
{
    if (root == nullptr)
    {
        return -1;
    }
    else
    {
        int l = height(root->left);
        int r = height(root->right);
        if (l > r)
        {
            return l + 1;
        }
        else
        {
            return r + 1;
        }
    }
}
void BFS(TreeNode *root)
{
    int h = height(root);
    for (int i = 0; i <= h; i++)
    {
        TreeNode *nxt = nullptr;
        LevelOrder(root, i, nxt);
    }
}
void LevelOrder(TreeNode *root, int level, TreeNode *&nxt)
{
    if (root == nullptr)
    {
        return;
    }
    else if (level == 0)
    {
        root->next = nxt;
        nxt = root;
        return;
    }
    LevelOrder(root->right, level - 1, nxt);
    LevelOrder(root->left, level - 1, nxt);
}
TreeNode *connect(TreeNode *root)
{
    BFS(root);
    return root;
}
int main()
{
    TreeNode *root = new TreeNode(1);
    root->next == nullptr;
    root->left = new TreeNode(2);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);
    root->right = new TreeNode(3);
    root->right->next = nullptr;
    root->right->left = new TreeNode(6);
    root->right->right = new TreeNode(7);
    root->right->right->next = nullptr;
    return 0;
}