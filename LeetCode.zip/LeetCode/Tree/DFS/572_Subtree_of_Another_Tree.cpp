#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void checkValidity(TreeNode *root, TreeNode *subRoot, bool &isValid)
{
    if (root == nullptr && subRoot == nullptr)
    {
        return;
    }
    else if ((root == nullptr && subRoot != nullptr) ||
             (root != nullptr && subRoot == nullptr))
    {
        isValid = false;
        return;
    }
    if (root->val != subRoot->val)
    {
        isValid = false;
    }
    checkValidity(root->left, subRoot->left, isValid);
    checkValidity(root->right, subRoot->right, isValid);
}
void findSubtree(TreeNode *root, TreeNode *subRoot, bool &matchedSubtree)
{
    if (root == nullptr)
    {
        return;
    }
    bool isValid = true;
    if (root->val == subRoot->val)
    {
        checkValidity(root, subRoot, isValid);
        if (isValid)
        {
            matchedSubtree = true;
            return;
        }
    }
    findSubtree(root->left, subRoot, matchedSubtree);
    findSubtree(root->right, subRoot, matchedSubtree);
}
bool isSubtree(TreeNode *root, TreeNode *subRoot)
{
    bool matchedSubtree = false;
    findSubtree(root, subRoot, matchedSubtree);
    return matchedSubtree;
}
int main()
{
    TreeNode *root = new TreeNode(3);
    root->left = new TreeNode(4);
    root->left->left = new TreeNode(1);
    root->left->right = new TreeNode(2);
    root->right = new TreeNode(5);
    TreeNode *subRoot = new TreeNode(4);
    subRoot->left = new TreeNode(1);
    subRoot->right = new TreeNode(2);
    if (isSubtree(root, subRoot))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}