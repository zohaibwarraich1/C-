#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void Preorder(TreeNode *r, vector<int> &result)
{
    if (r == nullptr)
    {
        return;
    }
    result.push_back(r->val);
    Preorder(r->left, result);
    Preorder(r->right, result);
}
vector<int> preorderTraversal(TreeNode *root)
{
    vector<int> result;
    Preorder(root, result);
    return result;
}
int main()
{
    TreeNode *root = new TreeNode(1);
    root->right = new TreeNode(2);
    root->right->left = new TreeNode(3);
    vector<int> result = preorderTraversal(root);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}