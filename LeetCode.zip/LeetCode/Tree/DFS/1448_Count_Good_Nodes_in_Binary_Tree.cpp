#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void preorder(TreeNode *temp, int &count, int max)
{
    if (temp == nullptr)
    {
        return;
    }
    if (temp->val >= max)
    {
        count++;
        max = temp->val;
    }
    preorder(temp->left, count, max);
    preorder(temp->right, count, max);
}
int goodNodes(TreeNode *root)
{
    int count = 0;
    int max = root->val;
    preorder(root, count, max);
    return count;
}
int main()
{
    TreeNode *root = new TreeNode(2);
    root->right = new TreeNode(4);
    root->right->left = new TreeNode(10);
    root->right->right = new TreeNode(8);
    root->right->right->left = new TreeNode(4);
    cout << goodNodes(root);
    return 0;
}