#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void preorder(TreeNode *r, bool flag, int &sum)
{
    if (r == nullptr)
    {
        return;
    }
    if (flag == true && r->left == nullptr && r->right == nullptr)
    {
        sum += r->val;
    }
    preorder(r->left, true, sum);
    preorder(r->right, false, sum);
}
int sumOfLeftLeaves(TreeNode *root)
{
    int sum = 0;
    bool flag = false;
    preorder(root, flag, sum);
    return sum;
}
int main()
{
    TreeNode *root = new TreeNode(3);
    root->left = new TreeNode(9);
    root->right = new TreeNode(20);
    root->right->left = new TreeNode(15);
    root->right->right = new TreeNode(7);
    cout << sumOfLeftLeaves(root);
    return 0;
}