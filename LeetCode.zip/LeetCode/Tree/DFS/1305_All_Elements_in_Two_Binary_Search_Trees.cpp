#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void PreOrder(TreeNode *root, vector<int> &result)
{
    if (root == nullptr)
    {
        return;
    }
    result.push_back(root->val);
    PreOrder(root->left, result);
    PreOrder(root->right, result);
}
vector<int> getAllElements(TreeNode *root1, TreeNode *root2)
{
    vector<int> result;
    PreOrder(root1, result);
    PreOrder(root2, result);
    sort(result.begin(), result.end());
    return result;
}
int main()
{
    TreeNode *root1 = new TreeNode(2);
    root1->left = new TreeNode(1);
    root1->right = new TreeNode(4);
    TreeNode *root2 = new TreeNode(1);
    root2->left = new TreeNode(0);
    root2->right = new TreeNode(3);
    vector<int> result = getAllElements(root1, root2);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}