#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void preorder(TreeNode *r, long long &valCompare, bool &valid)
{
    if (r == nullptr)
    {
        return;
    }
    preorder(r->left, valCompare, valid);
    if (r->val <= valCompare)
    {
        valid = false;
    }
    valCompare = r->val;
    preorder(r->right, valCompare, valid);
}
bool isValidBST(TreeNode *root)
{
    long long valCompare = LLONG_MIN;
    ;
    bool valid = true;
    preorder(root, valCompare, valid);
    if (valid)
    {
        return true;
    }
    else
    {
        return false;
    }
}
int main()
{
    TreeNode *root = new TreeNode(2);
    root->left = new TreeNode(1);
    root->right = new TreeNode(3);
    if (isValidBST(root))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}