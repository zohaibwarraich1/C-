#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
TreeNode *preorder(TreeNode *root1, TreeNode *root2)
{
    TreeNode *r;
    if (root1 == nullptr && root2 == nullptr)
    {
        return nullptr;
    }
    else if (root1 != nullptr && root2 == nullptr)
    {
        r = new TreeNode(root1->val);
        r->left = preorder(root1->left, root2);
        r->right = preorder(root1->right, root2);
        return r;
    }
    else if (root1 == nullptr && root2 != nullptr)
    {
        r = new TreeNode(root2->val);
        r->left = preorder(root1, root2->left);
        r->right = preorder(root1, root2->right);
        return r;
    }
    else
    {
        r = new TreeNode(root1->val + root2->val);
        r->left = preorder(root1->left, root2->left);
        r->right = preorder(root1->right, root2->right);
        return r;
    }
}
TreeNode *mergeTrees(TreeNode *root1, TreeNode *root2)
{
    return preorder(root1, root2);
}
void InOrder(TreeNode *root)
{
    if (root == nullptr)
    {
        return;
    }
    InOrder(root->left);
    cout << root->val << " ";
    InOrder(root->right);
}
int main()
{
    TreeNode *root1 = new TreeNode(1);
    root1->right = new TreeNode(2);
    root1->left = new TreeNode(3);
    root1->left->left = new TreeNode(5);
    TreeNode *root2 = new TreeNode(2);
    root2->right = new TreeNode(3);
    root2->left = new TreeNode(1);
    root2->left->right = new TreeNode(4);
    root2->right->right = new TreeNode(7);
    TreeNode *result = mergeTrees(root1, root2);
    InOrder(result);
    return 0;
}