#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void preorder(TreeNode *r, vector<int> &vec)
{
    if (r == nullptr)
    {
        return;
    }
    if (r->left == nullptr && r->right == nullptr)
    {
        vec.push_back(r->val);
    }
    preorder(r->left, vec);
    preorder(r->right, vec);
}
bool leafSimilar(TreeNode *root1, TreeNode *root2)
{
    vector<int> r1;
    vector<int> r2;
    preorder(root1, r1);
    preorder(root2, r2);
    if (r1.size() != r2.size())
    {
        return false;
    }
    for (int i = 0; i < r1.size(); i++)
    {
        if (r1[i] != r2[i])
        {
            return false;
        }
    }
    return true;
}
int main()
{
    TreeNode *root1 = new TreeNode(4);
    root1->left = new TreeNode(2);
    root1->left->left = new TreeNode(1);
    root1->left->right = new TreeNode(3);
    root1->right = new TreeNode(7);
    TreeNode *root2 = new TreeNode(4);
    root2->left = new TreeNode(2);
    root2->left->left = new TreeNode(1);
    root2->left->right = new TreeNode(3);
    root2->right = new TreeNode(7);
    if (leafSimilar(root1, root2))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}