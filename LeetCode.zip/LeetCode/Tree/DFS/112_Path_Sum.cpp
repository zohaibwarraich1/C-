#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void preorder(TreeNode *r, int target, int sum, bool &valid)
{
    if (r == nullptr)
    {
        return;
    }
    sum += r->val;
    if (sum == target && r->left == nullptr && r->right == nullptr)
    {
        valid = true;
    }
    preorder(r->left, target, sum, valid);
    preorder(r->right, target, sum, valid);
}
bool hasPathSum(TreeNode *root, int targetSum)
{
    bool valid = false;
    preorder(root, targetSum, 0, valid);
    if (valid)
        return true;
    else
        return false;
}
int main()
{
    TreeNode *root = new TreeNode(2);
    root->right = new TreeNode(4);
    root->right->left = new TreeNode(10);
    root->right->right = new TreeNode(8);
    root->right->right->left = new TreeNode(4);
    if (hasPathSum(root, 6))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}