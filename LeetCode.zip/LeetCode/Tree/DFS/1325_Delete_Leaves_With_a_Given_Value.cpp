#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
TreeNode *preorder(TreeNode *r, int target)
{
    if (r == nullptr)
    {
        return nullptr;
    }
    r->left = preorder(r->left, target);
    r->right = preorder(r->right, target);
    if (r->left == nullptr && r->right == nullptr && r->val == target)
    {
        return nullptr;
    }
    return r;
}
TreeNode *removeLeafNodes(TreeNode *root, int target)
{
    root = preorder(root, target);
    return root;
}
void InOrder(TreeNode *root)
{
    if (root == nullptr)
    {
        return;
    }
    InOrder(root->left);
    cout << root->val << " ";
    InOrder(root->right);
}
int main()
{
    TreeNode *root = new TreeNode(4);
    root->left = new TreeNode(2);
    root->left->left = new TreeNode(1);
    root->left->right = new TreeNode(3);
    root->right = new TreeNode(7);
    TreeNode *result = removeLeafNodes(root, 2);
    InOrder(result);
    return 0;
}