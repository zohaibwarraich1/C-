#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
int height(TreeNode *r)
{
    if (r == nullptr)
    {
        return -1;
    }
    else
    {
        int l = height(r->left);
        int ri = height(r->right);
        return max(l, ri) + 1;
    }
}
bool isBalanced(TreeNode *root)
{
    if (root == nullptr)
    {
        return true;
    }
    int cal = height(root->left) - height(root->right);
    bool balanced = true;
    if (cal > 1 || cal < -1)
    {
        balanced = false;
    }
    bool left = isBalanced(root->left);
    bool right = isBalanced(root->right);
    if (balanced && left && right)
    {
        return true;
    }
    else
        return false;
}
int main()
{
    TreeNode *root = new TreeNode(3);
    root->left = new TreeNode(9);
    root->right = new TreeNode(20);
    root->right->left = new TreeNode(15);
    root->right->right = new TreeNode(7);
    if (isBalanced(root))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}