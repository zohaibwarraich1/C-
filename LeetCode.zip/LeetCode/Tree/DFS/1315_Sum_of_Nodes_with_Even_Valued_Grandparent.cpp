#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void preorder(TreeNode *r, int &sum, TreeNode *gp, TreeNode *p)
{
    if (r == nullptr)
    {
        return;
    }
    if (gp != nullptr && gp->val % 2 == 0)
    {
        sum += r->val;
    }
    gp = p;
    p = r;
    preorder(r->left, sum, gp, p);
    preorder(r->right, sum, gp, p);
}
int sumEvenGrandparent(TreeNode *root)
{
    int sum = 0;
    preorder(root->left, sum, nullptr, root);
    preorder(root->right, sum, nullptr, root);
    return sum;
}
int main()
{
    TreeNode *root = new TreeNode(6);
    root->left = new TreeNode(7);
    root->left->right = new TreeNode(7);
    root->left->right->left = new TreeNode(1);
    root->left->right->right = new TreeNode(4);
    root->left->left = new TreeNode(2);
    root->left->left->left = new TreeNode(9);
    root->right = new TreeNode(8);
    root->right->right = new TreeNode(3);
    root->right->left = new TreeNode(1);
    root->right->right->right = new TreeNode(5);
    cout << sumEvenGrandparent(root);
    return 0;
}