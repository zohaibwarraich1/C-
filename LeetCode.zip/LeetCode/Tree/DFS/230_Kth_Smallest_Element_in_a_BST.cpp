#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void countNodes(TreeNode *r, int &count, int k, int &ans)
{
    if (r == nullptr)
    {
        return;
    }
    countNodes(r->left, count, k, ans);
    count++;
    if (count == k)
    {
        ans = r->val;
    }
    countNodes(r->right, count, k, ans);
}
int kthSmallest(TreeNode *root, int k)
{
    int count = 0;
    int ans = 0;
    countNodes(root, count, k, ans);
    return ans;
}
int main()
{
    TreeNode *root = new TreeNode(3);
    root->left = new TreeNode(1);
    root->left->right = new TreeNode(2);
    root->right = new TreeNode(4);
    cout << kthSmallest(root, 1);
    return 0;
}