#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void check(TreeNode *p, TreeNode *q, bool &isSame)
{
    if (p == nullptr && q == nullptr)
    {
        return;
    }
    else if (p == nullptr && q != nullptr || p != nullptr && q == nullptr)
    {
        isSame = false;
        return;
    }
    if (p->val != q->val)
    {
        isSame = false;
    }
    check(p->left, q->left, isSame);
    check(p->right, q->right, isSame);
}
bool isSameTree(TreeNode *p, TreeNode *q)
{
    bool isSame = true;
    check(p, q, isSame);
    if (isSame)
    {
        return true;
    }
    return false;
}
int main()
{
    TreeNode *root1 = new TreeNode(1);
    root1->left = new TreeNode(2);
    root1->right = new TreeNode(3);
    TreeNode *root2 = new TreeNode(1);
    root2->left = new TreeNode(2);
    root2->right = new TreeNode(3);
    if (isSameTree(root1, root2))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}