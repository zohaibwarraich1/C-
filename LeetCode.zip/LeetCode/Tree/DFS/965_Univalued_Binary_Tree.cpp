#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
bool isValid(TreeNode *root, int val)
{
    if (root == nullptr)
    {
        return true;
    }
    if (root->val != val)
    {
        return false;
    }
    bool l = isValid(root->left, val);
    bool r = isValid(root->right, val);
    return (l && r);
}
bool isUnivalTree(TreeNode *root)
{
    return isValid(root, root->val);
}
int main()
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(1);
    root->right = new TreeNode(2);
    if (isUnivalTree(root))
        cout << "True";
    else
        cout << "False";
    return 0;
}