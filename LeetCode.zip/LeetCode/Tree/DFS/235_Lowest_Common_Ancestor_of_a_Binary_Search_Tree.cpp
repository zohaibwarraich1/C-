#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
void findAncestors(TreeNode *r, TreeNode *find, vector<TreeNode *> &store)
{
    if (r == nullptr)
    {
        return;
    }
    store.push_back(r);
    if (r->val == find->val)
    {
        return;
    }
    else
    {
        if (r->val < find->val)
        {
            findAncestors(r->right, find, store);
        }
        else if (r->val > find->val)
        {
            findAncestors(r->left, find, store);
        }
    }
}
TreeNode *lowestCommonAncestor(TreeNode *root, TreeNode *p, TreeNode *q)
{
    if (p == nullptr || q == nullptr)
    {
        return nullptr;
    }
    vector<TreeNode *> pV;
    vector<TreeNode *> qV;
    findAncestors(root, p, pV);
    findAncestors(root, q, qV);
    TreeNode *common = nullptr;
    for (int i = 0; i < min(pV.size(), qV.size()); i++)
    {
        if (pV[i] == qV[i])
        {
            common = pV[i];
        }
    }
    return common;
}
int main()
{
    TreeNode *root = new TreeNode(6);
    root->left = new TreeNode(2);
    root->left->left = new TreeNode(0);
    root->left->right = new TreeNode(4);
    root->left->right->left = new TreeNode(3);
    root->left->right->right = new TreeNode(5);
    root->right = new TreeNode(8);
    root->right->left = new TreeNode(7);
    root->right->right = new TreeNode(9);
    TreeNode *result = lowestCommonAncestor(root, root->left, root->right);
    cout << result->val << endl;
    return 0;
}