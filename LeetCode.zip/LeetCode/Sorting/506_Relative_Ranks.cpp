#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<string> findRelativeRanks(vector<int> &score)
{
    int n = score.size();
    vector<int> sortedScore(score);
    sort(sortedScore.rbegin(), sortedScore.rend());
    unordered_map<int, string> rank;
    for (int i = 0; i < n; ++i)
    {
        if (i == 0)
            rank[sortedScore[i]] = "Gold Medal";
        else if (i == 1)
            rank[sortedScore[i]] = "Silver Medal";
        else if (i == 2)
            rank[sortedScore[i]] = "Bronze Medal";
        else
            rank[sortedScore[i]] = to_string(i + 1);
    }
    vector<string> answer(n);
    for (int i = 0; i < n; ++i)
    {
        answer[i] = rank[score[i]];
    }
    return answer;
}
int main()
{
    vector<int> score = {5, 4, 3, 2, 1};
    vector<string> result = findRelativeRanks(score);
    for (auto ele : result)
    {
        cout << ele << ", ";
    }
    return 0;
}