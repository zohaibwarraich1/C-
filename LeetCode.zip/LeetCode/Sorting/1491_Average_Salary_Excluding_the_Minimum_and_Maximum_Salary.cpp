#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
double average(vector<int> &salary)
{
    long sum = 0;
    int n = salary.size();
    sort(salary.begin(), salary.end());
    for (int i = 0; i < n; i++)
    {
        sum += salary[i];
    }
    cout << sum << endl;
    sum = sum - (salary[0] + salary[n - 1]);
    cout << sum << endl;
    double average = (double)sum / (n - 2);
    return average;
}
int main()
{
    vector<int> salary = {2000, 3000, 1000, 4000};
    cout << average(salary);
    return 0;
}