#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
bool isArithmetic(vector<int> nums, int l, int r)
{
    vector<int> temp;
    for (int i = l; i <= r; i++)
    {
        temp.push_back(nums[i]);
    }
    sort(temp.begin(), temp.end());
    for (int i = 1; i < temp.size() - 1; i++)
    {
        if (temp[i + 1] - temp[i] != temp[i] - temp[i - 1])
        {
            return false;
        }
    }
    return true;
}
vector<bool> checkArithmeticSubarrays(vector<int> &nums, vector<int> &l, vector<int> &r)
{
    vector<bool> result;
    for (int i = 0; i < r.size(); i++)
    {
        result.push_back(isArithmetic(nums, l[i], r[i]));
    }
    return result;
}
int main()
{
    vector<int> nums = {4, 6, 5, 9, 3, 7};
    vector<int> l = {0, 0, 2};
    vector<int> r = {2, 3, 5};
    vector<bool> result = checkArithmeticSubarrays(nums, l, r);
    for (auto ele : result)
    {
        if (ele == true)
        {
            cout << "True ";
        }
        else
            cout << "False ";
    }
    return 0;
}