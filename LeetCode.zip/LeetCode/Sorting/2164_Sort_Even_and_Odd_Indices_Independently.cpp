#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> sortEvenOdd(vector<int> &nums)
{
    vector<int> odd;
    vector<int> even;
    for (int i = 0; i < nums.size(); i++)
    {
        if (i % 2 == 0)
        {
            even.push_back(nums[i]);
        }
        else
        {
            odd.push_back(nums[i]);
        }
    }
    sort(even.begin(), even.end());
    sort(odd.rbegin(), odd.rend());
    vector<int> result;
    int ep = 0;
    int op = 0;
    for (int i = 0; i < nums.size(); i++)
    {
        if (i % 2 == 0)
        {
            result.push_back(even[ep]);
            ep++;
        }
        else
        {
            result.push_back(odd[op]);
            op++;
        }
    }
    return result;
}
int main()
{
    vector<int> nums = {4, 1, 2, 3};
    vector<int> result = sortEvenOdd(nums);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}