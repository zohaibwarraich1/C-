#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int matrixSum(vector<vector<int>> &nums)
{
    for (int i = 0; i < nums.size(); i++)
    {
        sort(nums[i].begin(), nums[i].end());
    }
    int sum = 0;
    for (int i = 0; i < nums[0].size(); i++)
    {
        int temp = INT_MIN;
        for (int j = 0; j < nums.size(); j++)
        {
            if (temp < nums[j][i])
            {
                temp = nums[j][i];
            }
        }
        sum += temp;
    }
    return sum;
}
int main()
{
    vector<vector<int>> nums = {{7, 2, 1}, {6, 4, 2}, {6, 5, 3}, {3, 2, 1}};
    cout << matrixSum(nums);
    return 0;
}