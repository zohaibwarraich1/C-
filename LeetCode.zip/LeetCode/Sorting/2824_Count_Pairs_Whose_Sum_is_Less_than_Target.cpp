#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int countPairs(vector<int> &nums, int target)
{
    sort(nums.begin(), nums.end());
    int count = 0;
    for (int i = 0; i < nums.size() - 1; i++)
    {
        for (int j = i + 1; j < nums.size(); j++)
        {
            if (nums[i] + nums[j] < target)
            {
                count++;
            }
        }
    }
    return count;
}
int main()
{
    vector<int> nums = {-1, 1, 2, 3, 1};
    cout << countPairs(nums, 2);
    return 0;
}