#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
void CountingSort(vector<int> &nums, int div, int size)
{
    int count[10] = {0};
    vector<int> result(size);
    for (int i = 0; i < size; i++)
    {
        count[(nums[i] / div) % 10]++;
    }
    for (int i = 1; i < 10; i++)
    {
        count[i] += count[i - 1];
    }
    for (int i = size - 1; i >= 0; i--)
    {
        result[count[(nums[i] / div) % 10] - 1] = nums[i];
        count[(nums[i] / div) % 10]--;
    }
    for (int i = 0; i < size; i++)
    {
        nums[i] = result[i];
    }
}
void RadixSort(vector<int> &nums)
{
    int size = nums.size();
    int max = nums[0];
    for (int i = 1; i < size; i++)
    {
        if (max < nums[i])
        {
            max = nums[i];
        }
    }
    for (int div = 1; max / div > 0; div *= 10)
    {
        CountingSort(nums, div, size);
    }
}
int maxProduct(vector<int> &nums)
{
    RadixSort(nums);
    int size = nums.size();
    return (nums[size - 2] - 1) * (nums[size - 1] - 1);
}
int main()
{
    vector<int> nums = {3, 4, 5, 2};
    cout << maxProduct(nums);
    return 0;
}