#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int Pivot(string &s, int l, int r)
{
    int pivot = r;
    int pIndex = l;
    for (int i = l; i < r; i++)
    {
        if (s[i] <= s[pivot])
        {
            swap(s[pIndex], s[i]);
            pIndex++;
        }
    }
    swap(s[pIndex], s[r]);
    return pIndex;
}
void QuickSort(string &s, int l, int r)
{
    if (l < r)
    {
        int p = Pivot(s, l, r);
        QuickSort(s, l, p - 1);
        QuickSort(s, p + 1, r);
    }
}
bool checkIfCanBreak(string s1, string s2)
{
    QuickSort(s1, 0, (s1.length() - 1));
    QuickSort(s2, 0, (s2.length() - 1));
    bool first = true;
    bool sec = true;
    for (int i = 0; i < s1.length(); i++)
    {
        if (s1[i] < s2[i])
        {
            first = false;
        }
        if (s2[i] < s1[i])
        {
            sec = false;
        }
    }
    if (first || sec)
    {
        return true;
    }
    else
    {
        return false;
    }
}
int main()
{
    string s1 = "abc";
    string s2 = "xya";
    if (checkIfCanBreak(s1, s2))
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
    return 0;
}