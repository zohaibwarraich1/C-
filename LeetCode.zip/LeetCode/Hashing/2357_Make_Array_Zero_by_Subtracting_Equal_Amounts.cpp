#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int minimumOperations(vector<int> &nums)
{
    set<int> st;
    for (int x : nums)
    {
        if (x != 0)
            st.insert(x);
    }
    return st.size();
}
int main()
{
    vector<int> nums = {1, 5, 0, 3, 5};
    cout << minimumOperations(nums);
    return 0;
}