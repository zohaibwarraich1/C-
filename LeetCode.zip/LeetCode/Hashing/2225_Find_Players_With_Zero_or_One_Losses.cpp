#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<vector<int>> findWinners(vector<vector<int>> &matches)
{
    map<int, int> losersMap;
    map<int, int> winnersMap;
    vector<int> losers;
    vector<int> winners;
    vector<vector<int>> result;
    for (int i = 0; i < matches.size(); i++)
    {
        losersMap[matches[i][1]]++;
    }
    for (auto it : losersMap)
    {
        if (it.second == 1)
        {
            losers.push_back(it.first);
        }
    }
    for (int i = 0; i < matches.size(); i++)
    {
        winnersMap[matches[i][0]]++;
    }
    for (auto it : winnersMap)
    {
        if (losersMap.find(it.first) == losersMap.end())
        {
            winners.push_back(it.first);
        }
    }
    result.push_back(winners);
    result.push_back(losers);
    return result;
}
int main()
{
    vector<vector<int>> matches = {{1, 3}, {2, 3}, {3, 6}, {5, 6}, {5, 7}, {4, 5}, {4, 8}, {4, 9}, {10, 4}, {10, 9}};
    vector<vector<int>> result = findWinners(matches);
    for (int i = 0; i < result.size(); i++)
    {
        for (int j = 0; j < result[i].size(); j++)
        {
            cout << result[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}