#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int numJewelsInStones(string jewels, string stones)
{
    unordered_map<char, int> mp;
    for (int i = 0; i < stones.length(); i++)
    {
        mp[stones[i]]++;
    }
    int count = 0;
    unordered_map<char, int>::iterator it = mp.begin();
    for (int i = 0; i < jewels.size(); i++)
    {
        if (mp.count(jewels[i]))
        {
            it = mp.find(jewels[i]);
            count += it->second;
        }
    }
    return count;
}
int main()
{
    string jewels = "aA";
    string stones = "aAAZZZZZZ";
    cout << numJewelsInStones(jewels, stones);
    return 0;
}