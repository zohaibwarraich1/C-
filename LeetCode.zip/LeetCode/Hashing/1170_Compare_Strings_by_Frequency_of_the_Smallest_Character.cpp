#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int f(string word)
{
    map<char, int> mp;
    for (int i = 0; i < word.size(); i++)
    {
        mp[word[i]]++;
    }
    auto it = mp.begin();
    return it->second;
}
vector<int> numSmallerByFrequency(vector<string> &queries, vector<string> &words)
{
    vector<int> result;
    vector<int> wordsCounts;
    for (int i = 0; i < words.size(); i++)
    {
        wordsCounts.push_back(f(words[i]));
    }
    vector<int> queryCounts;
    for (int i = 0; i < queries.size(); i++)
    {
        queryCounts.push_back(f(queries[i]));
    }
    for (int i = 0; i < queries.size(); i++)
    {
        int count = 0;
        for (int j = 0; j < words.size(); j++)
        {
            if (queryCounts[i] < wordsCounts[j])
            {
                count++;
            }
        }
        result.push_back(count);
    }
    return result;
}
int main()
{
    vector<string> queries = {"bbb", "cc"};
    vector<string> words = {"a", "aa", "aaa", "aaaa"};
    vector<int> result = numSmallerByFrequency(queries, words);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}