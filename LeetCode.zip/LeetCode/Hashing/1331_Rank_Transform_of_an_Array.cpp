#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> arrayRankTransform(vector<int> &arr)
{
    vector<int> tempArr = arr;
    sort(tempArr.begin(), tempArr.end());
    map<int, int> mp;
    int rank = 1;
    for (int i = 0; i < tempArr.size(); i++)
    {
        if (mp.find(tempArr[i]) == mp.end())
        {
            mp[tempArr[i]] = rank;
            rank++;
        }
    }
    tempArr.clear();
    for (int i = 0; i < arr.size(); i++)
    {
        arr[i] = mp[arr[i]];
    }
    return arr;
}
int main()
{
    vector<int> arr = {40, 10, 20, 30};
    vector<int> result = arrayRankTransform(arr);
    for (int i = 0; i < result.size(); i++)
    {
        cout << result[i] << " ";
    }
    return 0;
}