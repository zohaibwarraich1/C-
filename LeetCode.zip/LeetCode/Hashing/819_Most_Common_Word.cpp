#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
string mostCommonWord(string paragraph, vector<string> &banned)
{
    string temp;
    string newPara;
    for (int i = 0; i < paragraph.size(); i++)
    {
        if (paragraph[i] != '.' && paragraph[i] != ';' && paragraph[i] != '!' && paragraph[i] != '?' && paragraph[i] != ',' && paragraph[i] != '\'')
        {
            newPara.push_back(paragraph[i]);
        }
        else
        {
            newPara.push_back(' ');
        }
    }
    set<string> set;
    for (int i = 0; i < banned.size(); i++)
    {
        transform(banned[i].begin(), banned[i].end(), banned[i].begin(), ::tolower);
        set.insert(banned[i]);
    }
    transform(newPara.begin(), newPara.end(), newPara.begin(), ::tolower);
    stringstream ss(newPara);
    map<string, int> mp;
    while (ss >> temp)
    {
        if (set.find(temp) == set.end())
        {
            mp[temp]++;
        }
    }
    string commonWord;
    int maxFreq = 0;
    for (auto it : mp)
    {
        if (it.second > maxFreq)
        {
            commonWord = it.first;
            maxFreq = it.second;
        }
    }
    return commonWord;
}
int main()
{
    string paragraph = "Bob hit a ball, the hit BALL flew far after it was hit.";
    vector<string> banned = {"Hit"};
    cout << mostCommonWord(paragraph, banned);
    return 0;
}