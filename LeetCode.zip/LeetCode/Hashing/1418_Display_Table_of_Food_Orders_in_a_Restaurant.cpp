#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<vector<string>> displayTable(vector<vector<string>> &orders)
{
    vector<vector<string>> result;
    set<string> items;
    for (int i = 0; i < orders.size(); i++)
    {
        items.insert(orders[i][2]);
    }
    vector<string> itemsVec;
    itemsVec.push_back("Table");
    for (auto it : items)
    {
        itemsVec.push_back(it);
    }
    result.push_back(itemsVec);
    map<pair<int, string>, int> mp;
    for (int i = 0; i < orders.size(); i++)
    {
        mp[make_pair(stoi(orders[i][1]), orders[i][2])]++;
    }
    set<int> tbNums;
    for (int i = 0; i < orders.size(); i++)
    {
        tbNums.insert(stoi(orders[i][1]));
    }
    auto it = tbNums.begin();
    for (int i = 0; i < tbNums.size(); i++)
    {
        vector<string> temp;
        temp.push_back(to_string(*it));
        for (int j = 1; j < result[i].size(); j++)
        {
            pair<int, string> p(*it, itemsVec[j]);
            if (mp.find(p) != mp.end())
            {
                auto it = mp.find(p);
                temp.push_back(to_string(it->second));
            }
            else
            {
                temp.push_back("0");
            }
        }
        result.push_back(temp);
        it++;
    }
    return result;
}
int main()
{
    vector<vector<string>> orders = {{"David", "3", "Ceviche"}, {"Corina", "10", "Beef Burrito"}, {"David", "3", "Fried Chicken"}, {"Carla", "5", "Water"}, {"Carla", "5", "Ceviche"}, {"Rous", "3", "Ceviche"}};
    vector<vector<string>> result = displayTable(orders);
    for (auto i : result)
    {
        for (auto j : i)
        {
            cout << j << " ";
        }
        cout << endl;
    }
    return 0;
}