#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <algorithm>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
vector<vector<string>> groupAnagrams(vector<string> &strs)
{
    vector<vector<string>> result;
    multimap<string, string> mp;
    for (int i = 0; i < strs.size(); i++)
    {
        string sorted = strs[i];
        sort(sorted.begin(), sorted.end());
        mp.insert({sorted, strs[i]});
    }
    string currKey = "";
    vector<string> groups;
    multimap<string, string>::iterator it = mp.begin();
    for (; it != mp.end(); it++)
    {
        if (currKey != it->first)
        {
            if (groups.empty() == false)
            {
                result.push_back(groups);
            }
            groups.clear();
            currKey = it->first;
        }
        groups.push_back(it->second);
    }
    result.push_back(groups);
    return result;
}
int main()
{
    multimap<string, string> mp;
    vector<string> strs = {"eat", "tan", "ate", "tea", "nat", "bat"};
    vector<vector<string>> groupedAnagrams = groupAnagrams(strs);
    for (int i = 0; i < groupedAnagrams.size(); i++)
    {
        cout << "[";
        for (int j = 0; j < groupedAnagrams[i].size(); j++)
        {
            cout << groupedAnagrams[i][j] << ", ";
        }
        cout << "\b\b]" << endl;
    }
    return 0;
}