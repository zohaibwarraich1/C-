#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <set>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
using namespace std;
vector<int> intersection(vector<int> &nums1, vector<int> &nums2)
{
    multiset<int> n1;
    for (int i = 0; i < nums1.size(); i++)
    {
        n1.insert(nums1[i]);
    }
    vector<int> result;
    for (int i = 0; i < nums2.size(); i++)
    {
        if (n1.count(nums2[i]))
        {
            result.push_back(nums2[i]);
            n1.erase(n1.find(nums2[i]));
        }
    }
    return result;
}
int main()
{
    vector<int> nums1 = {1, 2, 2, 1};
    vector<int> nums2 = {2, 2};
    vector<int> result = intersection(nums1, nums2);
    for (int i = 0; i < result.size(); i++)
    {
        cout << result[i] << " ";
    }
    return 0;
}