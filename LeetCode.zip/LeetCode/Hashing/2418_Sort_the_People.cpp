#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<string> sortPeople(vector<string> &names, vector<int> &heights)
{
    map<int, string, greater<int>> mp;
    vector<string> res;
    for (int i = 0; i < heights.size(); i++)
    {
        mp[heights[i]] = names[i];
    }
    for (auto it = mp.begin(); it != mp.end(); it++)
    {
        res.push_back(it->second);
    }
    return res;
}
int main()
{
    vector<string> names = {"Mary", "John", "Emma"};
    vector<int> heights = {180, 165, 170};
    vector<string> result = sortPeople(names, heights);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}