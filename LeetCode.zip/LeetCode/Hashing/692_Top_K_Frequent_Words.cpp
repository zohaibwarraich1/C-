#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<string> topKFrequent(vector<string> &words, int k)
{
    map<string, int> mp;
    for (int i = 0; i < words.size(); i++)
    {
        mp[words[i]]++;
    }
    multimap<int, string> mp2;
    for (auto it : mp)
    {
        mp2.insert(make_pair(it.second, it.first));
    }
    priority_queue<int> pq;
    for (auto it : mp2)
    {
        pq.push(it.first);
    }
    vector<string> result;
    for (int i = 0; i < k; i++)
    {
        auto it = mp2.find(pq.top());
        pq.pop();
        result.push_back(it->second);
        mp2.erase(it);
    }
    return result;
}
int main()
{
    vector<string> words = {"i", "love", "leetcode", "i", "love", "coding"};
    vector<string> result = topKFrequent(words, 2);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}