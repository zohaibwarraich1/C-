#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int minSteps(string s, string t)
{
    map<char, int> mp1;
    map<char, int> mp2;
    int count = 0;
    for (int i = 0; i < s.length(); i++)
    {
        mp1[s[i]]++;
    }
    for (int i = 0; i < t.length(); i++)
    {
        mp2[t[i]]++;
    }
    for (auto it : mp1)
    {
        int val = it.second - mp2[it.first];
        if (val > 0)
        {
            count += val;
        }
    }
    return count;
}
int main()
{
    string s = "leetcode";
    string t = "practice";
    cout << minSteps(s, t);
    return 0;
}