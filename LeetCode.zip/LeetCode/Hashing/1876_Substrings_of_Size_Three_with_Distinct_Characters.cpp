#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int countGoodSubstrings(string s)
{
    if (s.length() < 3)
    {
        return 0;
    }
    map<char, int> mp;
    int count = 0;
    for (int i = 0; i < s.length(); i++)
    {
        mp[s[i]]++;
        if (i >= 3)
        {
            mp[s[i - 3]]--;
        }
        int tempCount = 0;
        for (auto it : mp)
        {
            if (it.second == 1)
            {
                tempCount++;
            }
        }
        if (tempCount == 3)
        {
            count++;
        }
    }
    return count;
}
int main()
{
    string s = "aababcabc";
    cout << countGoodSubstrings(s);
    return 0;
}