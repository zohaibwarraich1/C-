#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <algorithm>
#include <set>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
vector<string> removeAnagrams(vector<string> &words)
{
    vector<string> result;
    string currentKey = "";
    for (int i = 0; i < words.size(); i++)
    {
        string strs = words[i];
        sort(strs.begin(), strs.end());
        if (currentKey != strs)
        {
            result.push_back(words[i]);
            currentKey = strs;
        }
    }
    return result;
}
int main()
{
    vector<string> strs = {"abba", "baba", "bbaa", "cd", "cd"};
    vector<string> result = removeAnagrams(strs);
    cout << "[";
    for (int i = 0; i < result.size(); i++)
    {
        cout << result[i] << ", ";
    }
    cout << "\b\b]";
    return 0;
}