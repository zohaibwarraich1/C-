#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int minimumOperationsToWriteY(vector<vector<int>> &grid)
{
    int mid = grid.size() / 2;
    int n = grid.size() - 1;
    map<int, int> y, outsideOfY;
    for (int i = 0; i < grid.size(); i++)
    {
        int l = i;
        int r = n - i;
        if (l < r)
        {
            y[grid[i][l]]++;
            y[grid[i][r]]++;
        }
        else
        {
            y[grid[i][mid]]++;
        }
    }
    for (int i = 0; i < grid.size(); i++)
    {
        int l = i;
        int r = n - i;
        for (int j = 0; j < grid[i].size(); j++)
        {
            if (l < r && j != l && j != r)
            {
                outsideOfY[grid[i][j]]++;
            }
            else if (l >= r && j != mid)
            {
                outsideOfY[grid[i][j]]++;
            }
        }
    }
    int SumofInside = 0;
    int SumofOutside = 0;
    for (auto it : y)
    {
        SumofInside += it.second;
    }
    for (auto it : outsideOfY)
    {
        SumofOutside += it.second;
    }
    int Min = INT_MAX;
    for (auto it1 : y)
    {
        int Inside = SumofInside - it1.second;
        for (auto it2 : outsideOfY)
        {
            if (it1.first != it2.first)
            {
                int Outside = SumofOutside - it2.second;
                Min = min(Min, Inside + Outside);
            }
        }
    }
    if (Min == INT_MAX)
    {
        Min = 73;
    }
    return Min;
}
int main()
{
    vector<vector<int>> grid = {{1, 2, 2}, {1, 1, 0}, {0, 1, 0}};
    cout << minimumOperationsToWriteY(grid);
    return 0;
}