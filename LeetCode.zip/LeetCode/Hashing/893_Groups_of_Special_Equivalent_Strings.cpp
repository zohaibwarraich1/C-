#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int numSpecialEquivGroups(vector<string> &words)
{
    set<string> set;
    for (int i = 0; i < words.size(); i++)
    {
        int even = 0;
        int odd = 1;
        string evenS;
        while (even < words[i].size())
        {
            evenS.push_back(words[i][even]);
            even = even + 2;
        }
        string oddS;
        while (odd < words[i].size())
        {
            oddS.push_back(words[i][odd]);
            odd = odd + 2;
        }
        sort(evenS.begin(), evenS.end());
        sort(oddS.begin(), oddS.end());
        string result = evenS + oddS;
        set.insert(result);
    }
    return set.size();
}
int main()
{
    vector<string> words = {"aa", "bb", "ab", "ba"};
    cout << numSpecialEquivGroups(words);
    return 0;
}