#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;

//* Recursion
int count(int n, vector<int> dp)
{
    if (n == 0)
        return 0;
    if (n == 1)
        return 1;
    int ans = count(n / 2, dp) + count(n % 2, dp);
    return ans;
}

//* Recursion + Memoization
int count(int n, vector<int> dp)
{
    if (n == 0)
        return 0;
    if (n == 1)
        return 1;
    if (dp[n] != -1)
    {
        return dp[n];
    }
    dp[n] = count(n / 2, dp) + count(n % 2, dp);
    return dp[n];
}

//* Tabulation
vector<int> countBits(int n)
{
    vector<int> ans;
    if (n == 0)
    {
        ans.push_back(0);
        return ans;
    }
    vector<int> dp(n + 1, -1);
    dp[0] = 0;
    dp[1] = 1;
    ans.push_back(dp[0]);
    ans.push_back(dp[1]);
    for (int i = 2; i <= n; i++)
    {
        dp[i] = dp[i / 2] + dp[i % 2];
        ans.push_back(dp[i]);
    }
    return ans;
}
int main()
{
    vector<int> ans = countBits(5);
    for (auto i : ans)
    {
        cout << i << " ";
    }
    return 0;
}