#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int evalRPN(vector<string> &tokens)
{
    stack<int> st;
    for (int i = 0; i < tokens.size(); i++)
    {
        if (tokens[i] == "+" || tokens[i] == "-" || tokens[i] == "*" || tokens[i] == "/")
        {
            int op1 = st.top();
            st.pop();
            int op2 = st.top();
            st.pop();
            if (tokens[i] == "+")
            {
                st.push(op2 + op1);
            }
            else if (tokens[i] == "-")
            {
                st.push(op2 - op1);
            }
            else if (tokens[i] == "*")
            {
                st.push(op2 * op1);
            }
            else if (tokens[i] == "/")
            {
                st.push(op2 / op1);
            }
        }
        else
        {
            st.push(stoi(tokens[i]));
        }
    }
    return st.top();
}
int main()
{
    vector<string> tokens = {"4", "13", "5", "/", "+"};
    cout << evalRPN(tokens);
    return 0;
}