#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <deque>
#include <list>
#include <stack>
#include <cstdlib>
#include <stdlib.h>
#include <iomanip>
using namespace std;
int minNumberOperations(vector<int> &target)
{
    stack<int> temp;
    temp.push(0);
    int moves = 0;
    for (int i = 0; i < target.size(); i++)
    {
        if (temp.top() < target[i])
        {
            moves += target[i] - temp.top();
            temp.push(target[i]);
        }
        else
        {
            while (target[i] < temp.top())
            {
                temp.pop();
            }
            temp.push(target[i]);
        }
    }
    return moves;
}
int main()
{
    vector<int> nums = {3, 1, 1, 2};
    cout << "Moves: " << minNumberOperations(nums);
    return 0;
}