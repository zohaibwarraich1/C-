#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<string> buildArray(vector<int> &target, int n)
{
    stack<int> st;
    int size = target.size();
    for (int i = size - 1; i >= 0; i--)
    {
        st.push(target[i]);
    }
    int counter = 1;
    vector<string> result;
    while (!st.empty())
    {
        if (st.top() == counter)
        {
            st.pop();
            result.push_back("Push");
        }
        else
        {
            result.push_back("Push");
            result.push_back("Pop");
        }
        counter++;
    }
    return result;
}
int main()
{
    vector<int> target = {1, 3};
    vector<string> res = buildArray(target, 3);
    for (auto i : res)
    {
        cout << i << " ";
    }
    return 0;
}