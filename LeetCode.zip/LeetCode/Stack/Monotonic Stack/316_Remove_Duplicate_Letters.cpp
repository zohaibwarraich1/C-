#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
string removeDuplicateLetters(string s)
{
    map<char, int> lastIndexes;
    for (int i = 0; i < s.length(); i++)
    {
        lastIndexes[s[i]] = i;
    }
    stack<char> st;
    vector<bool> seen(26, false); //* To check if curr element is already present in stack.
    for (int i = 0; i < s.length(); i++)
    {
        if (seen[s[i] - 'a'])
            continue;
        while (!st.empty() && st.top() > s[i] && lastIndexes[st.top()] > i)
        {
            seen[st.top() - 'a'] = false;
            st.pop();
        }
        st.push(s[i]);
        seen[s[i] - 'a'] = true;
    }
    string res;
    while (!st.empty())
    {
        res.push_back(st.top());
        st.pop();
    }
    reverse(res.begin(), res.end());
    return res;
}
int main()
{
    string s = "bcabc";
    cout << removeDuplicateLetters(s);
    return 0;
}