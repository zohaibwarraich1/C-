#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int Partition(vector<pair<int, int>> &pairs, int s, int e)
{
    int pivot = pairs[e].first;
    int index = s;
    for (int i = s; i <= e - 1; i++)
    {
        if (pairs[i].first > pivot)
        {
            swap(pairs[i], pairs[index]);
            index++;
        }
    }
    swap(pairs[index], pairs[e]);
    return index;
}
void QuickSort(vector<pair<int, int>> &pairs, int s, int e)
{
    if (s < e)
    {
        int partition = Partition(pairs, s, e);
        QuickSort(pairs, s, (partition - 1));
        QuickSort(pairs, (partition + 1), e);
    }
}
int carFleet(int target, vector<int> &position, vector<int> &speed)
{
    vector<pair<int, int>> pairs;
    for (int i = 0; i < position.size(); i++)
    {
        pairs.push_back(make_pair(position[i], speed[i]));
    }
    QuickSort(pairs, 0, pairs.size() - 1);
    stack<double> fleetSt;
    for (int i = 0; i < pairs.size(); i++)
    {
        double time = (double)(target - pairs[i].first) / pairs[i].second;
        if (!fleetSt.empty() && time <= fleetSt.top())
        {
            continue;
        }
        fleetSt.push(time);
    }
    return fleetSt.size();
}
int main()
{
    vector<int> position = {10, 8, 0, 3, 5};
    vector<int> speed = {2, 4, 1, 3, 1};
    cout << carFleet(12, position, speed);
    return 0;
}