#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
int largestRectangleArea(vector<int> &heights)
{
    stack<int> st;
    int maxArea = 0;
    for (int i = 0; i < heights.size(); i++)
    {
        while (!st.empty() && heights[st.top()] > heights[i])
        {
            int top = st.top();
            st.pop();
            int nse = i;
            int pse;
            if (!st.empty())
            {
                pse = st.top();
            }
            else
            {
                pse = -1;
            }
            int area = heights[top] * (nse - pse - 1);
            if (maxArea < area)
            {
                maxArea = area;
            }
        }
        st.push(i);
    }
    while (!st.empty())
    {
        int top = st.top();
        st.pop();
        int nse = heights.size();
        int pse;
        if (!st.empty())
        {
            pse = st.top();
        }
        else
        {
            pse = -1;
        }
        int area = heights[top] * (nse - pse - 1);
        if (maxArea < area)
        {
            maxArea = area;
        }
    }
    return maxArea;
}
int main()
{
    vector<int> heights = {2, 1, 5, 6, 2, 3};
    cout << largestRectangleArea(heights);
    return 0;
}