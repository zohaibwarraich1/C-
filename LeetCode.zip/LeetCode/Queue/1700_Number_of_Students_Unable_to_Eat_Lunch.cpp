#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int countStudents(vector<int> &students, vector<int> &sandwiches)
{
    queue<int> ones;
    queue<int> zeros;
    queue<int> arrangement;
    for (int i = 0; i < students.size(); i++)
    {
        if (students[i] == 0)
        {
            zeros.push(students[i]);
        }
        else
        {
            ones.push(students[i]);
        }
        arrangement.push(students[i]);
    }
    int i = 0;
    int count = 0;
    while (!arrangement.empty())
    {
        if (arrangement.front() == 0 && sandwiches[i] == 0 &&
            !zeros.empty())
        {
            zeros.pop();
            arrangement.pop();
            i++;
            count++;
        }
        else if (arrangement.front() == 1 && sandwiches[i] == 1 &&
                 !ones.empty())
        {
            ones.pop();
            arrangement.pop();
            i++;
            count++;
        }
        else
        {
            if (sandwiches[i] == 0 && zeros.empty() ||
                sandwiches[i] == 1 && ones.empty())
            {
                return students.size() - count;
            }
            int front = arrangement.front();
            arrangement.pop();
            arrangement.push(front);
        }
    }
    return 0;
}
int main()
{
    vector<int> students = {1, 1, 1, 0, 0, 1};
    vector<int> sandwiches = {1, 0, 0, 0, 1, 1};
    cout << countStudents(students, sandwiches);
    return 0;
}