#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
void Merge(vector<int> &nums, int l, int mid, int r)
{
    int i = l;
    int j = mid + 1;
    vector<int> temp;
    while (i <= mid && j <= r)
    {
        if (nums[i] <= nums[j])
        {
            temp.push_back(nums[i]);
            i++;
        }
        else
        {
            temp.push_back(nums[j]);
            j++;
        }
    }
    while (i <= mid)
    {
        temp.push_back(nums[i]);
        i++;
    }
    while (j <= r)
    {
        temp.push_back(nums[j]);
        j++;
    }
    for (int i = l; i <= r; i++)
    {
        nums[i] = temp[i - l];
    }
}
void MergeSort(vector<int> &nums, int l, int r)
{
    if (l < r)
    {
        int mid = l + (r - l) / 2;
        MergeSort(nums, l, mid);
        MergeSort(nums, mid + 1, r);
        Merge(nums, l, mid, r);
    }
}
vector<int> deckRevealedIncreasing(vector<int> &deck)
{
    MergeSort(deck, 0, deck.size() - 1);
    queue<int> queue;
    for (int i = 0; i < deck.size(); i++)
    {
        queue.push(i);
    }
    vector<int> result(deck.size());
    int i = 0;
    while (!queue.empty())
    {
        result[queue.front()] = deck[i];
        i++;
        queue.pop();
        queue.push(queue.front());
        queue.pop();
    }
    return result;
}
int main()
{
    vector<int> deck = {17, 13, 11, 2, 3, 5, 7};
    vector<int> result = deckRevealedIncreasing(deck);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}