#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int findTheWinner(int n, int k)
{
    queue<int> queue;
    for (int i = 1; i <= n; i++)
    {
        queue.push(i);
    }
    while (queue.size() != 1)
    {
        for (int i = 1; i < k; i++)
        {
            queue.push(queue.front());
            queue.pop();
        }
        queue.pop();
    }
    return queue.front();
}
int main()
{
    cout << findTheWinner(5, 2);
    return 0;
}