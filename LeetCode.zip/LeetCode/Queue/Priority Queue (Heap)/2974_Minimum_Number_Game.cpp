#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> numberGame(vector<int> &nums)
{
    priority_queue<int, vector<int>, greater<int>> takingElements;
    for (int i = 0; i < nums.size(); i++)
    {
        takingElements.push(nums[i]);
    }
    priority_queue<int, vector<int>, greater<int>> alice;
    priority_queue<int, vector<int>, greater<int>> bob;
    vector<int> result;
    while (!takingElements.empty())
    {
        alice.push(takingElements.top());
        takingElements.pop();
        bob.push(takingElements.top());
        takingElements.pop();
    }
    while (!alice.empty() || !bob.empty())
    {
        result.push_back(bob.top());
        bob.pop();
        result.push_back(alice.top());
        alice.pop();
    }
    return result;
}
int main()
{
    vector<int> nums = {5, 4, 2, 3};
    vector<int> result = numberGame(nums);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}