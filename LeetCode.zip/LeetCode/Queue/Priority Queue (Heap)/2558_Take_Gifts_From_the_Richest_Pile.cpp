#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
long long pickGifts(vector<int> &gifts, int k)
{
    long long sum = 0;
    priority_queue<int> pq;
    for (int i = 0; i < gifts.size(); i++)
    {
        pq.push(gifts[i]);
    }
    for (int i = 0; i < k; i++)
    {
        int temp = pq.top();
        pq.pop();
        temp = sqrt(temp);
        pq.push(temp);
    }
    while (!pq.empty())
    {
        sum += pq.top();
        pq.pop();
    }
    return sum;
}
int main()
{
    vector<int> gifts = {25, 64, 9, 4, 100};
    cout << pickGifts(gifts, 4);
    return 0;
}