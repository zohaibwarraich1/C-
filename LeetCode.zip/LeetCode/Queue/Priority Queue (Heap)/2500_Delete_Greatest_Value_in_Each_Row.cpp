#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int deleteGreatestValue(vector<vector<int>> &grid)
{
    vector<priority_queue<int>> pq(grid.size());
    cout << pq.size();
    for (int i = 0; i < grid.size(); i++)
    {
        for (int j = 0; j < grid[i].size(); j++)
        {
            pq[i].push(grid[i][j]);
        }
    }
    int sum = 0;
    for (int i = 0; i < grid[0].size(); i++)
    {
        int temp = INT_MIN;
        for (int j = 0; j < grid.size(); j++)
        {
            if (temp < pq[j].top())
            {
                temp = pq[j].top();
            }
            pq[j].pop();
        }
        sum += temp;
    }
    return sum;
}
int main()
{
    vector<vector<int>> grid = {{1, 2, 4}, {3, 3, 1}};
    cout << deleteGreatestValue(grid);
    return 0;
}