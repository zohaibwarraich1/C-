#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int lastStoneWeight(vector<int> &stones)
{
    priority_queue<int> pq;
    for (int i = 0; i < stones.size(); i++)
    {
        pq.push(stones[i]);
    }
    while (pq.size() > 1)
    {
        int x = pq.top();
        pq.pop();
        int y = pq.top();
        pq.pop();
        if (x == y)
        {
            continue;
        }
        else
        {
            pq.push(abs(y - x));
        }
    }
    if (pq.empty())
        return 0;
    else
        return pq.top();
}
int main()
{
    vector<int> stones = {{2, 7, 4, 1, 8, 1}};
    cout << lastStoneWeight(stones);
    return 0;
}