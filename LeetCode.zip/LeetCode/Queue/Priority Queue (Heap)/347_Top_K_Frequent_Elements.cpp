#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> topKFrequent(vector<int> &nums, int k)
{
    map<int, int> mp;
    for (int i = 0; i < nums.size(); i++)
    {
        mp[nums[i]]++;
    }
    priority_queue<pair<int, int>> pq;
    auto it = mp.begin();
    for (auto it : mp)
    {
        pair<int, int> p;
        cout << it.first << " " << it.second << endl;
        cout << it.second << " " << it.first << endl;
        cout << endl;
        pq.push(make_pair(it.second, it.first));
    }
    vector<int> result;
    int count = 0;
    while (count < k)
    {
        pair<int, int> p = pq.top();
        pq.pop();
        result.push_back(p.second);
        count++;
    }
    return result;
}
int main()
{
    vector<int> nums = {1, 1, 1, 2, 2, 3};
    vector<int> result = topKFrequent(nums, 2);
    return 0;
}