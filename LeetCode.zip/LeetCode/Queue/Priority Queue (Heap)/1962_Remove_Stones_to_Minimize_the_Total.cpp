#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int minStoneSum(vector<int> &piles, int k)
{
    priority_queue<int> pq;
    for (int i = 0; i < piles.size(); i++)
    {
        pq.push(piles[i]);
    }
    while (k != 0)
    {
        int num = pq.top();
        pq.pop();
        if (num % 2 == 1)
        {
            num += 1;
        }
        pq.push(num / 2);
        k--;
    }
    int sum = 0;
    while (!pq.empty())
    {
        sum += pq.top();
        pq.pop();
    }
    return sum;
}
int main()
{
    vector<int> piles = {9, 4, 5};
    cout << minStoneSum(piles, 2);
    return 0;
}