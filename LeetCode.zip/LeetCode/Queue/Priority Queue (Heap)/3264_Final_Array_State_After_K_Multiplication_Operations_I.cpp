#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> getFinalState(vector<int> &nums, int k, int multiplier)
{
    priority_queue<pair<int, int>, vector<pair<int, int>>,
                   greater<pair<int, int>>>
        minHeap;
    for (int i = 0; i < nums.size(); ++i)
    {
        minHeap.push({nums[i], i});
    }
    for (int i = 0; i < k; ++i)
    {
        pair<int, int> pair = minHeap.top();
        minHeap.pop();
        nums[pair.second] = pair.first * multiplier;
        minHeap.push({nums[pair.second], pair.second});
    }
    return nums;
}
int main()
{
    vector<int> nums = {2, 1, 3, 5, 6};
    vector<int> result = getFinalState(nums, 5, 2);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}