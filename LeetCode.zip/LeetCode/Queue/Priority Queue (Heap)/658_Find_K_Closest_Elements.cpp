#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> findClosestElements(vector<int> &arr, int k, int x)
{
    vector<int> res;
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    for (int i = 0; i < arr.size(); i++)
    {
        pq.push(make_pair(abs(arr[i] - x), arr[i]));
    }
    int count = 0;
    while (count < k)
    {
        pair<int, int> p = pq.top();
        cout << p.first << " " << p.second << endl;
        pq.pop();
        res.push_back(p.second);
        count++;
    }
    sort(res.begin(), res.end());
    return res;
}
int main()
{
    vector<int> arr = {4, 3, 8, 1, 7};
    vector<int> result = findClosestElements(arr, 3, 2);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}