#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<int> kthSmallestPrimeFraction(vector<int> &arr, int k)
{
    map<double, pair<int, int>> mp;
    priority_queue<double, vector<double>, greater<double>> queue;
    for (int i = 0; i < arr.size(); i++)
    {
        for (int j = i + 1; j < arr.size(); j++)
        {
            mp[(double)arr[i] / arr[j]] = make_pair(arr[i], arr[j]);
            queue.push((double)arr[i] / arr[j]);
        }
    }
    int count = 1;
    while (count < k)
    {
        queue.pop();
        count++;
    }
    vector<int> result;
    result.push_back(mp[queue.top()].first);
    result.push_back(mp[queue.top()].second);
    return result;
}
int main()
{
    vector<int> arr = {1, 2, 3, 5};
    vector<int> result = kthSmallestPrimeFraction(arr, 3);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}