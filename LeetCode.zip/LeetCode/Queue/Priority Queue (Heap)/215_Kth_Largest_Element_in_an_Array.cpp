#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int findKthLargest(vector<int> &nums, int k)
{
    priority_queue<int> pq;
    for (int i = 0; i < nums.size(); i++)
    {
        pq.push(nums[i]);
    }
    int count = 1;
    while (count < k)
    {
        pq.pop();
        count++;
    }
    return pq.top();
}
int main()
{
    vector<int> nums = {1, 2, 3, 4, 5};
    cout << findKthLargest(nums, 2);
    return 0;
}