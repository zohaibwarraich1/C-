#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int minSetSize(vector<int> &arr)
{
    map<int, int> mp;
    int originalSize = arr.size();
    for (int i = 0; i < arr.size(); i++)
    {
        mp[arr[i]]++;
    }
    priority_queue<pair<int, int>, vector<pair<int, int>>> pq;
    for (auto it : mp)
    {
        pq.push(make_pair(it.second, it.first));
    }
    int tempSize = originalSize;
    int count = 0;
    while (!pq.empty() && tempSize > (originalSize / 2))
    {
        pair<int, int> pair = pq.top();
        cout << pair.first << " " << pair.second << endl;
        pq.pop();
        tempSize -= pair.first;
        count++;
    }
    return count;
}
int main()
{
    vector<int> arr = {3, 3, 3, 3, 5, 5, 5, 2, 2, 7};
    cout << minSetSize(arr);
    return 0;
}