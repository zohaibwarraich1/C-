#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
int maximumScore(int a, int b, int c)
{
    priority_queue<int> pq;
    pq.push(a);
    pq.push(b);
    pq.push(c);
    int count = 0;
    while (!pq.empty() && pq.size() > 1)
    {
        int first = pq.top() - 1;
        pq.pop();
        int second = pq.top() - 1;
        pq.pop();
        if (first != 0)
            pq.push(first);
        if (second != 0)
            pq.push(second);
        count++;
    }
    return count;
}
int main()
{
    cout << maximumScore(4, 4, 6);
    return 0;
}