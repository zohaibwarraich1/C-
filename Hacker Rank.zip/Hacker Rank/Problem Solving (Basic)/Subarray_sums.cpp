#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <queue>
#include <list>
#include <stack>
using namespace std;
vector<long> findSum(vector<int> numbers, vector<vector<int>> queries)
{
    int f = 0, s = 0;
    int x = 0;
    vector<long> res;
    for (int i = 0; i < queries.size(); i++)
    {
        f = queries[i][0];
        s = queries[i][1];
        x = queries[i][2];
        long sum = 0;
        for (int j = f; j <= s; j++)
        {
            sum += numbers[j - 1];

            if (numbers[j - 1] == 0)
            {
                sum += x;
            }
        }
        res.push_back(sum);
    }
    return res;
}
int main()
{
    vector<int> numbers = {-5, 0};
    vector<vector<int>> queries = {{2, 2, 20}, {1, 2, 10}};
    vector<long> result = findSum(numbers, queries);
    for (auto ele : result)
    {
        cout << ele << " ";
    }
    return 0;
}