#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <deque>
#include <list>
#include <stack>
using namespace std;
long h(string s)
{
    long mod = 1000000007; //* mod = 10^9+7.
    long temp = 0;
    for (int i = 0; i < s.size(); i++)
    {
        int power = (s.size() - i) - 1;
        int ascii = (int)s[i];
        int multiply = pow(131, power);
        temp += ascii * multiply;
    }
    temp = temp % mod;
    return temp;
}
vector<int> authEvents(vector<vector<string>> events)
{
    unordered_set<long> hashes;
    vector<int> verify;
    for (int i = 0; i < events.size(); i++)
    {
        if (events[i][0] == "setPassword")
        {
            hashes.clear();
            hashes.insert(h(events[i][1]));
        }
        else if (events[i][0] == "authorize")
        {
            long value = stol(events[i][1]);
            if (hashes.find(value) != hashes.end())
            {
                verify.push_back(1);
            }
            else
            {
                verify.push_back(0);
            }
        }
    }
    return verify;
}
int main()
{
    vector<vector<string>> events = {{"setPassword", "000A"}, {"authorize", "108738450"}, {"authorize", "108738449"}, {"authorize", "244736787"}};
    vector<int> verify = authEvents(events);
    for (auto element : verify)
    {
        cout << element << endl;
    }
    return 0;
}