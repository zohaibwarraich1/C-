#include <iostream>
using namespace std;
int main()
{
    //! Program for star with spaces similiar to diamond //

    int n;
    cout << "Enter odd number for rows: ";
    cin >> n;
    int half = n / 2;
    for (int i = 1; i <= n; i++)
    {
        if (i % 2 == 1 || i == 1)
        {
            for (int j = 1; j <= i; j++)
            {
                if (j == 1)
                {
                    for (int m = 1; m <= half; m++)
                    {
                        cout << " ";
                    }
                }
                cout << "* ";
            }
            cout << endl;
            half--;
        }
    }
    int half_2 = 1;
    for (int i = n - 1; i >= 1; i--)
    {
        if (i % 2 == 1 || i == 1)
        {
            for (int j = 1; j <= i; j++)
            {
                if (j == 1)
                {
                    for (int m = 1; m <= half_2; m++)
                    {
                        cout << " ";
                    }
                }
                cout << "* ";
            }
            cout << endl;
            half_2++;
        }
    }
    return 0;
}