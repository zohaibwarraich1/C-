#include <iostream>
using namespace std;
int main()
{
    //! Program for printing satrs starting from left side //

    int r, c;
    for (r = 1; r <= 5; r++)
    {
        for (c = 1; c <= r; c++)
        {
            cout << "*";
        }
        cout << endl;
    }
    return 0;
}