#include <iostream>
using namespace std;
int main()
{
    //! Program for printing star pattern starting from right side //

    int r, c, s;
    for (r = 1; r <= 5; r++)
    {
        for (s = 1; s <= 5 - r; s++)
        {
            cout << " ";
        }
        for (c = 1; c <= r; c++)
        {
            cout << "*";
        }
        cout << endl;
    }
    return 0;
}